@extends('porto.app')
@section('header')
<header id="header" class="side-header d-flex">
				<div class="header-body">
					<div class="header-container container d-flex h-100">
						<div class="header-column flex-row flex-lg-column justify-content-center h-100">
							<div class="header-row flex-row justify-content-start justify-content-lg-center py-lg-5">
								@include('porto.partials.header-logo.header-logo-32')
							</div>
							<div class="header-row header-row-side-header flex-row h-100 overflow-hidden pb-lg-5">
								@include('porto.partials.header-nav.header-nav-171')
							</div>
							<div class="header-row justify-content-end pb-lg-3">
								@include('porto.partials.header-social-icons.header-social-icons-14')
								<p class="d-none d-lg-block text-1 pt-3">© 2021 PORTO. All rights reserved</p>
								<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
									<i class="fas fa-bars"></i>
								</button>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main no-height" id="main">
				
				<div class="container-fluid p-0">

					<div id="photographyLightbox" class="mfp-hide">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/3.jpg" class="img-fluid">
									</span>
								</div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs show-thumbs mt" id="thumbGalleryThumbs">
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/3-thumb.jpg">
									</span>
								</div>
							</div>
						</div>
					</div>
					<ul id="portfolioGrid" class="portfolioGridFullNoMargins p-0" data-grid-sizer=".col-lg-5ths">
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-278')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-279')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-280')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-281')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-282')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-283')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-284')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-285')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-286')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-287')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-288')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-289')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-290')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-291')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-292')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-283')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-282')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-281')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-280')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-279')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-298')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-286')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-285')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-284')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-289')
								</a>
							</div>
						</li>
					</ul>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
