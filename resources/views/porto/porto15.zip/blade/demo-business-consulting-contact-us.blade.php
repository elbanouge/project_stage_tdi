@extends('porto.app')
@section('header')
<header id="header" class="header-transparent header-transparent-dark-bottom-border header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0 bg-dark box-shadow-none">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-10')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-44')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				@include('porto.partials.page-header.page-header-89')

				<div class="container">
					<div class="row pt-1 pb-4 mb-3">
						<div class="col-lg-8">

							<h2 class="font-weight-bold text-color-dark">- Send a Message</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla volutpat ex finibus urna tincidunt, auctor ullamcorper risus luctus. Nunc et feugiat arcu, in placerat risus. Phasellus condimentum sapien vitae.</p>

							<form class="contact-form custom-contact-form-style-1" action="php/contact-form.php" method="POST">
								<div class="contact-form-success alert alert-success d-none mt-4">
									<strong>Success!</strong> Your message has been sent to us.
								</div>

								<div class="contact-form-error alert alert-danger d-none mt-4">
									<strong>Error!</strong> There was an error sending your message.
									<span class="mail-error-message text-1 d-block"></span>
								</div>

								<input type="hidden" name="subject" value="Contact Message Received">
								<div class="form-row">
									<div class="form-group col">
										<div class="custom-input-box">
											<i class="icon-user icons text-color-primary"></i>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" placeholder="Name*" required>
										</div>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<div class="custom-input-box">
											<i class="icon-envelope icons text-color-primary"></i>
											<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control" name="email" placeholder="Email*" required>
										</div>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<div class="custom-input-box">
											<i class="icon-bubble icons text-color-primary"></i>
											<textarea maxlength="5000" data-msg-required="Please enter your message." rows="10" class="form-control" name="message" placeholder="Message*" required></textarea>
										</div>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<input type="submit" value="Submit Now" class="btn btn-outline custom-border-width btn-primary custom-border-radius font-weight-semibold text-uppercase mb-4" data-loading-text="Loading...">
									</div>
								</div>
							</form>
						</div>
						<div class="col-lg-4">

							<div class="row mb-4">
								<div class="col">
									<div class="feature-box feature-box-style-2">
										<div class="feature-box-icon mt-1">
											<i class="icon-location-pin icons"></i>
										</div>
										<div class="feature-box-info">
											<h2 class="font-weight-bold text-color-dark">- Address</h2>
											<p class="text-4">
												123 Porto Blvd, Suite 100<br>
												New York, NY
											</p>
										</div>
									</div>
								</div>
							</div>
							<div class="row mb-4">
								<div class="col">
									<div class="feature-box feature-box-style-2">
										<div class="feature-box-icon mt-1">
											<i class="icon-phone icons"></i>
										</div>
										<div class="feature-box-info">
											<h2 class="font-weight-bold text-color-dark">- Phone</h2>
											<p class="text-4">
												123-456-7890 <br>
												123-456-7891
											</p>
										</div>
									</div>
								</div>
							</div>
							<div class="row mb-4">
								<div class="col">
									<div class="feature-box feature-box-style-2">
										<div class="feature-box-icon mt-1">
											<i class="icon-envelope icons"></i>
										</div>
										<div class="feature-box-info">
											<h2 class="font-weight-bold text-color-dark">- Email</h2>
											<p class="text-4">
												<a href="mailto:mail@example.com" class="text-decoration-none">mail@example.com</a><br>
												<a href="mailto:mail2@example.com" class="text-decoration-none">mail2@example.com</a>
											</p>
										</div>
									</div>
								</div>
							</div>

						</div>

					</div>

				</div>

				<!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
				<div id="googlemaps" class="google-map mt-4 mb-0"></div>


			</div>
@endsection

@section('footer')
<footer id="footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 text-center pb-4">
							<p>2021 © Porto <span class="text-color-light">Business Consulting</span> - Copyright All Rights Reserved</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
