@extends('porto.app')
@section('header')
<header id="header" class="header-floating-bar" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'reveal', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 116, 'stickySetTop': '0px', 'stickyChangeLogo': false}">
				<div class="header-body bg-color-dark box-shadow-none">
					<div class="header-container header-container-height-sm container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-22')
								</div>
							</div>
							<div class="header-column justify-content-end mr-lg-4">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-112')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				<div class="slider-container rev_slider_wrapper" style="height: 100vh;">
					<div id="revolutionSlider" class="slider rev_slider manual" data-version="5.4.8">
						<ul>
							<li data-transition="fade">
								<img src="img/demos/gym/slides/slide-1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">
							</li>
							<li data-transition="fade">
								<img src="img/demos/gym/slides/slide-2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">
							</li>
						</ul>

						<div class="tp-static-layers">
							<h1 class="tp-caption font-weight-semibold text-color-light tp-static-layer" data-x="center" data-hoffset="0" data-y="center" data-voffset="-50" data-start="800" data-startslide="0" data-endslide="99" data-transform_in="y:[-300%];opacity:0;s:500;" style="font-size: 76px;">Take Action Now</h1>

								<div class="tp-caption font-weight-normal text-color-light text-uppercase tp-static-layer" data-x="center" data-hoffset="0" data-y="center" data-voffset="0" data-start="800" data-startslide="0" data-endslide="99" data-transform_in="y:[-300%];opacity:0;s:500;" style="font-size: 22px;">Get ready and start our free trail</div>

								<a href="demo-gym-contact-us.html" class="btn btn-primary tp-caption text-uppercase text-color-light custom-font-weight-medium tp-static-layer" data-x="center" data-hoffset="0" data-y="center" data-voffset="80" data-start="1500" data-startslide="0" data-endslide="99" data-fontsize="['15','15','15','24']" data-lineheight="['17','17','17','26']" style="padding: 15px 25px;" data-transform_in="y:[-300%];opacity:0;s:500;">Join Now</a>
							</div>
						</div>
					</div>
				</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-quaternary">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 text-center">
							<ul class="social-icons custom-social-icons">
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="row mt-2">
						<div class="col-lg-12 text-center">
							<p>2021 © Porto <strong class="text-color-light font-weight-normal">The Gym</strong> Copyright All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
