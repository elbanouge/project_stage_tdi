@extends('porto.app')
@section('header')
<header id="header" class="header-full-width solid-header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 78, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-31')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-167')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main calc-height initial-height" id="main">
				
				<div class="container-fluid p-0">

					<div id="photographyLightbox" class="mfp-hide">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
									</span>
								</div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs show-thumbs mt" id="thumbGalleryThumbs">
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
									</span>
								</div>
							</div>
						</div>
					</div>
					<ul id="portfolioGrid" class="p-0" data-grid-sizer=".col-lg-3">
						<li class="col-lg-6 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-264')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-265')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-266')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-267')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-268')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-269')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-270')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-271')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-272')
								</a>
							</div>
						</li>
						<li class="col-lg-6 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-273')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-274')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-275')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-276')
								</a>
							</div>
						</li>
						<li class="col-md-6 col-lg-3 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-277')
								</a>
							</div>
						</li>
					</ul>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
