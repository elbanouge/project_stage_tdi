@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body header-body-bottom-border border-top-0">
					<div class="header-top">
						<div class="container">
							<div class="header-row">
								<div class="header-column justify-content-start">
									<div class="header-row">
										<ul class="list list-unstyled list-inline mb-0">
											<li class="list-inline-item text-color-dark mr-4 mb-0">
												Sales: <a href="tel:+1234567890" class="text-color-dark text-color-hover-primary text-decoration-none"><strong>123-456-789</strong></a>
											</li>
											<li class="list-inline-item text-color-dark d-none d-sm-inline-block mb-0">
												Services: <a href="tel:+1234567890" class="text-color-dark text-color-hover-primary text-decoration-none"><strong>123-456-789</strong></a>
											</li>
										</ul>
									</div>
								</div>
								<div class="header-column justify-content-end">
									<div class="header-row">
										@include('porto.partials.header-social-icons.header-social-icons-9')
										<a href="#" class="btn custom-svg-btn-style-1 custom-svg-btn-style-1-solid custom-svg-btn-style-1-small text-color-light ml-4">
											<svg class="custom-svg-btn-background" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 210 70" preserveaspectratio="none">
												<polygon fill="none" stroke="#D4D4D4" stroke-width="2" stroke-miterlimit="10" points="7,5 185,5 205,34 186,63 7,63 "></polygon>
											</svg>
											GET A QUOTE
											<svg class="custom-svg-btn-arrow" version="1.1" viewbox="0 0 15.698 8.706" width="17" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
												<polygon stroke="#FFF" stroke-width="0.4" fill="#FFF" points="11.354,0 10.646,0.706 13.786,3.853 0,3.853 0,4.853 13.786,4.853 10.646,8 11.354,8.706 15.698,4.353 "></polygon>
											</svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-24')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-121')
									<div class="header-nav-features">
										@include('porto.partials.header-nav-feature.header-nav-feature-11')
									</div>
									<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
										<i class="fas fa-bars"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				@include('porto.partials.page-header.page-header-148')

				<!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
				<div id="googlemaps" class="google-map m-0" style="height:500px;"></div>

				<div class="container py-5 my-4">
					<div class="row">
						<div class="col-lg-6 mb-5 mb-lg-0">
							<h2 class="font-weight-bold text-transform-none text-8 pb-2 mb-4">Contact Us</h2>
							<div class="row">
								<div class="col">
									<div class="feature-box feature-box-style-5">
										<div class="feature-box-icon">
											<img class="icon-animated" width="42" src="img/demos/industry-factory/icons/icon-location.svg" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}">
										</div>
										<div class="feature-box-info">
											<h3 class="text-transform-none font-weight-bold custom-font-size-1 mb-3">Address</h3>
											<div class="d-flex flex-column flex-md-row">
												<ul class="list list-unstyled pr-5 mb-md-0">
													<li class="mb-0"><strong class="text-color-dark custom-font-size-3">Office/Sales</strong></li>
													<li class="mb-0">123 Street Name</li>
													<li class="mb-0">New York</li>
													<li class="mb-0">12345</li>
												</ul>
												<ul class="list list-unstyled pl-md-4 mb-0">
													<li class="mb-0"><strong class="text-color-dark custom-font-size-3">Factory</strong></li>
													<li class="mb-0">123 Street Name</li>
													<li class="mb-0">New York</li>
													<li class="mb-0">12345</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row py-3 my-4">
								<div class="col">
									<div class="feature-box feature-box-style-5">
										<div class="feature-box-icon">
											<img class="icon-animated" width="42" src="img/demos/industry-factory/icons/icon-mail.svg" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary position-relative bottom-5'}">
										</div>
										<div class="feature-box-info">
											<h3 class="text-transform-none font-weight-bold custom-font-size-1 pb-1 mb-2">E-mail Address</h3>
											<ul class="list list-unstyled pr-5 mb-0">
												<li class="mb-0"><a href="mailto:email@domain.com" class="text-color-default text-color-hover-primary text-decoration-none">porto@porto.com</a></li>
												<li class="mb-0"><a href="mailto:email@domain.com" class="text-color-default text-color-hover-primary text-decoration-none">porto2@porto.com</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="feature-box feature-box-style-5">
										<div class="feature-box-icon">
											<img class="icon-animated" width="42" src="img/demos/industry-factory/icons/icon-phone.svg" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}">
										</div>
										<div class="feature-box-info">
											<h3 class="text-transform-none font-weight-bold custom-font-size-1 pb-1 mb-2">Phone Number</h3>
											<ul class="list list-unstyled pr-5 mb-0">
												<li class="mb-0"><a href="tel:+1234567890" class="text-color-default text-color-hover-primary text-decoration-none">(800) 123-4567</a></li>
												<li class="mb-0"><a href="tel:+1234567890" class="text-color-default text-color-hover-primary text-decoration-none">(800) 123-9876</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<h2 class="font-weight-bold text-transform-none text-8 pb-2 mb-4">Send Us a Message</h2>
							<form class="contact-form custom-form-style-1" action="php/contact-form.php" method="POST">
								<div class="contact-form-success alert alert-success d-none mt-4">
									<strong>Success!</strong> Your message has been sent to us.
								</div>

								<div class="contact-form-error alert alert-danger d-none mt-4">
									<strong>Error!</strong> There was an error sending your message.
									<span class="mail-error-message text-1 d-block"></span>
								</div>

								<div class="form-row">
									<div class="form-group col">
										<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" placeholder="Your Name" required>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control" name="email" placeholder="Email Address" required>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<textarea maxlength="5000" data-msg-required="Please enter your message." rows="6" class="form-control" name="message" placeholder="Your Message" required></textarea>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<button type="submit" class="btn custom-svg-btn-style-1 custom-svg-btn-style-1-solid text-color-light text-uppercase" data-loading-text="Loading...">
											<svg class="custom-svg-btn-background" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 210 70" preserveaspectratio="none">
												<polygon fill="none" stroke="#D4D4D4" stroke-width="2" stroke-miterlimit="10" points="7,5 185,5 205,34 186,63 7,63 "></polygon>
											</svg>
											Send Message
										</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="section section-with-shape-divider border-0 custom-bg-lighten-grey-1 pt-5 pb-0 m-0">
				<div class="shape-divider shape-divider-reverse-x" style="height: 120px;">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 2000 120" preserveaspectratio="xMinYMin">
						<polygon fill="#FFF" points="-11,2 693,112 2019,6 2019,135 -11,135 "></polygon>
					</svg>
				</div>
				<div class="container pt-lg-5 mt-5">
					<div class="row">
						<div class="col-lg-3 mb-5 mb-lg-0">
							<a href="demo-industry-factory.html">
								<img src="img/demos/industry-factory/logo-light.png" class="img-fluid mt-5 mb-4" alt="Demo Industry &amp; Factory">
							</a>
							<p class="mb-0"><strong class="text-color-light">Porto Industrial, Factory, Manufacturing</strong></p>
							<p>Advanced Template LTD.</p>
							<ul class="social-icons social-icons-medium">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter mx-2"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</div>
						<div class="col-lg-4 offset-lg-1 mb-5 mb-lg-0">
							<h4 class="text-color-light font-weght-bold positive-ls-2 custom-font-size-2">USEFUL LINKS</h4>
							<div class="row">
								<div class="col-md-6">
									<ul class="list list-unstyled mb-0">
										<li class="mb-0"><a href="#">Contact Us</a></li>
										<li class="mb-0"><a href="#">Our Services</a></li>
										<li class="mb-0"><a href="#">Payment Methods</a></li>
										<li class="mb-0"><a href="#">Services Guide</a></li>
										<li class="mb-0"><a href="#">FAQs</a></li>
										<li class="mb-0"><a href="#">Service Support</a></li>
										<li class="mb-0"><a href="#">Privacy</a></li>
										<li class="mb-0"><a href="#">About Porto</a></li>
										<li class="mb-0"><a href="#">Our Guarantees</a></li>
										<li class="mb-0"><a href="#">Terms And Conditions</a></li>
									</ul>
								</div>
								<div class="col-md-6">
									<ul class="list list-unstyled mb-0">
										<li class="mb-0"><a href="#">Privacy Policy</a></li>
										<li class="mb-0"><a href="#">Return Policy</a></li>
										<li class="mb-0"><a href="#">Intellectual Property Claims</a></li>
										<li class="mb-0"><a href="#">Sitemap</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-lg-3 offset-lg-1 mb-5 mb-lg-0">
							<h4 class="text-color-light font-weght-bold positive-ls-2 custom-font-size-2">OPENING HOURS</h4>
							<ul class="list list-unstyled list-inline custom-list-style-1 mb-0">
								<li><a href="#">Mon - Fri: 8:30 am to 5:00 pm</a></li>
								<li><a href="#">Saturday: 9:30 am to 1:00 pm</a></li>
								<li><a href="#">Sunday: Closed</a></li>
							</ul>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-18')
			</footer>
@endsection
