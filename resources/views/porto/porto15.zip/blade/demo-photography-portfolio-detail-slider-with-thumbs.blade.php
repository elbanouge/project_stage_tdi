@extends('porto.app')
@section('header')
<header id="header" class="header-full-width" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-33')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-175')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main" id="main">
				
				<div class="container pt-4">

					<div id="portfolioSliderWithThumbs">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div style="background: url('img/demos/photography/gallery/family/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/3.jpg');"></div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs" id="thumbGalleryThumbs">
								<div style="background: url('img/demos/photography/gallery/family/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/3-thumb.jpg');"></div>
							</div>
						</div>
					</div>
				
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
