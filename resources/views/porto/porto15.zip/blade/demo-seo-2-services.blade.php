@extends('porto.app')
@section('header')
<header id="header" class="header-transparent header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 70, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0 appear-animation" data-appear-animation="fadeIn">
					<div class="header-top">
						<div class="container">
							<div class="header-row">
								<div class="header-column justify-content-start">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<span class="ws-nowrap custom-text-color-grey-1 text-2 pl-0"><i class="icon-envelope icons text-4 top-3 left-1 mr-1"></i> <a href="mailto:example@domain.com" class="text-color-default text-color-hover-primary">example@domain.com</a></span>
												</li>
												<li class="nav-item d-none d-md-block">
													<span class="ws-nowrap custom-text-color-grey-1 text-2"><i class="icon-clock icons text-4 top-3 left-1 mr-1"></i> Mon - Sat 9:00am - 6:00pm / Sunday - CLOSED</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>
								<div class="header-column justify-content-end">
									<div class="header-row">
										@include('porto.partials.header-social-icons.header-social-icons-16')
										<a href="tel:+1234567890" class="btn btn-tertiary font-weight-semibold text-3 px-4 custom-height-1 rounded-0 align-items-center d-none d-md-flex">
											<i class="icon-phone icons text-4 mr-2"></i> (800) 123-4567
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-38')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-194')
									<div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">porto.partials
										@include('porto.partials.header-nav-feature.header-nav-feature-3')
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="maiporto.partials

				@include('porto.partials.page-header.page-header-202')

				<section class="section bg-color-light position-relative border-0 pt-3 m-0">
					<svg class="custom-page-header-curved-top-1" width="100%" height="700" xmlns="http://www.w3.org/2000/svg">
						<path transform="rotate(-3.1329219341278076 1459.172607421877,783.5322875976566) " d="m-12.54488,445.11701c0,0 2.16796,-1.48437 6.92379,-3.91356c4.75584,-2.42918 12.09956,-5.80319 22.45107,-9.58247c20.70303,-7.55856 53.43725,-16.7382 101.56202,-23.22255c48.12477,-6.48434 111.6401,-10.27339 193.90533,-7.05074c41.13262,1.61132 88.20271,5.91306 140.3802,12.50726c230.96006,32.89734 314.60609,102.57281 635.26547,59.88645c320.65938,-42.68635 452.47762,-118.72154 843.58759,3.72964c391.10997,122.45118 553.23416,-82.15958 698.49814,-47.66481c-76.25064,69.23438 407.49874,281.32592 331.2481,350.5603c-168.91731,29.52009 85.02254,247.61162 -83.89478,277.13171c84.07062,348.27313 -2948.95065,-242.40222 -2928.39024,-287.84045" stroke-width="0" stroke="#000" fill="#FFF" id="svg_2"></path>
					</svg>
					<div class="container position-relative z-index-1 pb-3">
						<div class="custom-circle custom-circle-medium custom-circle-pos-17 appear-animation" data-appear-animation="expandIn" data-appear-animation-delay="1200">
							<div class="bg-color-quaternary rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 2000}"></div>	
						</div>
						<div class="custom-circle custom-circle-small custom-circle-pos-18 appear-animation" data-appear-animation="expandIn" data-appear-animation-delay="1400">
							<div class="custom-bg-color-grey-1 rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 2500}"></div>	
						</div>
						<div class="custom-circle custom-circle-extra-small custom-circle-pos-19 appear-animation" data-appear-animation="expandIn" data-appear-animation-delay="1600">
							<div class="custom-bg-color-grey-2 rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 1000}"></div>	
						</div>
							
						<div class="row justify-content-center pb-2 mb-4">
							<div class="col-md-7 col-lg-4 mb-4 mb-lg-0">
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1600" data-plugin-options="{'accY': -100}">
									<div class="custom-dots-rect-3" style="background-image: url(img/demos/seo-2/dots-group-3.png);"></div>
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-1.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Seo Services</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400" data-plugin-options="{'accY': -300}">
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-4.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Digital Marketing</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-lg-4 pt-lg-4 mt-lg-5 mb-4 mb-lg-0">
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1400">
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-2.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Email Marketing</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="250">
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-5.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Social Media</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-lg-4">
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1700" data-plugin-options="{'accY': -100}">
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-3.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Data Analysis</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
								<div class="card border-0 custom-box-shadow-1 custom-border-radius-1 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="500" data-plugin-options="{'accY': -100}">
									<div class="card-body text-center p-5">
										<img src="img/demos/seo-2/icons/icon-6.png" class="img-fluid mb-4 mt-3 pb-3" width="55" alt="">
										<h4 class="text-color-dark font-weight-semibold mb-3">Link Building</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra erat orci, ac auctor.</p>
										<a href="demo-seo-2-services-detail.html" class="text-color-tertiary font-weight-bold">READ MORE +</a>
									</div>
								</div>
							</div>
						</div>
						<div class="custom-circle custom-circle-big custom-circle-pos-20 appear-animation" data-appear-animation="expandInWithBlur" data-appear-animation-delay="200" data-appear-animation-duration="2s">
							<div class="bg-color-secondary rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 1, 'transition': true, 'transitionDuration': 2000}"></div>
						</div>
						<div class="custom-circle custom-circle-small custom-circle-pos-21 appear-animation" data-appear-animation="expandInWithBlur" data-appear-animation-delay="700" data-appear-animation-duration="2s">
							<div class="custom-bg-color-grey-2 rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 1000}"></div>
						</div>
						<div class="custom-circle custom-circle-medium custom-circle-pos-22 appear-animation" data-appear-animation="expandInWithBlur" data-appear-animation-delay="1200" data-appear-animation-duration="2s">
							<div class="custom-bg-color-grey-1 rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 3000}"></div>
						</div>
						<div class="custom-circle custom-circle-extra-small custom-circle-pos-23 appear-animation" data-appear-animation="expandInWithBlur" data-appear-animation-delay="1700" data-appear-animation-duration="2s">
							<div class="custom-bg-color-grey-2 rounded-circle w-100 h-100" data-plugin-float-element data-plugin-options="{'startPos': 'bottom', 'speed': 0.5, 'transition': true, 'transitionDuration': 1500}"></div>
						</div>
					</div>
				</section>

				<section class="section section-height-3 bg-color-secondary position-relative border-0 m-0">
					<div class="container position-relative z-index-1 pt-2 pb-5 mt-3 mb-5">
						<div class="row justify-content-center mb-3">
							<div class="col-md-8 col-lg-6 text-center">
								<div class="overflow-hidden mb-2">
									<h2 class="font-weight-bold text-color-light text-7 line-height-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="250">Get Your Free Instant SEO Audit Now</h2>
								</div>
								<div class="overflow-hidden mb-1">
									<p class="lead custom-text-color-light-1 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">Improve your seo ranking with porto</p>
								</div>
								<div class="overflow-hidden mb-3">
									<p class="custom-text-color-light-1 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="550">Best SEO Features &amp; Methodologies. Better SEO than your competitors</p>
								</div>
							</div>
						</div>
						<div class="row mb-3">
							<div class="col">
								<form class="custom-form-style-1 custom-form-simple-validation form-errors-light" action="/">
									<div class="form-row mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="700">
										<div class="form-group col-md-6 pr-md-2">
											<input type="text" class="form-control" value="" placeholder="Enter URL" required>
										</div>
										<div class="form-group col-md-6 pl-md-2">
											<input type="email" class="form-control" value="" placeholder="Enter E-mail Adress" required>
										</div>
									</div>
									<div class="form-row justify-content-center appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="850">
										<div class="form-group col-auto mb-0">
											<button type="submit" class="btn btn-quaternary btn-rounded font-weight-bold px-5 py-3 text-3">CHECK NOW</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-quaternary position-relative mt-0">
				<svg class="custom-section-curved-top-7" width="100%" height="400" xmlns="http://www.w3.org/2000/svg">
					<path id="svg_2" fill="#171940" stroke="#000" stroke-width="0" d="m-16.68437,95.44889c0,0 5.33335,176.00075 660.00283,93.33373c327.33474,-41.33351 503.33549,15.3334 639.00274,35.66682c135.66725,20.33342 59.66691,9.66671 358.33487,28.33346c298.66795,18.66676 268.66829,-45.00088 382.66831,-112.00048c114.00002,-66.9996 718.31698,-59.48704 1221.66946,95.563c503.35248,155.05004 -221.83202,184.10564 -243.66935,197.60521c-21.83733,13.49958 -3008.67549,-19.83371 -3008.00467,-20.83335c-0.67082,0.99964 -30.00428,-232.33469 -10.00419,-317.66839z" class="svg-fill-color-quaternary"></path>
				</svg>
				<div class="container mt-0 mb-4">
					<div class="row py-5">
						<div class="col-lg-3 mb-5 mb-lg-0">
							<h4 class="font-weight-bold text-color-light text-5 ls-0 pb-1 mb-2">ABOUT US</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra lorem ipsum erat orci, ac auctor lacus tincidunt ut...</p>
							<a href="demo-seo-2.html">
								<img src="img/demos/seo-2/logo-footer.png" class="img-fluid" alt="Demo SEO 2">
							</a>
						</div>
						<div class="col-lg-3 mb-4 mb-lg-0">
							<h4 class="font-weight-bold text-color-light text-5 ls-0 pb-1 mb-2">USEFUL LINKS</h4>
							<ul class="list list-unstyled">
								<li class="mb-1">
									<a href="#">Features</a>
								</li>
								<li class="mb-1">
									<a href="#">Pages</a>
								</li>
								<li class="mb-1">
									<a href="#">Portfolio</a>
								</li>
								<li class="mb-1">
									<a href="#">About Us</a>
								</li>
								<li class="mb-1">
									<a href="#">Contact Us</a>
								</li>
							</ul>
						</div>
						<div class="col-lg-3 mb-4 mb-lg-0">
							<h4 class="font-weight-bold text-color-light text-5 ls-0 pb-1 mb-2">OUR SERVICES</h4>
							<ul class="list list-unstyled">
								<li class="mb-1">
									<a href="demo-seo-2-services-detail.html">Seo Services</a>
								</li>
								<li class="mb-1">
									<a href="demo-seo-2-services-detail.html">Email Marketing</a>
								</li>
								<li class="mb-1">
									<a href="demo-seo-2-services-detail.html">Data Analysis</a>
								</li>
								<li class="mb-1">
									<a href="demo-seo-2-services-detail.html">Digital Marketing</a>
								</li>
								<li class="mb-1">
									<a href="demo-seo-2-services-detail.html">Social Media Marketing</a>
								</li>
							</ul>
						</div>
						<div class="col-lg-3">
							<h4 class="font-weight-bold text-color-light text-5 ls-0 pb-1 mb-2">CONTACT US</h4>
							<ul class="list list-unstyled">
								<li class="mb-1">
									Address: 123 Street Name, City, England
								</li>
								<li class="mb-1">
									Phone: <a href="tel:+1234567890">(123) 456-7890</a>
								</li>
								<li class="mb-1">
									Email: <a href="#">mail@example.com</a>
								</li>
							</ul>
							<ul class="social-icons custom-social-icons-style-1">
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
							</ul>
						</div>
					</div>porto.partials
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-38')
			</footer>
@endsection
