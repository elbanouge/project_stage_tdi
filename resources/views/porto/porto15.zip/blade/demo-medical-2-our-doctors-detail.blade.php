@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0">
					<div class="header-top header-top-default header-top-borders border-bottom-0 bg-color-light">
						<div class="container h-100">
							<div class="header-row h-100">
								<div class="header-column justify-content-between">
									<div class="header-row">
										<nav class="header-nav-top w-100">
											<ul class="nav nav-pills justify-content-between w-100 h-100">
												<li class="nav-item py-2 d-none d-xl-inline-flex">
													<span class="header-top-phone py-2 d-flex align-items-center text-color-primary font-weight-semibold text-uppercase">
														<i class="icon-phone icons text-5 mr-2"></i> <a href="tel:+1234567890">(800) 123-4567</a>
													</span>
													<span class="header-top-email px-0 font-weight-normal d-flex align-items-center"><i class="far fa-envelope text-4"></i>  <a class="text-color-default" href="mailto:mail@example.com">mail@example.com</a></span>
													<span class="header-top-opening-hours px-0 font-weight-normal d-flex align-items-center"><i class="far fa-clock text-4"></i>Mon - Sat 9:00am - 6:00pm / Sunday - CLOSED</span>
												</li>
												<li class="nav-item nav-item-header-top-socials d-flex justify-content-between">
													<span class="header-top-socials p-0 h-100">
														<ul class="d-flex align-items-center h-100 p-0">
															<li class="list-unstyled">
																<a href="#"><i class="fab fa-instagram text-color-quaternary text-hover-primary"></i></a>
															</li>
															<li class="list-unstyled">
																<a href="#"><i class="fab fa-facebook-f text-color-quaternary text-hover-primary"></i></a>
															</li>
															<li class="list-unstyled">
																<a href="#"><i class="fab fa-twitter text-color-quaternary text-hover-primary"></i></a>
															</li>
														</ul>
													</span>
													<span class="header-top-button-make-as-appoitment d-inline-flex align-items-center justify-content-center h-100 p-0 align-top">
														<a href="demo-medical-2-contact-us.html" class="d-flex align-items-center justify-content-center h-100 w-100 btn-primary font-weight-normal text-decoration-none">MAKE AN APPOINTMENT</a>
													</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container bg-color-light">
						<div class="header-row">
							<div class="header-column header-column-logo">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-28')
								</div>
							</div>
							<div class="header-column header-column-nav-menu justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-154')
								</div>
							</div>
							<div class="header-column header-column-search justify-content-center align-items-end">
								<div class="header-nav-features">
									@include('porto.partials.header-nav-feature.header-nav-feature-12')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-176')

				<div class="container py-5">
					<div class="row">
						<div class="col-lg-4 pb-4 pb-lg-0">
							<div class="card border-0 mb-4 border-radius-0 box-shadow-1 mb-4">
								<div class="card-body p-3 z-index-1 text-center">
									<a href="demo-medical-2-our-doctors-detail.html" class="d-block text-center bg-color-grey">
										<img alt="Doctor" class="img-fluid rounded" src="img/demos/medical-2/doctors/doctor-1.png">
									</a>
									<strong class="font-weight-bolder text-dark d-block text-5 mt-4 mb-0">
										<a href="demo-medical-2-our-doctors-detail.html" class="text-dark">
											John Smith
										</a>
									</strong>
									<span class="text-uppercase d-block text-default font-weight-semibold text-1 p-relative bottom-4 mb-0">Cardiology</span>
									<a href="demo-medical-2-contact-us.html" class="btn btn-outline btn-light bg-hover-light text-dark text-hover-primary border-color-grey border-color-active-primary border-color-hover-primary text-uppercase rounded-0 px-4 py-2 mb-4 mt-3 text-2">Make An Appointment</a>
								</div>
							</div>

							<ul class="social-icons social-icons-clean social-icons-big text-center">
								<li class="social-icons-instagram">
									<a href="http://www.instagram.com/" target="_blank" title="Instagram" class="border border-color-grey">
										<i class="fab fa-instagram text-4"></i>
									</a>
								</li>
								<li class="social-icons-twitter">
									<a href="http://www.twitter.com/" target="_blank" title="Twitter" class="border border-color-grey">
										<i class="fab fa-twitter text-4"></i>
									</a>
								</li>
								<li class="social-icons-facebook">
									<a href="http://www.facebook.com/" target="_blank" title="Facebook" class="border border-color-grey">
										<i class="fab fa-facebook-f text-4"></i>
									</a>
								</li>
							</ul>

							<hr class="mt-4 mb-5">

							<h3 class="text-color-quaternary font-weight-bolder text-capitalize mt-2 mb-2">Contact Info</h3>
							<p class="pb-3">Lorem ipsum dolor sit amet, consectetur adipiscing.</p>

							<div class="feature-box feature-box-style-2 mb-4">
								<div class="feature-box-icon">
									<i class="fas fa-mobile-alt"></i>
								</div>
								<div class="feature-box-info">
									<h5 class="m-0 font-weight-bold">Direct Phone Number</h5>
									<p class="m-0"><a href="tel:+1234567890">(800) 123-4567</a></p>
								</div>
							</div>

							<div class="feature-box feature-box-style-2 mb-4">
								<div class="feature-box-icon">
									<i class="far fa-envelope"></i>
								</div>
								<div class="feature-box-info">
									<h5 class="m-0 font-weight-bold">E-mail Address</h5>
									<p class="m-0"><a href="mailto:mail@domain.com">johndoe@portotheme.com</a></p>
								</div>
							</div>

							<div class="feature-box feature-box-style-2 mb-4">
								<div class="feature-box-icon">
									<i class="far fa-clock"></i>
								</div>
								<div class="feature-box-info">
									<h5 class="m-0 font-weight-bold">Working Days/Hours</h5>
									<p class="m-0">Mon - Sun / 9:00AM - 8:00PM</p>
								</div>
							</div>

						</div>
						<div class="col-lg-8">

							<h3 class="text-color-quaternary font-weight-bolder text-capitalize mb-2">About Me</h3>
							<p class="font-weight-semibold">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut tellus ante. Nam suscipit urna risus, fermentum commodo ipsum porta id.</p>
							<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. Vestibulum auctor felis eget orci semper vestibulum. Pellentesque ultricies nibh gravida, accumsan libero luctus, molestie nunc.</p>

							<p class="mb-4">Pellentesque ultricies nibh gravida, accumsan libero luctus, molestie nunc. In nibh ipsum, blandit id faucibus ac.</p>
							<div class="d-flex justify-content-start flex-column flex-xl-row pb-2">
								<ul class="list list-icons list-icons-style-2 list-icons-sm custom-list-icons mb-1 mb-xl-3">
									<li class="text-color-quaternary font-weight-bolder mb-2"><i class="fas fa-check text-color-quaternary"></i>Pellentesque ultricies nibh</li>
									<li class="text-color-quaternary font-weight-bolder mb-2"><i class="fas fa-check text-color-quaternary"></i>Ultricies nibh pellen</li>
									<li class="text-color-quaternary font-weight-bolder"><i class="fas fa-check text-color-quaternary"></i>Pellentesque ultricies nibh</li>
								</ul>
								<ul class="list list-icons list-icons-style-2 list-icons-sm custom-list-icons">
									<li class="text-color-quaternary font-weight-bolder mb-2"><i class="fas fa-check text-color-quaternary"></i>Ultricies nibh pellen</li>
									<li class="text-color-quaternary font-weight-bolder mb-2"><i class="fas fa-check text-color-quaternary"></i>Pellentesque ultricies nibh</li>
									<li class="text-color-quaternary font-weight-bolder"><i class="fas fa-check text-color-quaternary"></i>Ultricies nibh pellen</li>
								</ul>
							</div>

							<hr class="mt-4 mb-5">

							<h3 class="text-color-quaternary font-weight-bolder text-capitalize mt-2 mb-2">Education</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut tellus ante.</p>

							<div class="process process-vertical pt-4">
								<div class="process-step appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">
									<div class="process-step-circle">
										<strong class="process-step-circle-content text-4">2016</strong>
									</div>
									<div class="process-step-content">
										<h4 class="mb-1 text-4 font-weight-bold">Practical Degree of Medicine</h4>
										<p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas risus est, dignissim non urna at, efficitur cursus nibh. Curabitur varius vel mauris at auctor. Nam ullamcorper bibendum est et porta. Donec congue libero vitae semper varius.</p>
									</div>
								</div>
								<div class="process-step appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">
									<div class="process-step-circle">
										<strong class="process-step-circle-content text-4">2010</strong>
									</div>
									<div class="process-step-content">
										<h4 class="mb-1 text-4 font-weight-bold">Practical Degree of Medicine</h4>
										<p class="mb-0">Maecenas risus est, dignissim non urna at, efficitur cursus nibh. Curabitur varius vel mauris at auctor. Nam ullamcorper bibendum est et porta. Donec congue libero vitae semper varius.</p>
									</div>
								</div>
								<div class="process-step appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="600">
									<div class="process-step-circle">
										<strong class="process-step-circle-content text-4">1999</strong>
									</div>
									<div class="process-step-content">
										<h4 class="mb-1 text-4 font-weight-bold">Practical Degree of Medicine</h4>
										<p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas risus est, dignissim non urna at, efficitur cursus nibh. Curabitur varius vel mauris at auctor. Nam ullamcorper bibendum est et porta. Donec congue libero vitae semper varius.</p>
									</div>
								</div>
							</div>

							<hr class="mt-0 mb-5">

							<h3 class="text-color-quaternary font-weight-bolder text-capitalize mt-2 mb-2">Skills</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut tellus ante.</p>

							<div class="progress-bars mt-4 mb-4">
								<div class="progress-label">
									<span class="text-1">HTML/CSS</span>
								</div>
								<div class="progress progress-xs mb-2">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="100%">
										<span class="progress-bar-tooltip">100%</span>
									</div>
								</div>
								<div class="progress-label">
									<span class="text-1">Design</span>
								</div>
								<div class="progress progress-xs mb-2">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="300">
										<span class="progress-bar-tooltip">85%</span>
									</div>
								</div>
								<div class="progress-label">
									<span class="text-1">WordPress</span>
								</div>
								<div class="progress progress-xs mb-2">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="75%" data-appear-animation-delay="600">
										<span class="progress-bar-tooltip">75%</span>
									</div>
								</div>
								<div class="progress-label">
									<span class="text-1">Photoshop</span>
								</div>
								<div class="progress progress-xs mb-2">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="900">
										<span class="progress-bar-tooltip">85%</span>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>

				<section class="bg-color-primary">
					<div class="container">
						<div class="row py-2">
							<div class="col py-5 text-center text-color-light">
								<p class="text-uppercase text-color-light d-block mb-0 text-center appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="300">Need a Speciallist?</p>
								<h3 class="text-color-quaternary mb-4 text-color-light d-block text-center font-weight-semibold text-capitalize appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">Get Better Now! Just Make An Appointment</h3>
								<a href="demo-medical-2-contact-us.html" class="btn btn-outline btn-light bg-hover-light text-hover-dark text-color-light border-color-light text-uppercase rounded-0 px-5 py-3 mb-2 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="500">make an appointment</a>
							</div>
						</div>
					</div>
				</section>

				<section class="footer-top-info">
					<div class="container-fluid">
						<div class="row">
							<div class="col-xs-12 col-xl-4 p-4 bg-color-secondary d-flex align-items-center justify-content-between">
								<div class="footer-top-info-detail">
									<h4 class="text-color-light mb-1 d-block font-weight-semibold text-capitalize appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">Emergency Cases</h4>
									<p class="d-block m-0 footer-top-info-desc appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="200">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
								</div>
								<a href="#" type="button" class="btn btn-outline btn-footer-top-info btn-light rounded-0 d-block text-color-light border-color-primary text-uppercase text-center p-0 custom-btn-footer-top-info bg-transparent-hover appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="300">view more +</a>
							</div>
							<div class="col-xs-12 col-xl-4 p-4 bg-color-tertiary d-flex align-items-center justify-content-between">
								<div class="footer-top-info-detail">
									<h4 class="text-color-light mb-1 d-block font-weight-semibold text-capitalize appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="400">Doctors Timetable</h4>
									<p class="d-block m-0 footer-top-info-desc appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="500">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
								</div>
								<a href="#" type="button" class="btn btn-outline btn-footer-top-info btn-light rounded-0 d-block text-color-light border-color-primary text-uppercase text-center p-0 custom-btn-footer-top-info bg-transparent-hover appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="600">view more +</a>
							</div>
							<div class="col-xs-12 col-xl-4 p-4 bg-color-secondary d-flex align-items-center justify-content-between">
								<div class="footer-top-info-detail">
									<h4 class="text-color-light mb-1 d-block font-weight-semibold text-capitalize appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="700">Find Us On Map</h4>
									<p class="d-block m-0 footer-top-info-desc appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
								</div>
								<a href="#" type="button" class="btn btn-outline btn-footer-top-info btn-light rounded-0 d-block text-color-light border-color-primary text-uppercase text-center p-0 custom-btn-footer-top-info bg-transparent-hover appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="900">view more +</a>
							</div>
						</div>
					</div>
				</section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="m-0 bg-color-quaternary">
				<div class="container">
					<div class="row py-5">
						<div class="col-sm-12 pb-4 pb-lg-0 col-lg-2 mb-2 d-flex align-items-center">
							<img src="img/demos/medical-2/logos/logo-footer.png" alt="Logo Footer">
						</div>
						<div class="col-sm-6 col-lg-3 footer-column footer-column-get-in-touch">
							<h4 class="mb-4 text-uppercase">Get in Touch</h4>
							<div class="info custom-info mb-4">
								<div class="custom-info-block custom-info-block-address">
									<span class="text-color-default font-weight-bolder text-uppercase title-custom-info-block title-custom-info-block-address">Address</span>
									<span class="font-weight-normal text-color-light text-custom-info-block p-relative bottom-6 text-custom-info-block-address">123 Street Name, City, England</span>
								</div>
								<div class="custom-info-block custom-info-block-phone">
									<span class="text-color-default font-weight-bolder text-uppercase title-custom-info-block title-custom-info-block-phone">Phone</span>
									<span class="font-weight-normal text-color-light text-custom-info-block p-relative bottom-6 text-custom-info-block-phone">Toll Free <a href="tel:+1234567890" class="text-color-light">(123) 456-7890</a></span>
								</div>
								<div class="custom-info-block custom-info-block-email">
									<span class="text-color-default font-weight-bolder text-uppercase title-custom-info-block title-custom-info-block-email">Email</span>
									<span class="font-weight-normal text-color-light text-custom-info-block p-relative bottom-6 text-custom-info-block-email"><a class="text-color-light" href="mailto:mail@example.com">mail@example.com</a></span>
								</div>
								<div class="custom-info-block custom-info-block-working-days">
									<span class="text-color-default font-weight-bolder text-uppercase title-custom-info-block title-custom-info-block-working-days">Working Days/Hours</span>
									<span class="font-weight-normal text-color-light text-custom-info-block text-custom-info-block-working-days">Mon - Sun / 9:00AM - 8:00PM</span>
								</div>
							</div>
							<ul class="social-icons">
								<li class="social-icons-instagram">
									<a href="http://www.instagram.com/" target="_blank" title="Instagram">
										<i class="fab fa-instagram text-4 font-weight-semibold"></i>
									</a>
								</li>
								<li class="social-icons-twitter">
									<a href="http://www.twitter.com/" target="_blank" title="Twitter">
										<i class="fab fa-twitter text-4 font-weight-semibold"></i>
									</a>
								</li>
								<li class="social-icons-facebook">
									<a href="http://www.facebook.com/" target="_blank" title="Facebook">
										<i class="fab fa-facebook-f text-4 font-weight-semibold"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="col-sm-6 pt-5 pt-md-0 col-lg-4">
							<div class="nav-footer-container">
								<h4 class="mb-4 text-uppercase">Medical Services</h4>
								<div class="nav-footer d-flex">
									<ul>
										<li>
											<a href="#">Home</a>
										</li>
										<li>
											<a href="#">About Us</a>
										</li>
										<li>
											<a href="#">Our Doctors</a>
										</li>
										<li>
											<a href="#">Departments</a>
										</li>
										<li>
											<a href="#">Overview</a>
										</li>
										<li>
											<a href="#">Cardiology</a>
										</li>
										<li>
											<a href="#">Gastroenterology</a>
										</li>
										<li>
											<a href="#">Pulmonology</a>
										</li>
										<li>
											<a href="#">Dental Care</a>
										</li>
										<li>
											<a href="#">Gynecology</a>
										</li>										
									</ul>
									<ul class="pl-4">
										<li>
											<a href="#">Hepatology</a>
										</li>
										<li>
											<a href="#">Gastroenterology</a>
										</li>
										<li>
											<a href="#">Pulmonology</a>
										</li>
										<li>
											<a href="#">Blog</a>
										</li>
										<li>
											<a href="#">Contact Us</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-12 pt-4 pt-lg-0 col-lg-3 text-left ml-lg-auto footer-column footer-column-opening-hours">
							<h4 class="mb-4 text-uppercase">Opening Hours</h4>
							<div class="info custom-info pt-0">
								<span>Mon-Fri</span>
								<span>8:30 am to 5:00 pm</span>
							</div>
							<div class="info custom-info">
								<span>Saturday</span>
								<span>9:30 am to 1:00 pm</span>
							</div>
							<div class="info custom-info pb-0 border-bottom-0">
								<span>Sunday</span>
								<span>Closed</span>
							</div>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-24')
			</footer>
@endsection
