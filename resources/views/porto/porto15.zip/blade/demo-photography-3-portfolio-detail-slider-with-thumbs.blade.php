@extends('porto.app')
@section('header')
<header id="header" class="side-header d-flex">
				<div class="header-body">
					<div class="header-container container d-flex h-100">
						<div class="header-column flex-row flex-lg-column justify-content-center h-100">
							<div class="header-row flex-row justify-content-start justify-content-lg-center py-lg-5">
								@include('porto.partials.header-logo.header-logo-32')
							</div>
							<div class="header-row header-row-side-header flex-row h-100 overflow-hidden pb-lg-5">
								@include('porto.partials.header-nav.header-nav-171')
							</div>
							<div class="header-row justify-content-end pb-lg-3">
								@include('porto.partials.header-social-icons.header-social-icons-14')
								<p class="d-none d-lg-block text-1 pt-3">© 2021 PORTO. All rights reserved</p>
								<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
									<i class="fas fa-bars"></i>
								</button>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main no-height" id="main">
				
				<div class="container pt-4">

					<div id="portfolioSliderWithThumbs">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div style="background: url('img/demos/photography/gallery/family/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/3.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/1.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/2.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/3.jpg');"></div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs" id="thumbGalleryThumbs">
								<div style="background: url('img/demos/photography/gallery/family/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/family/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/travel/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/lifestyle/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/landscape/3-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/1-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/2-thumb.jpg');"></div>
								<div style="background: url('img/demos/photography/gallery/wedding/3-thumb.jpg');"></div>
							</div>
						</div>
					</div>
				
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
