@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': false, 'stickyEnableOnMobile': true, 'stickyStartAt': 70, 'stickyChangeLogo': false, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0 box-shadow-none">
					<div class="header-container header-container-md container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav')
									<div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">porto.partialsporto.partials
										@include('porto.partials.header-nav-feature.header-nav-feature')
										@include('porto.partials.header-nav-feature.header-nav-feature-1')
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('mainporto.partials
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-217')

				<div class="container container-lg-custom py-4">
					<div class="row align-items-center">
						<div class="col center">
							<div class="row">
								<div class="col">
									<div class="tabs tabs-bottom tabs-center tabs-simple">
										<ul class="nav nav-tabs">
											<li class="nav-item active">
												<a class="nav-link" href="#tabHeaders" data-toggle="tab">Headers</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabSideHeaders" data-toggle="tab">Side Headers</a>
											</li>
										</ul>
										<div class="tab-content">
											<div class="tab-pane active" id="tabHeaders">
												<div class="row justify-content-center">
													<div class="col-12 col-lg-9 text-center">
														<div class="owl-carousel mt-2 mb-0 show-nav-title show-nav-title-both-sides show-nav-title-both-sides-style-2 stage-margin" data-plugin-options="{'items': 1, 'margin': 10, 'loop': true, 'nav': true, 'dots': false, 'stagePadding': 40, 'autoHeight': true, 'lazyLoad': true, 'lazyLoadEager': true}">

															<div>
																<a href="feature-headers-classic.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Classic</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/classic.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">1/53</p>
															</div>

															<div>
																<a href="feature-headers-classic-language-dropdown.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Classic + Language Dropdown</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/classic-language-dropdown.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">2/53</p>
															</div>

															<div>
																<a href="feature-headers-classic-big-logo.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Classic + Big Logo</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/classic-big-log.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">3/53</p>
															</div>

															<div>
																<a href="feature-headers-flat.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Flat</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/flat.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">4/53</p>
															</div>

															<div>
																<a href="feature-headers-flat-top-bar.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Flat + Top Bar</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/flat-top-bar.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">5/53</p>
															</div>

															<div>
																<a href="feature-headers-flat-top-bar-top-borders.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Flat + Top Bar Top + Border</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/flat-top-bar-top-borders.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">6/53</p>
															</div>

															<div>
																<a href="feature-headers-flat-colored-top-bar.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Flat Colored + Top Bar</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/flat-colored-top-bar.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">7/53</p>
															</div>

															<div>
																<a href="feature-headers-flat-borders.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Flat + Borders</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/flat-borders.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">8/53</p>
															</div>

															<div>
																<a href="feature-headers-center.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Center</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/center.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">9/53</p>
															</div>

															<div>
																<a href="feature-headers-center-double-navs.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Center + Double Navs</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/center-double-navs.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">10/53</p>
															</div>

															<div>
																<a href="feature-headers-center-nav-buttons.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Center + Nav + Buttons</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/center-nav-buttons.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">11/53</p>
															</div>

															<div>
																<a href="feature-headers-center-below-slider.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Center Below Slider</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/center-below-slider.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">12/53</p>
															</div>

															<div>
																<a href="feature-headers-floating-bar.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Floating Bar</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/floating-bar.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">13/53</p>
															</div>

															<div>
																<a href="feature-headers-floating-icons.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Floating Icons</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/floating-icons.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">14/53</p>
															</div>

															<div>
																<a href="feature-headers-below-slider.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Below Slider</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/below-slider.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">15/53</p>
															</div>

															<div>
																<a href="feature-headers-full-video.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Video</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-video.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">16/53</p>
															</div>

															<div>
																<a href="feature-headers-narrow.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Narrow</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/narrow.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">17/53</p>
															</div>

															<div>
																<a href="feature-headers-sticky-shrink.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Sticky Shirnk</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/sticky-shirnk.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">18/53</p>
															</div>

															<div>
																<a href="feature-headers-sticky-static.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Sticky Static</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/sticky-static.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">19/53</p>
															</div>

															<div>
																<a href="feature-headers-sticky-change-logo.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Sticky Change Logo</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/sticky-change-logo.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">20/53</p>
															</div>

															<div>
																<a href="feature-headers-sticky-reveal.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Sticky Reveal</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/sticky-reveal.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">21/53</p>
															</div>

															<div>
																<a href="feature-headers-transparent-light.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Transparent Light</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/transparent-light.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">22/53</p>
															</div>

															<div>
																<a href="feature-headers-transparent-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Transparent Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/transparent-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">23/53</p>
															</div>

															<div>
																<a href="feature-headers-transparent-light-bottom-border.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Transparent Light + Bottom Border</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/transparent-light-bottom-border.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">24/53</p>
															</div>

															<div>
																<a href="feature-headers-transparent-dark-bottom-border.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Transparent Dark + Bottom Border</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/transparent-dark-bottom-border.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">25/53</p>
															</div>

															<div>
																<a href="feature-headers-transparent-bottom-slider.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Transparent Bottom Slider</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/transparent-bottom-slider.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">26/53</p>
															</div>

															<div>
																<a href="feature-headers-semi-transparent-light.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Semi Transparent Light</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/semi-transparent-light.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">27/53</p>
															</div>

															<div>
																<a href="feature-headers-semi-transparent-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Semi Transparent Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/semi-transparent-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">28/53</p>
															</div>

															<div>
																<a href="feature-headers-semi-transparent-bottom-slider.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Semi Transparent Bottom Slider</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/semi-transparent-bottom-slider.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">29/53</p>
															</div>

															<div>
																<a href="feature-headers-semi-transparent-top-bar-borders.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Semi Transparent + Top Bar + Borders</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/semi-transparent-top-bar-borders.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">30/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">31/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width-borders.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width + Borders</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width-borders.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">32/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width-transparent-light.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width Transparent Light</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width-transparent-light.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">33/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width-transparent-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width Transparent Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width-transparent-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">34/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width-semi-transparent-light.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width Semi Transparent Light</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width-semi-transparent-light.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">35/53</p>
															</div>

															<div>
																<a href="feature-headers-full-width-semi-transparent-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Full Width Semi Transparent Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/full-width-semi-transparent-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">36/53</p>
															</div>

															<div>
																<a href="feature-headers-navbar.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Navbar</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/navbar.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">37/53</p>
															</div>

															<div>
																<a href="feature-headers-navbar-full.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Navbar Full</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/navbar-full.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">38/53</p>
															</div>

															<div>
																<a href="feature-headers-navbar-pills.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Navbar Pills</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/navbar-pills.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">39/53</p>
															</div>

															<div>
																<a href="feature-headers-navbar-divisors.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Navbar Divisors</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/navbar-divisors.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">40/53</p>
															</div>

															<div>
																<a href="feature-headers-navbar-icons-search.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Navbar + Icons + Search</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/navbar-icons-search.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">41/53</p>
															</div>

															<div>
																<a href="feature-headers-sign-in-sign-up.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Sign In/ Sign Up</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/sign-in-sign-up.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">42/53</p>
															</div>

															<div>
																<a href="feature-headers-logged.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Logged</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/logged.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">43/53</p>
															</div>

															<div>
																<a href="feature-headers-mini-cart.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Mini Cart</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/mini-cart.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">44/53</p>
															</div>

															<div>
																<a href="feature-headers-search-simple-input.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Search Simple Input</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/search-simple-input.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">45/53</p>
															</div>

															<div>
																<a href="feature-headers-search-simple-input-reveal.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Search Simple Input Reveal</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/search-simple-input-reveal.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">46/53</p>
															</div>

															<div>
																<a href="feature-headers-search-dropdown.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Search Dropdown</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/search-dropdown.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">47/53</p>
															</div>

															<div>
																<a href="feature-headers-search-big-input-hidden.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Search Big Input Hidden</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/search-big-input-hidden.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">48/53</p>
															</div>

															<div>
																<a href="feature-headers-search-full-screen.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Search Full Screen</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/search-full-screen.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">49/53</p>
															</div>

															<div>
																<a href="feature-headers-extra-big-icon.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Extra Big Icon</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/extra-big-icon.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">50/53</p>
															</div>

															<div>
																<a href="feature-headers-extra-big-icons-top.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Extra Big Icons Top</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/extra-big-icons-top.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">51/53</p>
															</div>

															<div>
																<a href="feature-headers-extra-button.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Extra Button</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/extra-button.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">52/53</p>
															</div>

															<div>
																<a href="feature-headers-extra-background-color.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Extra Background Color</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/headers/extra-background-color.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">53/53</p>
															</div>

														</div>
													</div>
												</div>

												<div class="row pt-5 pb-4">
													<div class="col-sm-3">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-headers-classic.html">Classic</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-classic-language-dropdown.html">Classic + Language Dropdown</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-classic-big-logo.html">Classic + Big Logo</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-flat.html">Flat</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-flat-top-bar.html">Flat + Top Bar</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-flat-top-bar-top-borders.html">Flat + Top Bar Top + Border</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-flat-colored-top-bar.html">Flat Colored + Top Bar</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-flat-borders.html">Flat + Borders</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-center.html">Center</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-center-double-navs.html">Center + Double Navs</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-center-nav-buttons.html">Center + Nav + Buttons</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-center-below-slider.html">Center Below Slider</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-floating-bar.html">Floating Bar</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-floating-icons.html">Floating Icons</a>
															</li>

														</ul>
													</div>
													<div class="col-sm-3">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-headers-below-slider.html">Below Slider</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-video.html">Full Video</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-narrow.html">Narrow</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-sticky-shrink.html">Sticky Shirnk</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-sticky-static.html">Sticky Static</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-sticky-change-logo.html">Sticky Change Logo</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-sticky-reveal.html">Sticky Reveal</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-transparent-light.html">Transparent Light</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-transparent-dark.html">Transparent Dark</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-transparent-light-bottom-border.html">Transparent Light + Bottom Border</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-transparent-dark-bottom-border.html">Transparent Dark + Bottom Border</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-transparent-bottom-slider.html">Transparent Bottom Slider</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-semi-transparent-light.html">Semi Transparent Light</a>
															</li>

														</ul>
													</div>
													<div class="col-sm-3">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-headers-semi-transparent-dark.html">Semi Transparent Dark</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-semi-transparent-bottom-slider.html">Semi Transparent Bottom Slider</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-semi-transparent-top-bar-borders.html">Semi Transparent + Top Bar + Borders</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width.html">Full Width</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width-borders.html">Full Width + Borders</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width-transparent-light.html">Full Width Transparent Light</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width-transparent-dark.html">Full Width Transparent Dark</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width-semi-transparent-light.html">Full Width Semi Transparent Light</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-full-width-semi-transparent-dark.html">Full Width Semi Transparent Dark</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-navbar.html">Navbar</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-navbar-full.html">Navbar Full</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-navbar-pills.html">Navbar Pills</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-navbar-divisors.html">Navbar Divisors</a>
															</li>

														</ul>
													</div>
													<div class="col-sm-3">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-headers-navbar-icons-search.html">Navbar + Icons + Search</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-sign-in-sign-up.html">Sign In/ Sign Up</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-logged.html">Logged</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-mini-cart.html">Mini Cart</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-search-simple-input.html">Search Simple Input</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-search-simple-input-reveal.html">Search Simple Input Reveal</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-search-dropdown.html">Search Dropdown</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-search-big-input-hidden.html">Search Big Input Hidden</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-search-full-screen.html">Search Full Screen</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-extra-big-icon.html">Extra Big Icon</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-extra-big-icons-top.html">Extra Big Icons Top</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-extra-button.html">Extra Button</a>
															</li>

															<li>
																<a class="d-block" href="feature-headers-extra-background-color.html">Extra Background Color</a>
															</li>

														</ul>
													</div>
												</div>

											</div>
											<div class="tab-pane" id="tabSideHeaders">
												<div class="row justify-content-center">
													<div class="col-12 col-lg-9 text-center">
														<div class="owl-carousel mt-2 mb-0 show-nav-title show-nav-title-both-sides show-nav-title-both-sides-style-2 stage-margin" data-plugin-options="{'items': 1, 'margin': 10, 'loop': true, 'nav': true, 'dots': false, 'stagePadding': 40, 'autoHeight': true, 'lazyLoad': true, 'lazyLoadEager': true}">

															<div>
																<a href="feature-headers-side-header-left-dropdown.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Dropdown</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-dropdown.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">1/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-left-expand.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Expand</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-expand.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">2/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-left-columns.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Columns</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-columns.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">3/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-left-slide.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Slide</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-slide.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">4/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-left-semi-transparent.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Semi Transparent</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-semi-transparent.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">5/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-left-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Left Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-left-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">6/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-dropdown.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Dropdown</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-dropdown.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">7/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-expand.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Expand</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-expand.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">8/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-columns.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Columns</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-columns.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">9/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-slide.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Slide</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-slide.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">10/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-semi-transparent.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Semi Transparent</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-semi-transparent.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">11/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-right-dark.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Right Dark</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-right-dark.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">12/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-offcanvas-push.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Offcanvas Push</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-offcanvas-push.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">13/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-offcanvas-slide.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Offcanvas Slide</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-offcanvas-slide.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">14/15</p>
															</div>

															<div>
																<a href="feature-headers-side-header-narrow-bar.html" target="_blank" class="text-decoration-none">
																	<h4 class="text-3">Side Header Narrow Bar</h4>
																	<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/side-headers/side-header-narrow-bar.jpg">
																</a>
																<p class="text-1 opacity-7 pt-2 mb-0">15/15</p>
															</div>

														</div>
													</div>
												</div>

												<div class="row pt-5 pb-4">
													<div class="col-sm-6">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-page-headers-classic-small.html">Classic Small</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-classic-medium.html">Classic Medium</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-classic-large.html">Classic Large</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-modern-small.html">Modern Small</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-modern-medium.html">Modern Medium</a>
															</li>

															porto.partials
																<a class="d-block" href="feature-page-headers-modern-large.html">Modern Large</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-colors-primary.html">Colors Primary</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-colors-secondary.html">Colors Secondary</a>
															</li>

														</ul>
													</div>
													<div class="col-sm-6">
														<ul class="list list-unstyled list-borders text-2 text-center">

															<li>
																<a class="d-block" href="feature-page-headers-colors-tertiary.html">Colors Tertiary</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-colors-quaternary.html">Colors Quartenary</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-colors-light.html">Colors Light</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-colors-dark.html">Colors Dark</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-title-position-left-small.html">Title Position Left Small</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-title-position-left-medium.html">Title Position Left Medium</a>
															</li>

															<li>
																<a class="d-block" href="feature-page-headers-title-position-left-large.html">Title Position Left Large</a>
															</li>

														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>			
						</div>
					</div>

				</div>
			</div>
@endsection

@section('footer')
<footer id="footer" class="footer-texts-more-lighten">
				<div class="container">
					<div class="row py-4 my-5">
						<div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
							<h5 class="text-4 text-color-light mb-3">CONTACT INFO</h5>
							<ul class="list list-unstyled">
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">ADDRESS</span> 
									1234 Street Name, City, State, USA
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">PHONE</span>
									<a href="tel:+1234567890">Toll Free (123) 456-7890</a>
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">EMAIL</span>
									<a href="mailto:mail@example.com">mail@example.com</a>
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">WORKING DAYS/HOURS </span>
									Mon - Sun / 9:00AM - 8:00PM
								</li>
							</ul>
							<ul class="social-icons social-icons-clean-with-border social-icons-medium">
								<li class="social-icons-instagram">
									<a href="http://www.instagram.com/" class="no-footer-css" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
								</li>
								<li class="social-icons-twitter mx-2">
									<a href="http://www.twitter.com/" class="no-footer-css" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
								</li>
								<li class="social-icons-facebook">
									<a href="http://www.facebook.com/" class="no-footer-css" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
								</li>
							</ul>
						</div>
						<div class="col-md-6 col-lg-2 mb-5 mb-lg-0">
							<h5 class="text-4 text-color-light mb-3">USEFUL LINKS</h5>
							<ul class="list list-unstyled mb-0">
								<li class="mb-0"><a href="contact-us-1.html">Help Center</a></li>
								<li class="mb-0"><a href="about-us.html">About Us</a></li>
								<li class="mb-0"><a href="contact-us.html">Contact Us</a></li>
								<li class="mb-0"><a href="page-careers.html">Careers</a></li>
								<li class="mb-0"><a href="blog-grid-4-columns.html">Blog</a></li>
								<li class="mb-0"><a href="#">Our Location</a></li>
								<li class="mb-0"><a href="#">Privacy Policy</a></li>
								<li class="mb-0"><a href="sitemap.html">Sitemap</a></li>
							</ul>
						</div>
						<div class="col-md-6 col-lg-4 mb-5 mb-md-0">
							<h5 class="text-4 text-color-light mb-3">RECENT NEWS</h5>
							<article class="mb-3">
								<a href="blog-post.html" class="text-color-light text-3-5">Why should I buy a Web Template?</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
							<article class="mb-3">
								<a href="blog-post.html" class="text-color-light text-3-5">Creating Amazing Website with Porto</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
							<article>
								<a href="blog-post.html" class="text-color-light text-3-5">Best Practices for Top UI Design</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
						</div>
						<div class="col-md-6 col-lg-3">
							<h5 class="text-4 text-color-light mb-3">SUBSCRIBE NEWSLETTER</h5>
							<p class="mb-2">Get all the latest information on events, sales and offers. Sign up for newsletter:</p>
							<div class="alert alert-success d-none" id="newsletterSuccess">
								<strong>Success!</strong> You've been added to our email list.
							</div>
							<div class="alert alert-danger d-none" id="newsletterError"></div>
							<form id="newsletterForm" class="form-style-5 opacity-10" action="php/newsletter-subscribe.php" method="POST">
								<div class="form-row">
									<div class="form-group col">
										<input class="form-control" placeholder="Email Address" name="newsletterEmail" id="newsletterEmail" type="text">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<button class="btn btn-primary btn-rounded btn-px-4 btn-py-2 font-weight-bold" type="submit">SUBSCRIBE</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="container">
					@include('porto.partials.footer-copyright.footer-copyright')
				</div>
			</footer>
@endsection
