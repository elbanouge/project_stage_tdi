@extends('porto.app')
@section('header')
<header id="header" class="header-floating-bar header-floating-bar-static-sticky" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'reveal', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0px', 'stickyChangeLogo': false}">
				<div class="header-body bg-color-dark box-shadow-none">
					<div class="header-container header-container-height-sm container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-22')
								</div>
							</div>
							<div class="header-column justify-content-end mr-lg-4">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-110')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				<section class="section section-no-border section-light custom-padding-top-1 mb-0">
					<div class="container">
						<div class="row">
							<div class="col">
								<h1 class="font-weight-bold text-color-primary mt-4 mb-0">Pricing</h1>
								<h4 class="font-weight-bold text-color-quaternary">The perfect plan for you</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean aliquet laoreet lorem, a imperdiet sapien tincidunt at. Vivamus sed libero ut diam feugiat sagittis sit amet in justo.</p>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-quaternary section-center section-no-border m-0">
					<div class="container">						
						<div class="row justify-content-center">
							<div class="col-sm-9 col-md-7 col-lg-4 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="0">
								@include('porto.partials.thumb-info.thumb-info-139')
							</div>
							<div class="col-sm-9 col-md-7 col-lg-4 custom-sm-margin-1 custom-xs-margin-2 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="1000">
								@include('porto.partials.thumb-info.thumb-info-140')
							</div>
							<div class="col-sm-9 col-md-7 col-lg-4 custom-sm-margin-1 custom-xs-margin-2 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="2000">
								@include('porto.partials.thumb-info.thumb-info-141')
							</div>
						</div>
					</div>
				</section>

				<section class="section section-center section-no-border section-light">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-md-8 col-lg-4">
								<img src="img/demos/gym/icons/trainer-colored.png" class="mb-2" alt>
								<h2 class="font-weight-bold text-color-quaternary">Trainers</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit, felis nec gravida lobortis, est felis convallis lacus, vitae commodo metus ipsum.</p>
								<a class="btn btn-primary custom-btn-style-1 text-uppercase text-color-light custom-font-weight-medium" href="demo-gym-staff.html" title="Meet The Staff">Meet the Staff</a>
							</div>
							<div class="col-md-8 col-lg-4 custom-sm-margin-1">
								<img src="img/demos/gym/icons/member-colored.png" class="mb-2" alt>
								<h2 class="font-weight-bold text-color-quaternary">Become a Member</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit, felis nec gravida lobortis, est felis convallis lacus, vitae commodo metus ipsum.</p>
								<a class="btn btn-primary custom-btn-style-1 text-uppercase text-color-light custom-font-weight-medium" href="demo-gym-contact-us.html" title="Join Now">Join Now</a>
							</div>
							<div class="col-md-8 col-lg-4 custom-sm-margin-1">
								<img src="img/demos/gym/icons/group-fitness-colored.png" class="mb-2" alt>
								<h2 class="font-weight-bold text-color-quaternary">Group Fitness</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit, felis nec gravida lobortis, est felis convallis lacus, vitae commodo metus ipsum.</p>
								<a class="btn btn-primary custom-btn-style-1 text-uppercase text-color-light custom-font-weight-medium" href="demo-gym-classes.html" title="Learn More">Learn More</a>
							</div>
						</div>
					</div>
				</section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-quaternary">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 text-center">
							<ul class="social-icons custom-social-icons">
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="row mt-2">
						<div class="col-lg-12 text-center">
							<p>2021 © Porto <strong class="text-color-light font-weight-normal">The Gym</strong> Copyright All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
