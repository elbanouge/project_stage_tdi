@extends('porto.app')
@section('header')
<header id="header" class="header-full-width" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-33')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-175')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main" id="main">
				
				<div class="container">

					<div id="photographyLightbox" class="mfp-hide">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs show-thumbs mt" id="thumbGalleryThumbs">
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col">
							<ul id="portfolioVertical">
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-315')
										</a>
									</div>
								</li>
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-316')
										</a>
									</div>
								</li>
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-317')
										</a>
									</div>
								</li>
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-318')
										</a>
									</div>
								</li>
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-319')
										</a>
									</div>
								</li>
								<li>
									<div class="portfolio-vertical-item">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-320')
										</a>
									</div>
								</li>
							</ul>
						</div>
					</div>
				
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
