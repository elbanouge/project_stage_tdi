@extends('porto.app')
@section('header')
<header id="header" class="header-full-width transparent-header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 78, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-31')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-167')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main full-height initial-height" id="main">
				
				<section class="portfolio-parallax parallax section section-text-light section-parallax d-none-plus m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-1.jpg">
					<div class="container-fluid">
						<h2 class="portfolio-parallax-title">The Happy Family</h2>
						<span class="thumb-info-icons position-style-3 text-color-light">
							<span class="thumb-info-icon pictures bg-color-primary">
								53
								<i class="far fa-image"></i>
							</span>
						</span>
					</div>
				</section>
				<div id="photographyLightbox" class="mfp-hide">
					<div class="thumb-gallery">
						<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/wedding/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/wedding/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/wedding/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/landscape/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
								</span>
							</div>
						</div>
						<div class="owl-carousel owl-theme manual thumb-gallery-thumbs show-thumbs mt" id="thumbGalleryThumbs">
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/wedding/1-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/wedding/2-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/wedding/3-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/landscape/2-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block cur-pointer">
									<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
								</span>
							</div>
						</div>
					</div>
				</div>
				<div class="container">
					<div class="row mt-4">
						<div class="col-lg-7">
							<div class="row portfolio-list">
								<div class="col-lg-12">
									<div class="portfolio-detail-image-item mb-4">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-248')
										</a>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="portfolio-detail-image-item mb-4">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-249')
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-5">
							@include('porto.partials.sidebar.sidebar-33')
						</div>
					</div>
					<div class="row mt-4 pt-3">
						<div class="col-lg-5">
							@include('porto.partials.sidebar.sidebar-34')
						</div>
						<div class="col-lg-7">
							<div class="row portfolio-list">
								<div class="col-lg-12">
									<div class="portfolio-detail-image-item mb-4">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-250')
										</a>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="portfolio-detail-image-item mb-4">
										<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
											@include('porto.partials.thumb-info.thumb-info-251')
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<section class="section section-no-background section-no-border mb-0">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-10">
								<div class="owl-carousel owl-theme nav-center custom-carousel-dots-style m-0 p-0" data-plugin-options="{'items': 1, 'responsive': {'479': {'items': 1}, '979': {'items': 1}, '1199': {'items': 1}}, 'margin': 10, 'loop': false, 'dots': true, 'nav': false}">
									<div>
										<div class="col">
											@include('porto.partials.testimonial.testimonial-68')
										</div>
									</div>
									<div>
										<div class="col">
											@include('porto.partials.testimonial.testimonial-69')
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<div class="container p-0">
					<ul id="portfolioGrid" data-grid-sizer=".col-md-4" class="p-0">
						<li class="col-md-8 col-lg-8 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-252')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-253')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-254')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-255')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-256')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-257')
								</a>
							</div>
						</li>
						<li class="col-md-8 col-lg-8 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-258')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-259')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-260')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-261')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-262')
								</a>
							</div>
						</li>
						<li class="col-md-4 isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-263')
								</a>
							</div>
						</li>
					</ul>
				
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
