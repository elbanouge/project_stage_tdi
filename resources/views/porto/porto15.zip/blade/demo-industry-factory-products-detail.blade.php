@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body header-body-bottom-border border-top-0">
					<div class="header-top">
						<div class="container">
							<div class="header-row">
								<div class="header-column justify-content-start">
									<div class="header-row">
										<ul class="list list-unstyled list-inline mb-0">
											<li class="list-inline-item text-color-dark mr-4 mb-0">
												Sales: <a href="tel:+1234567890" class="text-color-dark text-color-hover-primary text-decoration-none"><strong>123-456-789</strong></a>
											</li>
											<li class="list-inline-item text-color-dark d-none d-sm-inline-block mb-0">
												Services: <a href="tel:+1234567890" class="text-color-dark text-color-hover-primary text-decoration-none"><strong>123-456-789</strong></a>
											</li>
										</ul>
									</div>
								</div>
								<div class="header-column justify-content-end">
									<div class="header-row">
										@include('porto.partials.header-social-icons.header-social-icons-9')
										<a href="#" class="btn custom-svg-btn-style-1 custom-svg-btn-style-1-solid custom-svg-btn-style-1-small text-color-light ml-4">
											<svg class="custom-svg-btn-background" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 210 70" preserveaspectratio="none">
												<polygon fill="none" stroke="#D4D4D4" stroke-width="2" stroke-miterlimit="10" points="7,5 185,5 205,34 186,63 7,63 "></polygon>
											</svg>
											GET A QUOTE
											<svg class="custom-svg-btn-arrow" version="1.1" viewbox="0 0 15.698 8.706" width="17" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
												<polygon stroke="#FFF" stroke-width="0.4" fill="#FFF" points="11.354,0 10.646,0.706 13.786,3.853 0,3.853 0,4.853 13.786,4.853 10.646,8 11.354,8.706 15.698,4.353 "></polygon>
											</svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-24')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-122')
									<div class="header-nav-features">
										@include('porto.partials.header-nav-feature.header-nav-feature-11')
									</div>
									<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
										<i class="fas fa-bars"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				@include('porto.partials.page-header.page-header-149')

				<section class="section section-with-shape-divider border-0 pb-2 pb-lg-5 m-0">
					<div class="shape-divider shape-divider-bottom" style="height: 120px;">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 2000 120" preserveaspectratio="xMinYMin">
							<polygon fill="#FFF" points="-11,2 693,112 2019,6 2019,135 -11,135 "></polygon>
						</svg>
					</div>
					<div class="container pt-3 pb-5 mb-5">
						<div class="row mb-lg-4">
							<div class="col">
								<h2 class="text-color-primary font-weight-medium positive-ls-3 text-4 mb-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">WHAT WE DO</h2>
								<h3 class="font-weight-bold text-transform-none text-9 line-height-2 mb-3 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">Automotive</h3>
								<p class="custom-font-secondary custom-font-size-1 line-height-7 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur.</p>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-lg-7 col-xl-6 pr-lg-4 mb-4 mb-lg-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">
								<div class="owl-carousel stage-margin stage-margin-sm nav-style-1 nav-svg-arrows-1 nav-dark custom-stage-outer-box-shadow" data-plugin-options="{'responsive': {'0': {'items': 1}, '476': {'items': 1}, '768': {'items': 1}, '992': {'items': 1}, '1200': {'items': 1}}, 'autoplay': false, 'autoplayTimeout': 5000, 'autoplayHoverPause': true, 'dots': false, 'nav': true, 'loop': true, 'margin': 20, 'stagePadding': 50}">
									<div>
										<img src="img/demos/industry-factory/generic/generic-4.jpg" class="img-fluid" alt="">
									</div>
									<div>
										<img src="img/demos/industry-factory/generic/generic-3.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
							<div class="col-lg-5 col-xl-6">
								<p class="pb-2 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. Vestibulum auctor felis eget orci semper vestibulum. Pellentesque ultricies nibh gravida, accumsan libero luctus, molestie nunc. In nibh ipsum, blandit id faucibus ac, finibus vitae dui. </p>
								<p class="pb-2 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">Vestibulum auctor felis eget orci semper vestibulum. Pellentesque ultricies nibh gravida, accumsan libero luctus, molestie nunc. In nibh ipsum. </p>
								<ul class="list list-icons list-icons-style-2 list-icons-lg custom-list-icons-icon-size pb-1 mb-3">
									<li class="font-weight-semibold text-color-dark appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1400"><i class="fas fa-check text-color-dark border-color-grey-1 top-7"></i> Pellentesque ultricies nibh</li>
									<li class="font-weight-semibold text-color-dark appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1600"><i class="fas fa-check text-color-dark border-color-grey-1 top-7"></i> Ultricies nibh pellen</li>
									<li class="font-weight-semibold text-color-dark appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1800"><i class="fas fa-check text-color-dark border-color-grey-1 top-7"></i> Ultricies nibh pellen</li>
								</ul>
								<a href="#specifications" data-hash data-hash-offset="100" class="custom-read-more btn btn-link d-inline-flex align-items-center font-weight-semibold text-decoration-none pl-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="2000" data-plugin-options="{'accY': 100}">
									VIEW SPECIFICATIONS
									<svg class="ml-2" version="1.1" viewbox="0 0 15.698 8.706" width="17" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
										<polygon stroke="#FFF" stroke-width="0.1" fill="#FFF" points="11.354,0 10.646,0.706 13.786,3.853 0,3.853 0,4.853 13.786,4.853 10.646,8 11.354,8.706 15.698,4.353 "></polygon>
									</svg>
								</a>
							</div>
						</div>
					</div>
				</section>

				<div id="specifications" class="container py-4 my-5">
					<div class="row">
						<div class="col">
							<h3 class="font-weight-bold text-transform-none text-9 line-height-2 pb-2 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Specifications</h3>
						</div>
					</div>
					<div class="row">
						<div class="col">
							<div class="table-responsive appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">
								<table class="table custom-table-style-1">
									<thead>
										<tr>
											<th>Model</th>
											<th>Gauge</th>
											<th>Width</th>
											<th>Length</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
										<tr>
											<td>ABC 123</td>
											<td>12 GA</td>
											<td>55"</td>
											<td>123"</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="section section-with-shape-divider border-0 custom-bg-lighten-grey-1 pt-5 pb-0 m-0">
				<div class="shape-divider shape-divider-reverse-x" style="height: 120px;">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 2000 120" preserveaspectratio="xMinYMin">
						<polygon fill="#FFF" points="-11,2 693,112 2019,6 2019,135 -11,135 "></polygon>
					</svg>
				</div>
				<div class="container pt-lg-5 mt-5">
					<div class="row">
						<div class="col-lg-3 mb-5 mb-lg-0">
							<a href="demo-industry-factory.html">
								<img src="img/demos/industry-factory/logo-light.png" class="img-fluid mt-5 mb-4" alt="Demo Industry &amp; Factory">
							</a>
							<p class="mb-0"><strong class="text-color-light">Porto Industrial, Factory, Manufacturing</strong></p>
							<p>Advanced Template LTD.</p>
							<ul class="social-icons social-icons-medium">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter mx-2"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</div>
						<div class="col-lg-4 offset-lg-1 mb-5 mb-lg-0">
							<h4 class="text-color-light font-weght-bold positive-ls-2 custom-font-size-2">USEFUL LINKS</h4>
							<div class="row">
								<div class="col-md-6">
									<ul class="list list-unstyled mb-0">
										<li class="mb-0"><a href="#">Contact Us</a></li>
										<li class="mb-0"><a href="#">Our Services</a></li>
										<li class="mb-0"><a href="#">Payment Methods</a></li>
										<li class="mb-0"><a href="#">Services Guide</a></li>
										<li class="mb-0"><a href="#">FAQs</a></li>
										<li class="mb-0"><a href="#">Service Support</a></li>
										<li class="mb-0"><a href="#">Privacy</a></li>
										<li class="mb-0"><a href="#">About Porto</a></li>
										<li class="mb-0"><a href="#">Our Guarantees</a></li>
										<li class="mb-0"><a href="#">Terms And Conditions</a></li>
									</ul>
								</div>
								<div class="col-md-6">
									<ul class="list list-unstyled mb-0">
										<li class="mb-0"><a href="#">Privacy Policy</a></li>
										<li class="mb-0"><a href="#">Return Policy</a></li>
										<li class="mb-0"><a href="#">Intellectual Property Claims</a></li>
										<li class="mb-0"><a href="#">Sitemap</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-lg-3 offset-lg-1 mb-5 mb-lg-0">
							<h4 class="text-color-light font-weght-bold positive-ls-2 custom-font-size-2">OPENING HOURS</h4>
							<ul class="list list-unstyled list-inline custom-list-style-1 mb-0">
								<li><a href="#">Mon - Fri: 8:30 am to 5:00 pm</a></li>
								<li><a href="#">Saturday: 9:30 am to 1:00 pm</a></li>
								<li><a href="#">Sunday: Closed</a></li>
							</ul>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-18')
			</footer>
@endsection
