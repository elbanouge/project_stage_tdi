@extends('porto.app')
@section('header')
<header id="header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': false, 'stickyStartAt': 0}">
				<div class="header-body border-top-0">
					<div class="header-container container py-2">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-11')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-49')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-95')

				<section class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row">
							<div class="col">
								<h2 class="font-weight-bold">A place near you</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce efficitur tellus vel sagittis suscipit. Aliquam nec nunc massa. Proin massa lorem, euismod sit amet est sit amet, placerat maximus quam. Sed efficitur metus id nisl tempus vestibulum. Curabitur varius suscipit euismod. Curabitur faucibus, tellus ut tincidunt lacinia, massa arcu tempus mi, vel feugiat massa nunc.</p>
							</div>
						</div>
						<div class="row mt-3">
							<div class="col-lg-6 mb-4 mb-lg-0">
								<div class="custom-thumb-carousel bg-color-light custom-box-shadow">
									<div class="lightbox" data-plugin-options="{'delegate': 'a', 'type': 'image', 'gallery': {'enabled': true}, 'mainClass': 'mfp-with-zoom', 'zoom': {'enabled': false, 'duration': 300}}">
										<div class="owl-carousel owl-theme custom-arrows-style-2" data-plugin-options="{'items': 1, 'loop': false, 'nav': true, 'dots': false}">
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-1.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-1.jpg" alt="Church Image">
												</a>
											</div>
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-2.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-2.jpg" alt="Church Image">
												</a>
											</div>
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-3.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-3.jpg" alt="Church Image">
												</a>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-lg-6 col-sm-6">
											<div class="custom-location">
												<img src="img/demos/church/others/pin.png" alt class="img-fluid">
												<h4 class="font-weight-bold custom-primary-font mb-0">Los Angeles</h4>
												<p>
													Porto Blvd, Suite 100<br>
													Los Angeles/CA<br>
													<a href="#">(view directions)</a>
												</p>
											</div>
										</div>
										<div class="col-lg-6 col-sm-6 pt-4 mt-1 custom-xs-padding-1">
											<span class="custom-phone custom-xs-ml-1">
												<strong>Phone:</strong> 
												<a class="custom-text-color-default" href="tel:+123456789">123-456-7890</a>
											</span>
											<a class="custom-xs-ml-1" href="mailto:church@domain.com">church@domain.com</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="custom-thumb-carousel bg-color-light custom-box-shadow">
									<div class="lightbox" data-plugin-options="{'delegate': 'a', 'type': 'image', 'gallery': {'enabled': true}, 'mainClass': 'mfp-with-zoom', 'zoom': {'enabled': false, 'duration': 300}}">
										<div class="owl-carousel owl-theme custom-arrows-style-2" data-plugin-options="{'items': 1, 'loop': false, 'nav': true, 'dots': false}">
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-4.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-4.jpg" alt="Church Image">
												</a>
											</div>
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-5.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-5.jpg" alt="Church Image">
												</a>
											</div>
											<div>
												<a class="img-thumbnail d-block img-thumbnail-hover-icon" href="img/demos/church/about-us/about-us-location-6.jpg">
													<img class="img-fluid" src="img/demos/church/about-us/about-us-location-6.jpg" alt="Church Image">
												</a>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-lg-6 col-sm-6">
											<div class="custom-location">
												<img src="img/demos/church/others/pin.png" alt class="img-fluid">
												<h4 class="font-weight-bold custom-primary-font mb-0">New York</h4>
												<p>
													Porto Blvd, Suite 100<br>
													New York/NY<br>
													<a href="#">(view directions)</a>
												</p>
											</div>
										</div>
										<div class="col-lg-6 col-sm-6 pt-4 mt-1 custom-xs-padding-1">
											<span class="custom-phone custom-xs-ml-1">
												<strong>Phone:</strong> 
												<a class="custom-text-color-default" href="tel:+123456789">123-456-7890</a>
											</span>
											<a class="custom-xs-ml-1" href="mailto:church@domain.com">church@domain.com</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-tertiary section-no-border m-0">
					<div class="container">
						<div class="row align-items-center">
							<div class="col-lg-10">
								<span class="custom-secondary-font font-weight-bold custom-text-color-1 text-4">First time visitor</span>
								<h2 class="font-weight-bold custom-text-color-1 m-0">Find out more about the Church. <span class="font-weight-normal custom-secondary-font custom-font-italic">You belong here</span></h2>
							</div>
							<div class="col-lg-2 mt-4 mt-lg-0">
								<a href="demo-church-about-us.html" class="btn btn-primary custom-btn-style-1 text-uppercase">Visitors Guide</a>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-no-border custom-position-relative custom-overflow-hidden p-0 m-0">
					<div class="custom-view-our-location text-center">
						<img src="img/demos/church/others/view-our-location.png" alt>
						<a href="#" onclick="initMapAt({latitude: 40.75198, longitude: -73.96978, zoom: 16}, event)" class="custom-view-location custom-secondary-font font-weight-bold text-color-light">View Our Location</a>
					</div>
					<div id="googlemaps" class="google-map"></div>
				</section>

			<footer id="footer" class="bg-color-secondary custom-footer m-0" style="background: url('img/demos/church/footer-bg.jpg'); background-size: cover;">
				<div class="container pt-5">
					<div class="row text-center">
						<div class="col">
							<a href="demo-church.html" class="text-decoration-none">
								<img src="img/demos/church/logo-white.png" width="90" height="41" alt class="img-fluid custom-img-fluid-center">
							</a>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center">
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="fas fa-map-marker-alt text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Porto Church</strong> 
								Porto Church 123 Porto Blvd, Suite 100 New York, NY
							</p>
						</div>
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="far fa-clock text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Join us on Sunday for worship</strong> 
								8.00pm - 9.00pm
							</p>
						</div>
						<div class="col-lg-4">
							<i class="fas fa-phone-volume text-color-primary custom-icon-size-1"></i>
							<p>
								<strong class="text-color-light">Contact us now</strong>
								<a href="tel:+91123456789" class="text-decoration-none custom-text-color-2">Phone : (123) 456-789</a>
								<a href="mail:mail@example.com" class="text-decoration-none custom-text-color-2">Email : mail@example.com</a>
							</p>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center pb-5">
						<div class="col">
							<ul class="social-icons social-icons-clean custom-social-icons mb-3">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
							<p class="text-1 text-color-light opacity-7">© Copyright 2021. All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
		</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-secondary custom-footer m-0" style="background: url('img/demos/church/footer-bg.jpg'); background-size: cover;">
				<div class="container pt-5">
					<div class="row text-center">
						<div class="col">
							<a href="demo-church.html" class="text-decoration-none">
								<img src="img/demos/church/logo-white.png" width="90" height="41" alt class="img-fluid custom-img-fluid-center">
							</a>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center">
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="fas fa-map-marker-alt text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Porto Church</strong> 
								Porto Church 123 Porto Blvd, Suite 100 New York, NY
							</p>
						</div>
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="far fa-clock text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Join us on Sunday for worship</strong> 
								8.00pm - 9.00pm
							</p>
						</div>
						<div class="col-lg-4">
							<i class="fas fa-phone-volume text-color-primary custom-icon-size-1"></i>
							<p>
								<strong class="text-color-light">Contact us now</strong>
								<a href="tel:+91123456789" class="text-decoration-none custom-text-color-2">Phone : (123) 456-789</a>
								<a href="mail:mail@example.com" class="text-decoration-none custom-text-color-2">Email : mail@example.com</a>
							</p>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center pb-5">
						<div class="col">
							<ul class="social-icons social-icons-clean custom-social-icons mb-3">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
							<p class="text-1 text-color-light opacity-7">© Copyright 2021. All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
