@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0">
					<div class="header-top border-bottom-0 bg-color-secondary">
						<div class="container">
							<div class="header-row py-2">
								<div class="header-column justify-content-center justify-content-md-start">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<span class="text-light opacity-7 pl-0">The best place to eat in downtown Porto!</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>
								<div class="header-column justify-content-end d-none d-md-flex">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<a href="tel:123-456-7890"><i class="fab fa-whatsapp text-4 text-color-primary" style="top: 0;"></i> 123-456-7890</a>
												</li>
											</ul>
										</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-36')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-186')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				@include('porto.partials.page-header.page-header-196')

				<section class="section section-default">
					<div class="container">
						<div class="row">
							<div class="col">
								
								<div class="tabs tabs-bottom tabs-center tabs-simple">
									<ul class="nav nav-tabs">
										<li class="nav-item active">
											<a class="nav-link" href="#tabsNavigationSimple1" data-toggle="tab">Lunch</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="#tabsNavigationSimple2" data-toggle="tab">Dinner</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="#tabsNavigationSimple3" data-toggle="tab">Drinks</a>
										</li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane active" id="tabsNavigationSimple1">
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">STARTERS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Consectetur Adipiscing</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$10</span>
														<h4>Adipiscing</h4>
														<p>Lorem, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Pulvinar Magna</h4>
														<p>Lorem, ipsum, dolor sit.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">APPETIZERS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$8</span>
														<h4>Feugiat Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Feugiat</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">MAINS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$18</span>
														<h4>Vestibulum</h4>
														<p>Ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$20</span>
														<h4>Curabitur Pellentesque</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$23</span>
														<h4>Pellentesque</h4>
														<p>Lorem, dolor sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">DESSERT</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Sit Folor</h4>
														<p>Folor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$10</span>
														<h4>Color</h4>
														<p>Color sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Light Amet</h4>
														<p>Amet.</p>
													</div>
												</div>
											</div>
										</div>
										<div class="tab-pane" id="tabsNavigationSimple2">
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">STARTERS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$5</span>
														<h4>Lorem Ipsum</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$7</span>
														<h4>Dolor Sit</h4>
														<p>Lorem, ipsum, dolor sit.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$8</span>
														<h4>Amet</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Consectetur Adipiscing</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$10</span>
														<h4>Adipiscing</h4>
														<p>Lorem, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Pulvinar Magna</h4>
														<p>Lorem, ipsum, dolor sit.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">APPETIZERS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$8</span>
														<h4>Feugiat Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Feugiat</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">ENTREES</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$18</span>
														<h4>Vestibulum</h4>
														<p>Ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$20</span>
														<h4>Curabitur Pellentesque</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$23</span>
														<h4>Pellentesque</h4>
														<p>Lorem, dolor sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">DESSERT</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Sit Folor</h4>
														<p>Folor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$10</span>
														<h4>Color</h4>
														<p>Color sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Light Amet</h4>
														<p>Amet.</p>
													</div>
												</div>
											</div>
										</div>
										<div class="tab-pane" id="tabsNavigationSimple3">
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">COCKTAILS</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Consectetur Adipiscing</h4>
														<p>Lorem, ipsum sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$10</span>
														<h4>Adipiscing</h4>
														<p>Lorem, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Pulvinar Magna</h4>
														<p>Lorem, ipsum, dolor sit.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">BEER</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$8</span>
														<h4>Feugiat Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Feugiat</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 text-center">
													<h4 class="menu-title">WINE</h4>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$8</span>
														<h4>Feugiat Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$9</span>
														<h4>Feugiat</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
												<div class="col-lg-4">
													<div class="menu-item">
														<span class="menu-item-price">$12</span>
														<h4>Nibh</h4>
														<p>Lorem, ipsum, dolor sit, amet.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</section>

				<div class="container">
					<div class="row mt-5 mb-4">
						<div class="col-lg-12 text-center">
							<h4 class="mt-4 mb-2">Special <strong>Menu</strong></h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

							<hr class="custom-divider">

							<ul class="special-menu pb-5">
								<li>
									<img src="img/demos/restaurant/products/product-1.jpg" class="img-fluid" alt="">
									<h3>Monday <em>Special</em></h3>
									<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.</span></p>
									<strong class="special-menu-price text-color-dark">$29</strong>
								</li>
								<li>
									<img src="img/demos/restaurant/products/product-2.jpg" class="img-fluid" alt="">
									<h3>Tuesday <em>Special</em></h3>
									<p><span>Lorem ipsum dolor sit amet. Donec eu pulvinar magna.</span></p>
									<strong class="special-menu-price text-color-dark">$39</strong>
								</li>
								<li>
									<img src="img/demos/restaurant/products/product-3.jpg" class="img-fluid" alt="">
									<h3>Wednesday <em>Special</em></h3>
									<p><span>Lorem ipsum dolor sit amet.</span></p>
									<strong class="special-menu-price text-color-dark">$24</strong>
								</li>
								<li>
									<img src="img/demos/restaurant/products/product-4.jpg" class="img-fluid" alt="">
									<h3>Thursday <em>Special</em></h3>
									<p><span>Lorem ipsum dolor sit amet magna.</span></p>
									<strong class="special-menu-price text-color-dark">$39</strong>
								</li>
								<li>
									<img src="img/demos/restaurant/products/product-5.jpg" class="img-fluid" alt="">
									<h3>Friday <em>Special</em></h3>
									<p><span>Lorem ipsum dolor sit amet adipiscing elit. Donec eu pulvinar magna.</span></p>
									<strong class="special-menu-price text-color-dark">$59</strong>
								</li>
							</ul>

						</div>
					</div>
				</div>
			</div>
@endsection

@section('footer')
<footer id="footer" class="border-top-0 bg-color-secondary mt-0">
				<div class="container">
					<div class="row py-5">
						<div class="col text-center">
							<ul class="footer-social-icons social-icons social-icons-clean social-icons-big social-icons-opacity-light social-icons-icon-light mt-1">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f text-2"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter text-2"></i></a></li>
								<li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in text-2"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-32')
			</footer>
@endsection
