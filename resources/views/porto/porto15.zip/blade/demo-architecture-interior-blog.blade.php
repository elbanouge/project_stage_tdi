@extends('porto.app')
@section('header')
<header id="header" class="side-header-overlay-full-screen side-header-hide" data-plugin-options="{'stickyEnabled': false}">

				<button class="hamburguer-btn hamburguer-btn-light hamburguer-btn-side-header hamburguer-btn-side-header-overlay active" data-set-active="false">
					<span class="close">
						<span></span>
						<span></span>
					</span>
				</button>

				<div class="header-body d-flex h-100">
					<div class="header-column flex-row flex-lg-column justify-content-center h-100">
						<div class="header-container container d-flex h-100">
							<div class="header-row header-row-side-header flex-row h-100 pb-5">
								<div class="side-header-scrollable scrollable colored-slider h-50" data-plugin-scrollable>
									<div class="scrollable-content">
										@include('porto.partials.header-nav.header-nav-11')
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				@include('porto.partials.page-header.page-header-53')

				<section class="section section-height-3 bg-light border-0 m-0">
					<div class="container container-xl-custom">
						<div class="row portfolio-list sort-destination pb-2">

							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-18')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-19')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-20')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-18')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-19')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-20')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-18')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-19')
							</div>
							<div class="col-lg-4 isotope-item text-left">
								@include('porto.partials.portfolio-item.portfolio-item-20')
							</div>

						</div>
					</div>
				</section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-quaternary border-width-1 custom-border-color-grey py-5 mt-0">
				<div class="container container-xl-custom">
					<div class="row justify-content-between">
						<div class="col-auto">
							<ul class="social-icons social-icons-clean social-icons-icon-light">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>
						<div class="col-auto text-right">
							<p class="text-color-light font-weight-light opacity-8 mb-0">Copyrights © 2021 All Rights Reserved by Okler</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
