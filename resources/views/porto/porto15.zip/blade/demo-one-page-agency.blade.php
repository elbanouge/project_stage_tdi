@extends('porto.app')
@section('header')
<header id="header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAtElement': '#header', 'stickySetTop': '0', 'stickyChangeLogo': false}">
				<div class="header-body">
					<div class="header-container container-fluid px-0">
						<div class="header-row">
							<div class="header-column custom-divider-1">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-30')
								</div>
							</div>
							<div class="header-column justify-content-center w-100">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-163')
								</div>
							</div>
							<div class="header-column custom-divider-1 _left justify-content-end">
								<div class="header-row px-4">
									<ul class="social-icons custom-social-icons-style-1 d-none d-md-flex">
										<li class="social-icons-facebook">
											<a href="http://www.facebook.com/" class="text-color-quaternary" target="_blank" title="Facebook">
												<i class="fab fa-facebook-f"></i>
											</a>
										</li>
										<li class="social-icons-twitter">
											<a href="http://www.twitter.com/" class="text-color-quaternary" target="_blank" title="Twitter">
												<i class="fab fa-twitter"></i>
											</a>
										</li>
										<li class="social-icons-linkedin">
											<a href="http://www.linkedin.com/" class="text-color-quaternary" target="_blank" title="Linkedin">
												<i class="fab fa-linkedin-in"></i>
											</a>
										</li>
									</ul>
									<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
										<i class="fas fa-bars"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				
				<div id="home" class="owl-carousel owl-carousel-light owl-carousel-light-init-fadeIn owl-theme manual dots-inside dots-horizontal-center show-dots-hover show-dots-xs dots-light nav-style-1 nav-inside nav-inside-plus nav-light nav-md nav-font-size-md show-nav-hover mb-0" data-plugin-options="{'autoplayTimeout': 7000}" style="height: 100vh;">
					<div class="owl-stage-outer">
						<div class="owl-stage">
										
							<!-- Carousel Slide 1 -->
							@include('porto.partials.owl-item.owl-item-19')

							<!-- Carousel Slide 2 -->
							@include('porto.partials.owl-item.owl-item-20')
						
						</div>
					</div>
					<div class="owl-nav">
						<button type="button" role="presentation" class="owl-prev"></button>
						<button type="button" role="presentation" class="owl-next"></button>
					</div>
				</div>

				<section id="who-we-are" class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Who We Are</h2>
								<p class="custom-section-sub-title">ABOUT PORTO AGENCY</p>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<p>
									<strong class="font-weight-semibold text-color-dark">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas alias id hic odit accusamus veniam illum.</strong><br>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio excepturi voluptatibus ipsum natus molestiae blanditiis pariatur est molestias ex nostrum. Nobis veritatis, deserunt sint! Ipsa labore aliquam, adipisci minus ex, temporibus aliquid, sapiente aspernatur id, facere dolorem magni placeat cum consectetur officiis ducimus.
								</p>
							</div>
							<div class="col-lg-6 custom-margin-3 custom-height text-center">
								<svg id="curved-line-1" class="d-none d-md-block" x="0px" y="0px" width="545px" height="305px" viewbox="0 0 545 305" enable-background="new 0 0 545 305" xml:space="preserve" data-appear-animation-svg="true">
									<circle class="circle appear-animation" data-appear-animation="circle-anim" fill="none" stroke="#231F20" stroke-miterlimit="10" stroke-dasharray="2.0106,1.0053" cx="10.206" cy="9.91" r="8.167"></circle>
									<circle class="circle-dashed" fill="none" stroke="white" stroke-miterlimit="10" stroke-dasharray="3,3" cx="10.206" cy="9.91" r="8.167"></circle>
									<path class="path appear-animation" data-appear-animation="line-anim" data-appear-animation-delay="800" fill="none" stroke="#010101" stroke-miterlimit="10" stroke-dasharray="2.0024,2.0024" d="M11.469,21.046
										c3.191,19.81,32.779,130.736,292.756,87.863c280.979-46.337,240.717,145.948,212.215,185.401"></path>
									<path class="path-dashed" fill="none" stroke="white" stroke-miterlimit="10" stroke-dasharray="3,3" d="M11.469,21.046
											c3.191,19.81,32.779,130.736,292.756,87.863c280.979-46.337,240.717,145.948,212.215,185.401"></path>
								</svg>
								<img src="img/demos/one-page-agency/who-we-are/who-we-are-1.jpg" alt class="custom-image-style-1 _left appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="1300">
								<img src="img/demos/one-page-agency/who-we-are/who-we-are-2.jpg" alt class="custom-image-style-1 _middle appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="1800">
								<img src="img/demos/one-page-agency/who-we-are/who-we-are-3.jpg" alt class="custom-image-style-1 _right appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="2300">
							</div>
						</div>
					</div>
				</section>

				<section class="section parallax section-parallax section-no-border custom-z-index m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/one-page-agency/parallax/parallax-1.jpg">
					<div class="container">
						<div class="row counters custom-counters">
							<div class="col-lg-3 col-sm-6">
								@include('porto.partials.counter.counter-69')
							</div>
							<div class="col-lg-3 col-sm-6">
								@include('porto.partials.counter.counter-70')
							</div>
							<div class="col-lg-3 col-sm-6">
								@include('porto.partials.counter.counter-71')
							</div>
							<div class="col-lg-3 col-sm-6">
								@include('porto.partials.counter.counter-72')
							</div>
						</div>
					</div>
				</section>

				<section id="what-we-do" class="section section-no-border bg-color-light m-0 pb-0">
					<div class="container custom-pos-rel">
						<svg id="curved-line-2" class="d-none d-lg-block" x="0px" y="0px" width="132px" height="225px" viewbox="0 0 132 225" enable-background="new 0 0 132 225" xml:space="preserve" data-appear-animation-svg="true">
							<circle class="circle" fill="none" stroke="#010101" stroke-miterlimit="10" stroke-dasharray="2,2" data-appear-animation="circle-anim" data-appear-animation-delay="1200" cx="120.888" cy="214.023" r="7.688"></circle>
							<circle class="circle-dashed" fill="none" stroke="white" stroke-miterlimit="10" stroke-dasharray="3,3" cx="120.888" cy="214.023" r="7.688"></circle>
							<path class="path" fill="none" stroke="#010101" stroke-miterlimit="10" stroke-dasharray="2,2" data-appear-animation="line-anim-2" d="M113.812,209.406c0,0-193-54.125-72.5-206.125"></path>
							<path class="path-dashed" fill="none" stroke="white" stroke-miterlimit="10" stroke-dasharray="3,3" d="M113.812,209.406c0,0-193-54.125-72.5-206.125"></path>
						</svg>
						<div class="row text-center">
							<div class="col">
								<h2>What We Do</h2>
								<p class="custom-section-sub-title">OUR AMAZING SERVICES</p>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="pr-4">
									<div class="feature-box feature-box-style-2 custom-feature-box-style-1">
		 								<div class="feature-box-icon" style="min-width: 3.4rem;">
		  									<i class="fas fa-object-group text-color-secondary"></i>
		  								</div>
		 								<div class="feature-box-info">
		  									<h4 class="mb-0">WEB DESIGN</h4>
		  									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro dolorem et ut praesentium consectetur, voluptas commodi laboriosam modi suscipit?</p>
		  								</div>
		 							</div>
		 							<div class="feature-box feature-box-style-2 custom-feature-box-style-1">
		 								<div class="feature-box-icon" style="min-width: 3.4rem;">
		  									<i class="fas fa-mobile-alt text-color-secondary _size-1"></i>
		  								</div>
		 								<div class="feature-box-info">
		  									<h4 class="mb-0">MOBILE APPS</h4>
		  									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus tenetur eligendi maxime quasi veritatis modi blanditiis?</p>
		  								</div>
		 							</div>
		 							<div class="feature-box feature-box-style-2 custom-feature-box-style-1">
		 								<div class="feature-box-icon" style="min-width: 3.4rem;">
		  									<i class="fas fa-code text-color-secondary"></i>
		  								</div>
		 								<div class="feature-box-info">
		  									<h4 class="mb-0">WEB DEVELOPMENT + ECOMMERCE</h4>
		  									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, nam harum eos sunt.</p>
		  								</div>
		 							</div>
		 							<a class="btn custom-btn-style-1 custom-margin-1 text-color-dark" href="#contact-us" data-hash>CONTACT US</a>
		 						</div>
							</div>
							<div class="col-lg-6">
								<img src="img/demos/one-page-agency/what-we-do/what-we-do-2.jpg" alt class="custom-image-style-2 _big appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="1500" data-appear-animation-duration="100">
								<img src="img/demos/one-page-agency/what-we-do/what-we-do-1.jpg" alt class="custom-image-style-2 _small appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="1900" data-appear-animation-duration="100" data-plugin-options="{'accY': 100}">
							</div>
						</div>
					</div>
				</section>

				<section class="section section-no-border bg-color-tertiary m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Testimonials</h2>
								<p class="custom-section-sub-title">HAPPY CLIENTS</p>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col">
								<div class="owl-carousel mb-0" data-plugin-options="{'items': 1, 'loop': false, 'dots': false, 'nav': false}">
									<div class="row justify-content-center">
										<div class="col-lg-8">
											@include('porto.partials.testimonial.testimonial-66')
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section id="portfolio" class="section section-no-border bg-color-light m-0 pb-4">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Portfolio</h2>
								<p class="custom-section-sub-title">OUR WORKS</p>
							</div>
						</div>
					</div>
					<div class="container-fluid">
						<div class="row justify-content-center">
							<div class="col">
								<ul class="nav nav-pills sort-source custom-nav-filter custom-center-pills" data-sort-id="portfolio" data-option-key="filter">
									<li class="nav-item active" data-option-value="*"><a class="nav-link active" href="#">SHOW ALL</a></li>
									<li class="nav-item" data-option-value=".website"><a class="nav-link" href="#">WEBSITE</a></li>
									<li class="nav-item" data-option-value=".brands"><a class="nav-link" href="#">BRANDS</a></li>
									<li class="nav-item" data-option-value=".mobile-app"><a class="nav-link" href="#">MOBILE APP</a></li>
									<li class="nav-item" data-option-value=".others"><a class="nav-link" href="#">OTHERS</a></li>
								</ul>
								<div class="sort-destination-loader sort-destination-loader-showing">
									<div id="loadMoreWrapper" class="row image-gallery sort-destination lightbox" data-sort-id="portfolio" data-total-pages="3" data-plugin-options="{'delegate': 'a.lightbox-portfolio', 'type': 'image', 'gallery': {'enabled': true}}">
										<div class="isotope-item col-sm-6 col-lg-3 website p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-201')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 brands p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-3.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-202')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 mobile-app p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-4.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-203')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 others p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-5.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-204')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 website p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-6.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-205')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 website p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-25.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-206')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 others p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-7.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-207')
												</a>
											</div>
										</div>
										<div class="isotope-item col-sm-6 col-lg-3 brands p-0">
											<div class="image-gallery-item mb-0">
												<a href="img/projects/project-1.jpg" class="lightbox-portfolio">
													@include('porto.partials.thumb-info.thumb-info-208')
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="container">
						<div class="container">
							<div id="LoadMoreBtnWrapper" class="row text-center mt-4 pt-4 mb-4">
								<div class="col">
									<div id="loadMoreLoader" class="load-more-loader">
										<div class="bounce-loader">
											<div class="bounce1"></div>
											<div class="bounce2"></div>
											<div class="bounce3"></div>
										</div>
									</div>
									<button id="loadMore" type="button" class="btn custom-btn-style-1 text-color-dark">LOAD MORE</button>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section id="cases" class="section section-no-border bg-color-tertiary m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Cases</h2>
								<p class="custom-section-sub-title">SUCCESFULL PROJECTS</p>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="owl-carousel show-nav-title custom-arrows-style-1" data-plugin-options="{'responsive': {'767': {'items': 1}, '1200': {'items': 3}}, 'margin': 15, 'loop': false, 'dots': false, 'nav': true}">
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-209')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-210')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-211')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-209')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-210')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
									<div class="text-center">
										@include('porto.partials.thumb-info.thumb-info-211')
										<a href="#" class="btn custom-btn-style-1 text-color-dark mt-3">VIEW MORE</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-primary section-no-border m-0">
					<div class="container">
						<div class="row align-items-center">
							<div class="col-lg-6 mb-5 mb-lg-0">
								<img src="img/demos/one-page-agency/purchase/purchase-1.png" alt class="img-fluid">
							</div>
							<div class="col-lg-5">
								<h2 class="text-color-light">Purchase Porto</h2>
								<p class="custom-section-sub-title text-color-light">GET READY NOW</p>
								<p class="text-color-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore iure, incidunt, in aspernatur error nostrum obcaecati velit doloremque praesentium soluta est. Atque, esse expedita, dicta, possimus voluptate alias porro pariatur beatae.</p>
								<a href="#" class="btn custom-btn-style-1 _color-2 text-color-light mt-4">PURCHASE NOW</a>
							</div>
						</div>
					</div>
				</section>

				<section id="our-team" class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Our Team</h2>
								<p class="custom-section-sub-title">THE DREAM TEAM</p>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="owl-carousel custom-arrows-style-1 custom-nav-pos-1 nav-arrows-1 mb-0" data-plugin-options="{'items': 4, 'margin': 40, 'loop': false, 'dots': false, 'nav': true, 'stagePadding': 40}">
									<div>
										@include('porto.partials.thumb-info.thumb-info-215')
										<div id="team-content-1" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-15.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">John Doe</h2>
													<p>CEO &amp; Web Designer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-216')
										<div id="team-content-2" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-19.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Robert Doe</h2>
													<p>Web Designer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-217')
										<div id="team-content-3" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-12.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Brian Doe</h2>
													<p>Developer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-218')
										<div id="team-content-4" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-11.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Greg Doe</h2>
													<p>Marketing</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-219')
										<div id="team-content-5" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-15.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">John Doe</h2>
													<p>CEO &amp; Web Designer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-220')
										<div id="team-content-6" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-19.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Robert Doe</h2>
													<p>Web Designer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-221')
										<div id="team-content-7" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-12.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Brian Doe</h2>
													<p>Developer</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-222')
										<div id="team-content-8" class="dialog dialog-lg zoom-anim-dialog mfp-hide p-5">
											<div class="row">
												<div class="col-lg-4 col-sm-4 mb-4 mb-md-0">
													<img src="img/team/team-11.jpg" class="custom-rounded-image img-fluid mb-4 mt-4" alt="">
													<ul class="social-icons custom-social-icons-style-2 text-center">
														<li class="social-icons-facebook">
															<a href="http://www.facebook.com/" target="_blank" title="Facebook">
																<i class="fab fa-facebook-f"></i>
															</a>
														</li>
														<li class="social-icons-twitter">
															<a href="http://www.twitter.com/" target="_blank" title="Twitter">
																<i class="fab fa-twitter"></i>
															</a>
														</li>
														<li class="social-icons-googleplus">
															<a href="http://www.plus.google.com/" target="_blank" title="Twitter">
																<i class="fab fa-google-plus-g" aria-hidden="true"></i>
															</a>
														</li>
														<li class="social-icons-linkedin">
															<a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
																<i class="fab fa-linkedin-in"></i>
															</a>
														</li>
													</ul>
												</div>
												<div class="col-lg-8 col-sm-8">
													<h2 class="font-weight-semibold text-color-dark">Greg Doe</h2>
													<p>Marketing</p>
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at elementum lacus. Fusce luctus urna ac mauris consequat, ac eleifend odio imperdiet. Sed euismod tempor orci, ullamcorper accumsan justo semper eu. Donec venenatis elit et euismod iaculis. Integer vehicula imperdiet metus at convallis. Donec ullamcorper at nunc lobortis ultricies. Nam tincidunt.</p>	
													<p class="text-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In imperdiet faucibus congue. Donec at volutpat nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas risus dui.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section id="blog" class="section section-no-border bg-color-tertiary m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<h2>Our Blog</h2>
								<p class="custom-section-sub-title">RECENT POSTS</p>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="owl-carousel show-nav-title custom-arrows-style-1" data-plugin-options="{'responsive': {'767': {'items': 1}, '1200': {'items': 3}}, 'margin': 15, 'loop': false, 'dots': false, 'nav': true, 'autoHeight': true}">
									<div>
										@include('porto.partials.thumb-info.thumb-info-223')
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-224')
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-225')
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-223')
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-224')
									</div>
									<div>
										@include('porto.partials.thumb-info.thumb-info-225')
									</div>
								</div>
							</div>
						</div>
						<div class="row text-center">
							<div class="col">
								<a href="#" class="btn custom-btn-style-1 text-color-dark">VIEW OUR BLOG</a>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row">
							<div class="col-6 col-md-4 col-lg-2 custom-margin-4-sm">
								<img src="img/logos/logo-1.png" alt class="img-fluid">
							</div>
							<div class="col-6 col-md-4 col-lg-2 custom-margin-4-sm">
								<img src="img/logos/logo-2.png" alt class="img-fluid">
							</div>
							<div class="col-6 col-md-4 col-lg-2 custom-margin-4-sm">
								<img src="img/logos/logo-3.png" alt class="img-fluid">
							</div>
							<div class="col-6 col-md-4 col-lg-2 custom-margin-4-sm">
								<img src="img/logos/logo-4.png" alt class="img-fluid">
							</div>
							<div class="col-6 col-md-4 col-lg-2">
								<img src="img/logos/logo-5.png" alt class="img-fluid">
							</div>
							<div class="col-6 col-md-4 col-lg-2">
								<img src="img/logos/logo-6.png" alt class="img-fluid">
							</div>
						</div>
					</div>
				</section>

				<!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
				<div id="googlemaps" class="google-map m-0 custom-contact-pos"></div>

				<section class="section section-no-border bg-color-quaternary m-0 p-0">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-lg-5 custom-contact-box custom-contact-pos bg-color-quaternary">
								<h2 class="text-color-light">Contact Us</h2>
								<div class="feature-box feature-box-style-2 custom-feature-box-style-2 mb-4">
									<div class="feature-box-icon">
										<i class="icon-call-in icons text-color-secondary"></i>
									</div>
									<div class="feature-box-info">
										<h6 class="mb-0 text-2">Call us</h6>
										<a href="tel:+88934567898" class="text-color-light text-decoration-none">+800 123 4567</a>
									</div>
								</div>
								<div class="feature-box feature-box-style-2 custom-feature-box-style-2 mb-4">
									<div class="feature-box-icon">
										<i class="icon-location-pin icons text-color-secondary"></i>
									</div>
									<div class="feature-box-info">
										<h6 class="mb-0 text-2">Our Location</h6>
										<p class="tall text-color-light">123 PORTO AVE PORTO, 1235</p>
									</div>
								</div>
								<h5 class="text-color-light">SEND A MESSAGE</h5>
								<form class="contact-form custom-contact-form-style-1" action="php/contact-form.php" method="POST">
									<div class="contact-form-success alert alert-success d-none mt-4">
										<strong>Success!</strong> Your message has been sent to us.
									</div>

									<div class="contact-form-error alert alert-danger d-none mt-4">
										<strong>Error!</strong> There was an error sending your message.
										<span class="mail-error-message text-1 d-block"></span>
									</div>

									<input type="hidden" name="subject" value="Contact Message Received">
									<div class="form-row _divider">
										<div class="form-group col-sm-6">
											<input type="text" value="" maxlength="100" class="form-control" name="name" placeholder="YOUR NAME" required>
										</div>
										<div class="form-group col-sm-6">
											<input type="text" value="" maxlength="100" class="form-control" name="phone" id="phone" placeholder="PHONE" required>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col">
											<input type="email" value="" maxlength="100" class="form-control" name="email" placeholder="EMAIL ADDRESS" required>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col">
											<textarea maxlength="5000" rows="5" class="form-control custom-textarea-style" name="message" id="message" placeholder="COMMENT" required></textarea>
										</div>
									</div>
									<div class="form-row">
										<div class="col">
											<input type="submit" value="SUBMIT" class="btn btn-primary custom-btn-style-2 text-color-light custom-margin-2 float-right mt-2" data-loading-text="Loading...">
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</section>

		</div>
@endsection

@section('footer')
<footer id="footer" class="m-0 p-0">
			@include('porto.partials.footer-copyright.footer-copyright-27')
		</footer>
@endsection
