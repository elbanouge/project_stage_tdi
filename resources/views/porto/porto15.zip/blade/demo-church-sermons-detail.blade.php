@extends('porto.app')
@section('header')
<header id="header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': false, 'stickyStartAt': 0}">
				<div class="header-body border-top-0">
					<div class="header-container container py-2">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-11')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-53')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-102')

				<section class="section section-tertiary section-no-border m-0">
					<div class="container">
						<div class="row text-center">
							<div class="col">
								<ul class="social-icons custom-social-icons-big">
    								<li class="social-icons-youtube">
    									<a href="http://www.youtube.com/" target="_blank" title="Video">
    										<i class="icon-social-youtube icons"></i>
	    									<span class="custom-icon-title text-uppercase">Video</span>
    									</a>
    								</li>
    								<li class="social-icons-soundcloud">
    									<a href="http://www.soundcloud.com/" target="_blank" title="Audio">
    										<i class="icon-social-soundcloud icons"></i>
	    									<span class="custom-icon-title text-uppercase">Audio</span>
    									</a>
    								</li>
    								<li class="social-icons-link">
    									<a href="#" target="_blank" title="Download">
    										<i class="icon-link icons"></i>
	    									<span class="custom-icon-title text-uppercase">Download</span>
    									</a>
    								</li>
     							</ul>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row">
							<div class="col">
								<article class="custom-post-event bg-color-light">
									<div class="post-event-date bg-color-primary text-center">
										<span class="month text-uppercase custom-secondary-font text-color-light">Oct</span>
										<span class="day font-weight-bold text-color-light">10</span>
										<span class="year text-color-light">2021</span>
									</div>
									<div class="post-event-content custom-margin-1">
										<h2 class="font-weight-bold text-color-dark">Mauris ornare semeu lorem</h2>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque tempor dolor ac purus varius placerat. Quisque tortor purus, imperdiet eget feugiat vitae, sodales nec arcu. In porta nunc eget tellus congue consectetur. Donec fringilla, ligula et facilisis elementum, mi eros imperdiet arcu, et faucibus mauris eros ac nisl. Morbi libero nunc, mollis nec suscipit vel, laoreet posuere tortor. Ut egestas.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat, est a finibus lobortis, eros justo rutrum est, in fringilla arcu ligula ornare mauris. Donec efficitur mi eget eros suscipit rhoncus. Nulla aliquet faucibus est, a ornare neque pellentesque quis. Nunc id volutpat magna. Sed tincidunt convallis cursus. Quisque maximus nulla eget turpis condimentum congue. Lorem ipsum.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat, est a finibus lobortis, eros justo rutrum est, in fringilla arcu ligula ornare mauris. Donec efficitur mi eget eros suscipit rhoncus. Nulla aliquet faucibus est, a ornare neque pellentesque quis. Nunc id volutpat magna. Sed tincidunt convallis cursus. Quisque maximus nulla eget turpis condimentum congue. Lorem ipsum.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat, est a finibus lobortis, eros justo rutrum est, in fringilla arcu ligula ornare mauris. Donec efficitur mi eget eros suscipit rhoncus. Nulla aliquet faucibus est, a ornare neque pellentesque quis. Nunc id volutpat magna. Sed tincidunt convallis cursus. Quisque maximus nulla eget turpis condimentum congue. Lorem ipsum.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat, est a finibus lobortis, eros justo rutrum est, in fringilla arcu ligula ornare mauris. Donec efficitur mi eget eros suscipit rhoncus. Nulla aliquet faucibus est, a ornare neque pellentesque quis. Nunc id volutpat magna. Sed tincidunt convallis cursus. Quisque maximus nulla eget turpis condimentum congue. Lorem ipsum.</p>
									</div>

									<div class="post-block post-author custom-margin-1 custom-xs-ml-0 mt-4 clearfix">
										<div class="img-thumbnail d-none d-sm-block custom-thumb-style-1 p-0">
											<a href="blog-post.html">
												<img src="img/demos/church/about-us/about-us-expect-1.jpg" alt class="img-fluid">
											</a>
										</div>
										<h4 class="text-color-dark text-uppercase custom-primary-font custom-line-height-1 text-1 mt-4 mb-0">
											<i class="icon-user icons font-weight-bold text-4 mr-1"></i>
											Author
										</h4>
										<p><strong class="name mb-3 text-color-dark">Joe Albert Doe</strong></p>
									</div>

									<div class="post-block post-comments custom-margin-1 custom-xs-ml-0 mt-1 clearfix">
										<h4 class="font-weight-bold text-color-dark custom-primary-font text-3 pt-2 mb-1">Comments <span class="comments-count">(3)</span>:</h4>

										<ul class="comments custom-comments-style">
											<li>
												<div class="comment">
													<div class="img-thumbnail d-none d-sm-block custom-thumb-style-1 p-0">
														<img class="avatar" alt="" src="img/demos/church/about-us/about-us-staff-2.jpg">
													</div>
													<div class="comment-block">
														<span class="comment-by">
															<strong class="text-uppercase text-color-dark">Henry Doe</strong>
															<span class="float-right">
																<span> <a class="text-1" href="#"><i class="fas fa-reply"></i> Reply</a></span>
															</span>
														</span>
														<p class="text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Mauris ultricies, justo eu convallis placerat, felis enim ornare nisi, vitae mattis nulla ante id dui.</p>
														<span class="date float-right text-1 mb-4">October 12, 2021 at 1:38 pm</span>
													</div>
												</div>

												<ul class="comments reply">
													<li>
														<div class="comment">
															<div class="img-thumbnail d-none d-sm-block custom-thumb-style-1 p-0">
																<img class="avatar" alt="" src="img/demos/church/about-us/about-us-staff-3.jpg">
															</div>
															<div class="comment-block">
																<span class="comment-by">
																	<strong class="text-uppercase text-color-dark">Monica Doe</strong>
																	<span class="float-right">
																		<span> <a class="text-1" href="#"><i class="fas fa-reply"></i> Reply</a></span>
																	</span>
																</span>
																<p class="text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
																<span class="date float-right text-1 mb-4">October 12, 2021 at 1:38 pm</span>
															</div>
														</div>
													</li>
													<li>
														<div class="comment">
															<div class="img-thumbnail d-none d-sm-block custom-thumb-style-1 p-0">
																<img class="avatar" alt="" src="img/demos/church/about-us/about-us-staff-4.jpg">
															</div>
															<div class="comment-block">
																<span class="comment-by">
																	<strong class="text-uppercase text-color-dark">Josie Doe</strong>
																	<span class="float-right">
																		<span> <a class="text-1" href="#"><i class="fas fa-reply"></i> Reply</a></span>
																	</span>
																</span>
																<p class="text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
																<span class="date float-right text-1 mb-4">October 12, 2021 at 1:38 pm</span>
															</div>
														</div>
													</li>
												</ul>
											</li>
											<li>
												<div class="comment">
													<div class="img-thumbnail d-none d-sm-block custom-thumb-style-1 p-0">
														<img class="avatar" alt="" src="img/demos/church/about-us/about-us-staff-5.jpg">
													</div>
													<div class="comment-block">
														<span class="comment-by">
															<strong class="text-uppercase text-color-dark">Robert Doe</strong>
															<span class="float-right">
																<span> <a class="text-1" href="#"><i class="fas fa-reply"></i> Reply</a></span>
															</span>
														</span>
														<p class="text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
														<span class="date float-right text-1 mb-4">October 12, 2021 at 1:38 pm</span>
													</div>
												</div>
											</li>
										</ul>

									</div>

									<div class="post-block post-leave-comment custom-margin-1 custom-xs-ml-0 pt-2">
										<h4 class="font-weight-bold text-color-dark custom-primary-font text-3 mt-3 pt-2 mb-2">Leave a comment:</h4>

										<form id="" action="" method="POST" class="custom-form-style-1">
											<div class="form-row">
												<div class="form-group col-lg-6">
													<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" placeholder="Your Name" required>
												</div>
												<div class="form-group col-lg-6">
													<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control" name="email" placeholder="Your E-mail" required>
												</div>
											</div>
											<div class="form-row">
												<div class="form-group col">
													<textarea maxlength="5000" data-msg-required="Please enter your comment." rows="10" class="form-control" name="comment" id="message" placeholder="Your message" required></textarea>
												</div>
											</div>
											<div class="form-row">
												<div class="form-group col">
													<input type="submit" value="Post Comment" class="btn btn-primary custom-btn-style-1 text-uppercase float-right" data-loading-text="Loading...">
												</div>
											</div>
										</form>
									</div>
								</article>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-tertiary section-no-border m-0">
					<div class="container">
						<div class="row align-items-center">
							<div class="col-lg-10">
								<span class="custom-secondary-font font-weight-bold custom-text-color-1 text-4">First time visitor</span>
								<h2 class="font-weight-bold custom-text-color-1 m-0">Find out more about the Church. <span class="font-weight-normal custom-secondary-font custom-font-italic">You belong here</span></h2>
							</div>
							<div class="col-lg-2 mt-4 mt-lg-0">
								<a href="demo-church-about-us.html" class="btn btn-primary custom-btn-style-1 text-uppercase">Visitors Guide</a>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-no-border custom-position-relative custom-overflow-hidden p-0 m-0">
					<div class="custom-view-our-location text-center">
						<img src="img/demos/church/others/view-our-location.png" alt>
						<a href="#" onclick="initMapAt({latitude: 40.75198, longitude: -73.96978, zoom: 16}, event)" class="custom-view-location custom-secondary-font font-weight-bold text-color-light">View Our Location</a>
					</div>
					<div id="googlemaps" class="google-map"></div>
				</section>

			<footer id="footer" class="bg-color-secondary custom-footer m-0" style="background: url('img/demos/church/footer-bg.jpg'); background-size: cover;">
				<div class="container pt-5">
					<div class="row text-center">
						<div class="col">
							<a href="demo-church.html" class="text-decoration-none">
								<img src="img/demos/church/logo-white.png" width="90" height="41" alt class="img-fluid custom-img-fluid-center">
							</a>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center">
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="fas fa-map-marker-alt text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Porto Church</strong> 
								Porto Church 123 Porto Blvd, Suite 100 New York, NY
							</p>
						</div>
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="far fa-clock text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Join us on Sunday for worship</strong> 
								8.00pm - 9.00pm
							</p>
						</div>
						<div class="col-lg-4">
							<i class="fas fa-phone-volume text-color-primary custom-icon-size-1"></i>
							<p>
								<strong class="text-color-light">Contact us now</strong>
								<a href="tel:+91123456789" class="text-decoration-none custom-text-color-2">Phone : (123) 456-789</a>
								<a href="mail:mail@example.com" class="text-decoration-none custom-text-color-2">Email : mail@example.com</a>
							</p>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center pb-5">
						<div class="col">
							<ul class="social-icons social-icons-clean custom-social-icons mb-3">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
							<p class="text-1 text-color-light opacity-7">© Copyright 2021. All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
		</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-secondary custom-footer m-0" style="background: url('img/demos/church/footer-bg.jpg'); background-size: cover;">
				<div class="container pt-5">
					<div class="row text-center">
						<div class="col">
							<a href="demo-church.html" class="text-decoration-none">
								<img src="img/demos/church/logo-white.png" width="90" height="41" alt class="img-fluid custom-img-fluid-center">
							</a>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center">
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="fas fa-map-marker-alt text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Porto Church</strong> 
								Porto Church 123 Porto Blvd, Suite 100 New York, NY
							</p>
						</div>
						<div class="col-lg-4 custom-sm-margin-bottom-1">
							<i class="far fa-clock text-color-primary custom-icon-size-1"></i>
							<p class="custom-text-color-2">
								<strong class="text-color-light">Join us on Sunday for worship</strong> 
								8.00pm - 9.00pm
							</p>
						</div>
						<div class="col-lg-4">
							<i class="fas fa-phone-volume text-color-primary custom-icon-size-1"></i>
							<p>
								<strong class="text-color-light">Contact us now</strong>
								<a href="tel:+91123456789" class="text-decoration-none custom-text-color-2">Phone : (123) 456-789</a>
								<a href="mail:mail@example.com" class="text-decoration-none custom-text-color-2">Email : mail@example.com</a>
							</p>
						</div>
					</div>
					<hr class="solid tall custom-hr-color-1">
					<div class="row text-center pb-5">
						<div class="col">
							<ul class="social-icons social-icons-clean custom-social-icons mb-3">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
							<p class="text-1 text-color-light opacity-7">© Copyright 2021. All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
