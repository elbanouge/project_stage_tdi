@extends('porto.app')
@section('header')
<header id="header" class="header-full-width" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-33')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-175')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main" id="main">
				
				<div id="photographyLightbox" class="mfp-hide">
					<div class="thumb-gallery">
						<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/travel/2.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
								</span>
							</div>
							<div>
								<span class="img-thumbnail d-block">
									<img alt="Project Image" src="img/demos/photography/gallery/wedding/3.jpg" class="img-fluid">
								</span>
							</div>
						</div>
					</div>
				</div>
				<div id="horizontalScrollBox">
					<div class="content">
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-303')
								</a>
							</div>
						</div>
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-304')
								</a>
							</div>
						</div>
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-305')
								</a>
							</div>
						</div>
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-306')
								</a>
							</div>
						</div>
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-307')
								</a>
							</div>
						</div>
						<div class="horizontal-scroll-item-wrapper">
							<div class="horizontal-scroll-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-308')
								</a>
							</div>
						</div>
					</div>
					<div class="custom-portfolio-navigation">
						<div class="prev"></div>
						<div class="next"></div>
					</div>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
