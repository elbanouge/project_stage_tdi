@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0">
					<div class="header-top header-top-default header-top-borders border-bottom-0 bg-color-light">
						<div class="container h-100">
							<div class="header-row h-100">
								<div class="header-column justify-content-between">
									<div class="header-row">
										<nav class="header-nav-top w-100">
											<ul class="nav nav-pills justify-content-between w-100 h-100">
												<li class="nav-item py-2 d-inline-flex">
													<span class="header-top-phone py-2 d-flex align-items-center text-color-secondary font-weight-semibold text-uppercase">
														<span>
															<img width="15" height="18" src="img/demos/business-consulting-2/icons/phone.svg" alt="Phone">
														</span>
														<a class="text-color-secondary text-color-hover-primary text-decoration-none" href="tel:123-456-7890">(800) 123-4567</a>
													</span>
													<span class="header-top-email px-0 font-weight-normal align-items-center d-none d-xl-flex">
														<span>
															<img width="25" height="18" src="img/demos/business-consulting-2/icons/mail.svg" alt="Mail">
														</span>
														<a class="text-color-secondary text-color-hover-primary text-decoration-none" href="mailto:business@portotheme.com">business@portotheme.com</a>
													</span>
													<span class="header-top-opening-hours px-0 font-weight-normal align-items-center text-color-secondary d-none d-xl-flex">
														<span>
															<img width="19" height="18" src="img/demos/business-consulting-2/icons/calendar.svg" alt="Calendar">
														</span>
														Mon - Sat 9:00am - 6:00pm / Sunday - CLOSED
													</span>
												</li>
												<li class="nav-item nav-item-header-top-socials d-none d-md-flex justify-content-between h-100">
													<span class="header-top-button-make-as-appoitment d-inline-flex align-items-center justify-content-center h-100 p-0 align-top">
														<a href="demo-business-consulting-2-contact-us.html" class="btn-primary d-flex align-items-center justify-content-center h-100 w-100 text-color-light font-weight-semibold text-decoration-none text-uppercase custom-button-header-top">free initial consultation</a>
													</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container bg-color-light">
						<div class="header-row">
							<div class="header-column header-column-logo">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-8')
								</div>
							</div>
							<div class="header-column header-column-nav-menu justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-30')
								</div>
							</div>
							<div class="header-column header-column-search justify-content-center align-items-end">
								<div class="header-nav-features">
									@include('porto.partials.header-nav-feature.header-nav-feature-9')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-73')

				<section class="custom-bg-color-lighter-grey">
					<div class="cards custom-cards h-auto pt-5 pb-4 container appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="100">
						<div class="row bg-color-light cards-container d-flex justify-content-center justify-content-xl-between w-100 mb-5 mx-0 box-shadow-1 p-relative top-0">
							<div class="col-sm-12 col-md-6 col-xl-4 bg-light p-0 shadow-none">
								<div class="card border-radius-0 border-0 shadow-none">
									<div class="card-body d-flex align-items-center justify-content-between flex-column z-index-1">
										<h4 class="card-title mb-4 font-weight-semibold text-color-primary">Get In Touch</h4>

										<strong class="d-block text-secondary text-4">Work Inquiries</strong>
										<p class="d-block m-0">(800) 123-4567</p>

										<strong class="d-block text-secondary text-4 pt-4">Careers &amp; Press</strong>
										<p class="d-block m-0">(800) 123-4568</p>

										<strong class="d-block text-secondary text-4 pt-4">Assistance Hours:</strong>
										<p class="d-block m-0">Mon - Sat 9:00am - 6:00pm</p>
										<p class="d-block m-0">Sunday - CLOSED</p>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-xl-4 bg-light p-0 shadow-none">
								<div class="card border-radius-0 border-0 shadow-none">
									<div class="card-body d-flex align-items-center justify-content-between flex-column z-index-1">
										<h4 class="card-title mb-4 font-weight-semibold text-color-primary">Address and Mail</h4>

										<strong class="d-block text-secondary text-4">Address</strong>
										<p class="d-block m-0">123 Street Name, City, England</p>

										<strong class="d-block text-secondary text-4 pt-4">E-mail</strong>
										<p class="d-block m-0">
											<a class="text-default" href="mailto:business@portotheme.com">business@portotheme.com</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-xl-4 bg-light p-0 shadow-none">
								<div class="card border-radius-0 border-0 shadow-none">
									<div class="card-body d-flex align-items-center justify-content-between flex-column z-index-1 border-right-0">
										<h4 class="card-title mb-4 font-weight-semibold text-color-primary">Social Media</h4>
										<ul class="social-icons custom-social-icons p-0 pt-3 m-0">
											<li class="m-0 d-block pb-2 social-icons-instagram">
												<a class="custom-bg-color-light-grey" href="http://www.instagram.com/" target="_blank" title="Instagram">
													<i class="fab fa-instagram text-4 font-weight-semibold text-color-secondary"></i>
												</a>
											</li>
											<li class="m-0 d-block pb-2 social-icons-twitter">
												<a class="custom-bg-color-light-grey" href="http://www.twitter.com/" target="_blank" title="Twitter">
													<i class="fab fa-twitter text-4 font-weight-semibold text-color-secondary"></i>
												</a>
											</li>
											<li class="m-0 d-block pb-2 social-icons-facebook">
												<a class="custom-bg-color-light-grey" href="http://www.facebook.com/" target="_blank" title="Facebook">
													<i class="fab fa-facebook-f text-4 font-weight-semibold text-color-secondary"></i>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section></div>
@endsection

@section('footer')
<footer id="footer" class="m-0 border-0 bg-color-quaternary overflow-hidden">
				<div class="container">
					<div class="row py-5 custom-row-footer">
						<div class="col-12 col-sm-12 col-lg-3 d-flex align-items-start flex-column footer-column custom-footer-column-logo">
							<img width="123" height="32" src="img/demos/business-consulting-2/logos/porto.png" alt="Logo Footer">
							<p class="d-block m-0 text-color-default">Lorem ipsum dolor sit amet, conse adipiscing elit. Nunc viverra lorem ipsum erat orci, ac auctor.</p>
						</div>
						<div class="col-12 col-sm-12 col-lg-9 footer-column">
							<div class="d-flex align-items-start align-sm-items-end justify-content-between flex-column h-100 mt-4 mt-sm-0">
								<div class="d-flex flex-nowrap flex-lg-wrap justify-content-start justify-content-lg-end align-items-start align-items-lg-center w-100 flex-column flex-lg-row mt-4 mt-lg-0 custom-container-info-socials">
									<ul class="nav nav-pills justify-content-between h-100 mb-4 mb-lg-0">
										<li class="nav-item d-inline-flex flex-column flex-lg-row">
											<span class="footer-nav-phone py-2 d-flex align-items-center text-color-secondary font-weight-semibold text-uppercase justify-content-start mb-2 mb-lg-0">
												<span>
													<img width="15" height="18" src="img/demos/business-consulting-2/icons/phone.svg" alt="Phone">
												</span>
												<a class="font-weight-bold text-color-secondary text-color-hover-primary text-decoration-none" href="tel:123-456-7890">(800) 123-4567</a>
											</span>
											<span class="footer-nav-email px-0 font-weight-normal d-flex align-items-center justify-content-start mb-2 mb-lg-0">
												<span>
													<img width="25" height="18" src="img/demos/business-consulting-2/icons/mail.svg" alt="Mail">
												</span>
												<a class="text-color-secondary text-color-hover-primary text-decoration-none" href="mailto:business@portotheme.com">business@portotheme.com</a>
											</span>
											<span class="footer-nav-opening-hours px-0 font-weight-normal d-flex align-items-center text-color-secondary justify-content-start mb-2 mb-lg-0">
												<span>
													<img width="19" height="18" src="img/demos/business-consulting-2/icons/calendar.svg" alt="Calendar">
												</span>
												Mon - Sat 9:00am - 6:00pm / Sunday - CLOSED
											</span>
										</li>
									</ul>
									<ul class="social-icons custom-social-icons">
										<li class="social-icons-instagram">
											<a class="custom-bg-color-light-grey" href="http://www.instagram.com/" target="_blank" title="Instagram">
												<i class="fab fa-instagram text-4 font-weight-semibold text-color-secondary"></i>
											</a>
										</li>
										<li class="social-icons-twitter">
											<a class="custom-bg-color-light-grey" href="http://www.twitter.com/" target="_blank" title="Twitter">
												<i class="fab fa-twitter text-4 font-weight-semibold text-color-secondary"></i>
											</a>
										</li>
										<li class="social-icons-facebook">
											<a class="custom-bg-color-light-grey" href="http://www.facebook.com/" target="_blank" title="Facebook">
												<i class="fab fa-facebook-f text-4 font-weight-semibold text-color-secondary"></i>
											</a>
										</li>
									</ul>
								</div>
								<nav class="nav-footer w-100 d-none d-lg-block">
									<ul class="nav nav-pills justify-content-end" id="mainNav">
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2.html">
												Home
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-about-us.html">
												About Us
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-services.html">
												Services
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-cases.html">
												Cases
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-team.html">
												Team
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-blog.html">
												Blog
											</a>
										</li>
										<li class="dropdown-secondary">
											<a class="nav-link text-color-secondary font-weight-bold letter-spacing-05 text-color-hover-primary" href="demo-business-consulting-2-contact-us.html">
												Contact Us
											</a>
										</li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-8')
			</footer>
@endsection
