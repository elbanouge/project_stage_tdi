@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': false, 'stickyEnableOnMobile': true, 'stickyStartAt': 70, 'stickyChangeLogo': false, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0 box-shadow-none">
					<div class="header-container header-container-md container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav')
									<div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">porto.partialsporto.partials
										@include('porto.partials.header-nav-feature.header-nav-feature')
										@include('porto.partials.header-nav-feature.header-nav-feature-1')
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection
porto.partials
@section('main')
<div role="main" class="main">
				@include('porto.partials.page-header.page-header-214')
	
				<div class="container container-lg-custom py-4">
					<div class="row justify-content-center">
						<div class="col-12 col-lg-9 text-center">
							<div class="owl-carousel mt-2 mb-0 show-nav-title show-nav-title-both-sides show-nav-title-both-sides-style-2 stage-margin" data-plugin-options="{'items': 1, 'margin': 10, 'loop': true, 'nav': true, 'dots': false, 'stagePadding': 40, 'autoHeight': true, 'lazyLoad': true, 'lazyLoadEager': true}">

								<div>
									<a href="feature-footers-classic.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">1/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-advanced.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Advanced</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-advanced.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">2/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-compact.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Compact</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-compact.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">3/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-simple.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Simple</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-simple.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">4/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-locations.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Locations</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-locations.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">5/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-copyright-light.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Copyright Light</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-copyright-light.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">6/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-copyright-dark.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Copyright Dark</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-copyright-dark.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">7/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-copyright-social-icons.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Copyright Social Icons</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-copyright-social-icons.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">8/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-copyright-social-icons.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Classic Copyright Social Icons</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-copyright-social-icons.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">9/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-primary.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Primary</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-primary.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">10/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-secondary.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Secondary</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-secondary.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">11/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-tertiary.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Tertiary</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-tertiary.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">12/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-quaternary.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Quartenary</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-quaternary.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">13/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-light.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Light</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-light.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">14/38</p>
								</div>

								<div>
									<a href="feature-footers-classic-colors-light-simple.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Colors Light Simple</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/classic-colors-light-simple.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">15/38</p>
								</div>

								<div>
									<a href="feature-footers-modern.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">16/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-font-style-alternative.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Font Style Alternative</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-font-style-alternative.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">17/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-clean.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Clean</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-clean.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">18/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-useful-links.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Useful Links</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-useful-links.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">19/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-background-image-simple.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Background Image Simple</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-background-image-simple.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">20/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-background-image-advanced.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Video Simple</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-background-video-simple.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">21/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-call-to-action-button.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Call to Action Button</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-call-to-action-button.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">22/38</p>
								</div>

								<div>
									<a href="feature-footers-modern-call-to-action-simple.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Modern Call to Action Simple</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/modern-call-to-action-simple.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">23/38</p>
								</div>

								<div>
									<a href="feature-footers-blog-classic.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Blog Classic</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/blog-classic.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">24/38</p>
								</div>

								<div>
									<a href="feature-footers-ecommerce-classic.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">eCommerce Classic</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/ecommerce-classic.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">25/38</p>
								</div>

								<div>
									<a href="feature-footers-contact-form-classic.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Contact Form Classic</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/contact-form-classic.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">26/38</p>
								</div>

								<div>
									<a href="feature-footers-contact-form-above-the-map.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Contact Form Above the Map</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/contact-form-above-the-map.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">27/38</p>
								</div>

								<div>
									<a href="feature-footers-contact-form-center.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Contact Form Center</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/contact-form-center.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">28/38</p>
								</div>

								<div>
									<a href="feature-footers-contact-form-columns.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Contact Form Columns</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/contact-form-columns.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">29/38</p>
								</div>

								<div>
									<a href="feature-footers-map-hidden.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Map Hidden</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/map-hidden.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">30/38</p>
								</div>

								<div>
									<a href="feature-footers-map-full-width.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Full Width</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/map-full-width.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">31/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-top-social-icons.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Top Social Icons</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-top-social-icons.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">32/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-big-icons.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Big Icons</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-big-icons.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">33/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-recent-work.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Recent Work</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-recent-work.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">34/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-reveal.html#footeranchor" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Reveal</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-reveal.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">35/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-instagram.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Instagram</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-instagram.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">36/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-full-width-light.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Full Width Light</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-full-width-light.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">37/38</p>
								</div>

								<div>
									<a href="feature-footers-extra-full-width-dark.html#footer" target="_blank" class="text-decoration-none">
										<h4 class="text-3">Full Width Dark</h4>
										<img alt="" class="img-fluid border-all owl-lazy" src="img/blank.gif" data-src="img/previews/footers/extra-full-width-dark.jpg">
									</a>
									<p class="text-1 opacity-7 pt-2 mb-0">38/38</p>
								</div>

							</div>
						</div>
					</div>

					<div class="row pt-5 pb-4">
						<div class="col-sm-4">
							<ul class="list list-unstyled list-borders text-2 text-center">

								<li>
									<a class="d-block" href="feature-footers-classic.html#footer">Classic</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-advanced.html#footer">Classic Advanced</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-compact.html#footer">Classic Compact</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-simple.html#footer">Classic Simple</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-locations.html#footer">Classic Locations</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-copyright-light.html#footer">Classic Copyright Light</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-copyright-dark.html#footer">Classic Copyright Dark</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-copyright-social-icons.html#footer">Classic Copyright Social Icons</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-copyright-social-icons.html#footer">Classic Copyright Social Icons</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-colors-primary.html#footer">Colors Primary</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-colors-secondary.html#footer">Colors Secondary</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-colors-tertiary.html#footer">Colors Tertiary</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-colors-quaternary.html#footer">Colors Quartenary</a>
								</li>

							</ul>
						</div>
						<div class="col-sm-4">
							<ul class="list list-unstyled list-borders text-2 text-center">

								<li>
									<a class="d-block" href="feature-footers-classic-colors-light.html#footer">Colors Light</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-classic-colors-light-simple.html#footer">Colors Light Simple</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern.html#footer">Modern</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-font-style-alternative.html#footer">Modern Font Style Alternative</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-clean.html#footer">Modern Clean</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-useful-links.html#footer">Modern Useful Links</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-background-image-simple.html#footer">Modern Background Image Simple</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-background-image-advanced.html#footer">Modern Video Simple</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-call-to-action-button.html#footer">Modern Call to Action Button</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-modern-call-to-action-simple.html#footer">Modern Call to Action Simple</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-blog-classic.html#footer">Blog Classic</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-ecommerce-classic.html#footer">eCommerce Classic</a>
								</li>

							</ul>
						</div>
						<div class="col-sm-4">
							<ul class="list list-unstyled list-borders text-2 text-center">

								<li>
									<a class="d-block" href="feature-footers-contact-form-classic.html#footer">Contact Form Classic</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-contact-form-above-the-map.html#footer">Contact Form Above the Map</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-contact-form-center.html#footer">Contact Form Center</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-contact-form-columns.html#footer">Contact Form Columns</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-map-hidden.html#footer">Map Hidden</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-map-full-width.html#footer">Full Width</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-top-social-icons.html#footer">Top Social Icons</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-big-icons.html#footer">Big Icons</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-recent-work.html#footer">Recent Work</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-reveal.html#footeranchor">Reveal</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-instagram.html#footer">Instagram</a>
								</li>

								<li>
									<a class="d-block" href="feature-footers-extra-full-width-light.html#footer">Full Width Light</a>
								</li>

							</ul>
						</div>
					</div>
				</div>
			</div>
@endsection

@section('footer')
<footer id="footer" class="footer-texts-more-lighten">
				<div class="container">
					<div class="row py-4 my-5">
						<div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
							<h5 clasporto.partials-light mb-3">CONTACT INFO</h5>
							<ul class="list list-unstyled">
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">ADDRESS</span> 
									1234 Street Name, City, State, USA
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">PHONE</span>
									<a href="tel:+1234567890">Toll Free (123) 456-7890</a>
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">EMAIL</span>
									<a href="mailto:mail@example.com">mail@example.com</a>
								</li>
								<li class="pb-1 mb-2">
									<span class="d-block font-weight-normal line-height-1 text-color-light">WORKING DAYS/HOURS </span>
									Mon - Sun / 9:00AM - 8:00PM
								</li>
							</ul>
							<ul class="social-icons social-icons-clean-with-border social-icons-medium">
								<li class="social-icons-instagram">
									<a href="http://www.instagram.com/" class="no-footer-css" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
								</li>
								<li class="social-icons-twitter mx-2">
									<a href="http://www.twitter.com/" class="no-footer-css" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
								</li>
								<li class="social-icons-facebook">
									<a href="http://www.facebook.com/" class="no-footer-css" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
								</li>
							</ul>
						</div>
						<div class="col-md-6 col-lg-2 mb-5 mb-lg-0">
							<h5 class="text-4 text-color-light mb-3">USEFUL LINKS</h5>
							<ul class="list list-unstyled mb-0">
								<li class="mb-0"><a href="contact-us-1.html">Help Center</a></li>
								<li class="mb-0"><a href="about-us.html">About Us</a></li>
								<li class="mb-0"><a href="contact-us.html">Contact Us</a></li>
								<li class="mb-0"><a href="page-careers.html">Careers</a></li>
								<li class="mb-0"><a href="blog-grid-4-columns.html">Blog</a></li>
								<li class="mb-0"><a href="#">Our Location</a></li>
								<li class="mb-0"><a href="#">Privacy Policy</a></li>
								<li class="mb-0"><a href="sitemap.html">Sitemap</a></li>
							</ul>
						</div>
						<div class="col-md-6 col-lg-4 mb-5 mb-md-0">
							<h5 class="text-4 text-color-light mb-3">RECENT NEWS</h5>
							<article class="mb-3">
								<a href="blog-post.html" class="text-color-light text-3-5">Why should I buy a Web Template?</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
							<article class="mb-3">
								<a href="blog-post.html" class="text-color-light text-3-5">Creating Amazing Website with Porto</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
							<article>
								<a href="blog-post.html" class="text-color-light text-3-5">Best Practices for Top UI Design</a>
								<p class="line-height-2 mb-0"><a href="#">Nov 25, 2020</a> in <a href="#">Design,</a> <a href="#">Coding</a></p>
							</article>
						</div>
						<div class="col-md-6 col-lg-3">
							<h5 class="text-4 text-color-light mb-3">SUBSCRIBE NEWSLETTER</h5>
							<p class="mb-2">Get all the latest information on events, sales and offers. Sign up for newsletter:</p>
							<div class="alert alert-success d-none" id="newsletterSuccess">
								<strong>Success!</strong> You've been added to our email list.
							</div>
							<div class="alert alert-danger d-none" id="newsletterError"></div>
							<form id="newsletterForm" class="form-style-5 opacity-10" action="php/newsletter-subscribe.php" method="POST">
								<div class="form-row">
									<div class="form-group col">
										<input class="form-control" placeholder="Email Address" name="newsletterEmail" id="newsletterEmail" type="text">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<button class="btn btn-primary btn-rounded btn-px-4 btn-py-2 font-weight-bold" type="submit">SUBSCRIBE</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="container">
					@include('porto.partials.footer-copyright.footer-copyright')
				</div>
			</footer>
@endsection
