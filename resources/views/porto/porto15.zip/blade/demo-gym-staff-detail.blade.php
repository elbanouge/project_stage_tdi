@extends('porto.app')
@section('header')
<header id="header" class="header-floating-bar header-floating-bar-static-sticky" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'reveal', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0px', 'stickyChangeLogo': false}">
				<div class="header-body bg-color-dark box-shadow-none">
					<div class="header-container header-container-height-sm container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-22')
								</div>
							</div>
							<div class="header-column justify-content-end mr-lg-4">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-111')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				
				<section class="section section-no-border section-light custom-padding-top-1 mb-0">
					<div class="container">
						<div class="row mt-4">
							<div class="col-md-8 col-lg-9">
								<div class="pr-4">
									<h1 class="font-weight-bold text-color-primary mb-0">Jessica Doe</h1>
									<h4 class="font-weight-bold text-color-quaternary">Personal Trainer</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean aliquet laoreet lorem, a imperdiet sapien tincidunt at. Vivamus sed libero ut diam feugiat sagittis sit amet in justo. Nam quis massa nec lorem tempus egestas at quis eros.</p>
									<p class="text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean aliquet laoreet lorem, a imperdiet sapien tincidunt at. Vivamus sed libero ut diam feugiat sagittis sit amet in justo. Nam quis massa nec lorem tempus egestas at quis eros. Morbi non augue vel tortor feugiat commodo vitae sed dolor. Maecenas a nisi euismod, bibendum arcu quis, posuere massa. Morbi mattis dui sem. Phasellus vel rhoncus ligula.</p>
								</div>
							</div>
							<div class="col-md-4 col-lg-3">
								<div class="owl-carousel custom-dots-bottom-center-1 custom-position-style-1 bg-color-primary p-3" data-plugin-options="{'items': 1, 'loop': false, 'dots': false, 'nav': false, 'autoplay': true, 'autoplayTimeout': 3000}">
									<div>
										<img src="img/demos/gym/staff/staff-detail-1.jpg" alt class="img-fluid">
									</div>
									<div>
										<img src="img/demos/gym/staff/staff-detail-2.jpg" alt class="img-fluid">
									</div>
									<div>
										<img src="img/demos/gym/staff/staff-detail-3.jpg" alt class="img-fluid">
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-quaternary section-text-light m-0">
					<div class="container">
						<div class="row">
							<div class="col">
								<h4 class="font-weight-bold text-color-light">Skills</h4>
							</div>
						</div>
						<div class="row mt-3">
							<div class="col-md-3">
								<ul class="list list-icons list-light text-color-light">
									<li><i class="fas fa-check"></i> Fitness Consultation</li>
									<li><i class="fas fa-check"></i> Professionals</li>
									<li><i class="fas fa-check"></i> Full Cardio</li>
								</ul>
							</div>
							<div class="col-md-3">
								<ul class="list list-icons list-light text-color-light">
									<li><i class="fas fa-check"></i> Conditioning</li>
									<li><i class="fas fa-check"></i> Sports</li>
									<li><i class="fas fa-check"></i> Consultation</li>
								</ul>
							</div>
							<div class="col-md-3">
								<ul class="list list-icons list-light text-color-light">
									<li><i class="fas fa-check"></i> Zumba</li>
									<li><i class="fas fa-check"></i> Nutrition</li>
									<li><i class="fas fa-check"></i> Spin</li>
								</ul>
							</div>
							<div class="col-md-3">
								<ul class="list list-icons list-light text-color-light">
									<li><i class="fas fa-check"></i> TRX</li>
									<li><i class="fas fa-check"></i> Fitness Consultation</li>
								</ul>
							</div>
						</div>
					</div>
				</section>

				<section class="section section-center section-no-border section-light">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-10">
								<h2 class="font-weight-bold text-color-quaternary appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="0"><span class="text-color-primary">Get Up!</span> Challenge yourself today</h2>
								<p class="appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="150">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sed sem ipsum. Proin efficitur dolor accumsan purus varius tempus nec a nulla. Aliquam id vulputate massa, a rhoncus justo. Nunc luctus non ipsum a cursus. Donec laoreet iaculis egestas. Nulla finibus sed ipsum a pretium. Mauris ut nisl nec metus.</p>
								<a class="btn btn-primary custom-btn-style-1 text-uppercase text-color-light custom-font-weight-medium text-2 appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="300" href="demo-gym-about-us.html">About the Gym</a>
							</div>
						</div>
					</div>
				</section>
			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-quaternary">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 text-center">
							<ul class="social-icons custom-social-icons">
								<li class="social-icons-instagram"><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-googleplus"><a href="http://www.google.com/" target="_blank" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="row mt-2">
						<div class="col-lg-12 text-center">
							<p>2021 © Porto <strong class="text-color-light font-weight-normal">The Gym</strong> Copyright All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</footer>
@endsection
