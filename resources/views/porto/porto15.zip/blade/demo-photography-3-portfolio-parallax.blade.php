@extends('porto.app')
@section('header')
<header id="header" class="side-header d-flex">
				<div class="header-body">
					<div class="header-container container d-flex h-100">
						<div class="header-column flex-row flex-lg-column justify-content-center h-100">
							<div class="header-row flex-row justify-content-start justify-content-lg-center py-lg-5">
								@include('porto.partials.header-logo.header-logo-32')
							</div>
							<div class="header-row header-row-side-header flex-row h-100 overflow-hidden pb-lg-5">
								@include('porto.partials.header-nav.header-nav-171')
							</div>
							<div class="header-row justify-content-end pb-lg-3">
								@include('porto.partials.header-social-icons.header-social-icons-14')
								<p class="d-none d-lg-block text-1 pt-3">© 2021 PORTO. All rights reserved</p>
								<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
									<i class="fas fa-bars"></i>
								</button>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main no-height" id="main">
				
				<a href="demo-photography-portfolio-ajax-on-page.html">
					<section class="portfolio-parallax portfolio-parallax-demo-3 parallax section section-text-light section-parallax m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-1.jpg">
						<div class="container-fluid">
							<h2 class="thumb-info-title font-weight-bold">
								Family
								<span class="thumb-info-sub-title font-weight-light">
									50 photos
								</span>
							</h2>
						</div>
					</section>
				</a>
				
				<a href="demo-photography-portfolio-ajax-on-page.html">
					<section class="portfolio-parallax portfolio-parallax-demo-3 parallax section section-text-light section-parallax m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-2.jpg">
						<div class="container-fluid">
							<h2 class="thumb-info-title font-weight-bold">
								Life Style
								<span class="thumb-info-sub-title font-weight-light">
									40 photos
								</span>
							</h2>
						</div>
					</section>
				</a>

				<a href="demo-photography-portfolio-ajax-on-page.html">
					<section class="portfolio-parallax portfolio-parallax-demo-3 parallax section section-text-light section-parallax m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-3.jpg">
						<div class="container-fluid">
							<h2 class="thumb-info-title font-weight-bold">
								Wedding
								<span class="thumb-info-sub-title font-weight-light">
									35 photos
								</span>
							</h2>
						</div>
					</section>
				</a>

				<a href="demo-photography-portfolio-ajax-on-page.html">
					<section class="portfolio-parallax portfolio-parallax-demo-3 parallax section section-text-light section-parallax m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-4.jpg">
						<div class="container-fluid">
							<h2 class="thumb-info-title font-weight-bold">
								Landscape
								<span class="thumb-info-sub-title font-weight-light">
									22 photos
								</span>
							</h2>
						</div>
					</section>
				</a>

				<a href="demo-photography-portfolio-ajax-on-page.html">
					<section class="portfolio-parallax portfolio-parallax-demo-3 parallax section section-text-light section-parallax m-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="img/demos/photography/portfolio/portfolio-parallax-5.jpg">
						<div class="container-fluid">
							<h2 class="thumb-info-title font-weight-bold">
								Travel
								<span class="thumb-info-sub-title font-weight-light">
									16 photos
								</span>
							</h2>
						</div>
					</section>
				</a>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
