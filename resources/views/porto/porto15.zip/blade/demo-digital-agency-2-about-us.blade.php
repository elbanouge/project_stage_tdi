@extends('porto.app')
@section('header')
<header id="header" class="header-transparent header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': false, 'stickyStartAt': 1, 'stickyHeaderContainerHeight': 100}">
				<div class="header-body border-top-0 bg-color-dark box-shadow-none">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column header-column-logo">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-16')
								</div>
							</div>
							<div class="header-column header-column-nav-menu justify-content-end w-100">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-77')
								</div>
							</div>
							<div class="header-column justify-content-end d-none d-lg-flex">
								<div class="header-row">
									@include('porto.partials.header-social-icons.header-social-icons-7')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

				@include('porto.partials.page-header.page-header-118')

								<div class="container p-relative z-index-2 mt-0 mt-lg-3 mt-xl-0 pt-0 pt-md-4 pt-lg-5 pb-xl-5 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">
									<div class="row">
										<div class="col-xl-7 py-4 py-xl-0">
											<img class="img-fluid" src="img/demos/digital-agency-2/about-us/about-us-1.jpg" alt="About Us 1">
										</div>
									</div>
									<div class="row justify-content-end p-relative">
										<div class="col-xl-7">
											<div class="about-us-featured-block w-100 bg-color-primary p-5 text-right custom-title-with-icon custom-title-with-icon-right custom-title-with-icon-light">
												<p class="custom-text-7 text-color-light opacity-7">Welcome to the Age of Digital Transformation</p>
												<h4 class="custom-text-11 text-color-light">Experience Design and<br>Intelligent Marketing.</h4>
											</div>
										</div>
									</div>
									<div class="row justify-content-between mt-5 mt-xl-0 mb-lg-4">
										<div class="col-xl-4 d-flex flex-column justify-content-end">
											<p class="custom-font-tertiary custom-text-7 mb-4">
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut tellus ante. Nam suscipit urna risus.
											</p>
											<p class="custom-text-4 mb-4 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at massa quam. Maecenas et sem accumsan, dictum arcu eu, consectetur eros. Nulla tortor est, lobortis vestibulum turpis sed, mollis commodo orci.
											</p>
											<p class="custom-text-4 mb-0 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">
												Sed elementum cursus ante in suscipit. Etiam a arcu consequat, vehicula nisi in, efficitur lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. In eu lectus ultricies, pellentesque libero vitae, dictum erat. 
											</p>
										</div>
										<div class="col-xl-7 py-4 py-xl-0">
											<img class="img-fluid" src="img/demos/digital-agency-2/about-us/about-us-2.jpg" alt="About Us 2">
											<ul class="custom-list list-unstyled my-3">
												<li class="font-weight-medium custom-text-4 mb-4 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">Porto Digital Agency Bulding, 2021</li>
											</ul>
										</div>
									</div>
								</div>

								<section class="bg-color-dark mb-5 mt-lg-5">
									<div class="container py-5">
										<div class="row counters py-5">
											<div class="col-md-6 col-lg-3 mb-4 mb-lg-0">
												@include('porto.partials.counter.counter-25')
											</div>
											<div class="col-md-6 col-lg-3 mb-4 mb-lg-0">
												@include('porto.partials.counter.counter-26')
											</div>
											<div class="col-md-6 col-lg-3 mb-4 mb-md-0">
												@include('porto.partials.counter.counter-27')
											</div>
											<div class="col-md-6 col-lg-3 mb-4 mb-md-0">
												@include('porto.partials.counter.counter-28')
											</div>
										</div>
									</div>
								</section>

								<section class="our-approach py-5">
									<div class="container pb-5">
										<div class="row">
											<div class="col-xl-4 pb-5 pb-xl-0 ">
												<div class="approach-img bg-color-dark">
													<div class="custom-circle custom-circle-1"></div>
													<div class="custom-circle custom-circle-2 bg-color-dark"></div>
													<span class="custom-circle custom-circle-our-approach-deco-1 bg-color-tertiary p-absolute d-block appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
													<span class="custom-circle custom-circle-our-approach-deco-2 bg-color-tertiary p-absolute d-block appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
													<span class="custom-circle custom-circle-our-approach-deco-3 bg-color-tertiary p-absolute d-block appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
												</div>
											</div>
											<div class="col-xl-8 d-flex flex-column justify-content-center align-items-start pl-5">
												<p class="custom-font-tertiary custom-text-6 line-height-6 font-weight-medium appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut tellus ante. Nam suscipit urna risus.</p>
												<p class="custom-text-3 mb-5 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero.</p>
												<a herf="demo-digital-agency-2-contact-us.html" class="btn btn-outline custom-btn-outline btn-primary rounded-0 text-color-dark custom-text-4 bg-color-hover-transparent text-color-hover-light font-weight-semibold custom-btn-with-arrow px-4 py-3 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">Get in Touch</a>
											</div>
										</div>
									</div>
								</section>

								<section class="our-insights bg-color-tertiary p-relative py-5">
									<span class="custom-circle custom-circle-2 bg-color-primary appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
									<span class="custom-circle custom-circle-3 bg-color-primary appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
									<div class="container py-5">
										<div class="row">
											<div class="col">
												<h4 class="text-color-dark custom-text-10 font-weight-bolder text-center custom-title-with-icon-center custom-title-with-icon custom-title-with-icon-primary pb-5 mb-5 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Our Insights</h4>
											</div>
										</div>
										<div class="row">
											<div class="col pb-5">
												<article>
													<p class="custom-font-tertiary text-uppercase custom-text-2 mb-1 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">FEBRUARY 4, 2021</p>
													<h4 class="text-color-dark custom-text-8 font-weight-bolder mb-3 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400"><a href="demo-digital-agency-2-our-blog-post.html" class="text-color-dark text-color-hover-primary">An Interview With John Paul Doe</a></h4>
													<p class="custom-text-4 mb-2 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero.</p>
													<a href="demo-digital-agency-2-our-blog-post.html" class="text-color-primary text-color-hover-secondary custom-text-4 font-weight-bolder text-decoration-underline appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="800">Read More...</a>
												</article>
											</div>
										</div>
										<div class="row">
											<div class="col pb-5">
												<article>
													<p class="custom-font-tertiary text-uppercase custom-text-2 mb-1 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">FEBRUARY 4, 2021</p>
													<h4 class="text-color-dark custom-text-8 font-weight-bolder mb-3 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400"><a href="demo-digital-agency-2-our-blog-post.html" class="text-color-dark text-color-hover-primary">Building An E-Commerce Site With CMS</a></h4>
													<p class="custom-text-4 mb-2 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero.</p>
													<a href="demo-digital-agency-2-our-blog-post.html" class="text-color-primary text-color-hover-secondary custom-text-4 font-weight-bolder text-decoration-underline appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="800">Read More...</a>
												</article>
											</div>
										</div>
										<div class="row">
											<div class="col pb-5">
												<article>
													<p class="custom-font-tertiary text-uppercase custom-text-2 mb-1 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">FEBRUARY 4, 2021</p>
													<h4 class="text-color-dark custom-text-8 font-weight-bolder mb-3 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400"><a href="demo-digital-agency-2-our-blog-post.html" class="text-color-dark text-color-hover-primary">How To Design Mobile Apps For Everyone</a></h4>
													<p class="custom-text-4 mb-2 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur. dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero.</p>
													<a href="demo-digital-agency-2-our-blog-post.html" class="text-color-primary text-color-hover-secondary custom-text-4 font-weight-bolder text-decoration-underline appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="800">Read More...</a>
												</article>
											</div>
										</div>
										<div class="row">
											<div class="col">		
												<a herf="demo-digital-agency-2-our-blog.html" class="btn btn-outline custom-btn-outline btn-primary rounded-0 text-color-dark custom-text-4 bg-color-hover-transparent text-color-hover-light font-weight-semibold custom-button-with-arrow px-4 py-3 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">View More</a>
											</div>
										</div>
									</div>
								</section>

				<section class="get-in-touch bg-color-after-secondary p-relative overflow-hidden">
					<span class="custom-circle custom-circle-1 bg-color-light appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
					<span class="custom-circle custom-circle-2 bg-color-light appear-animation" data-appear-animation="zoomIn" data-appear-animation-delay="100"></span>
					<div class="container">
						<div class="row">
							<div class="col-lg-8">
								<p class="mb-2 text-color-tertiary custom-text-7 custom-title-with-icon custom-title-with-icon-light appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">Let’s Get in Touch</p>
								<h4 class="text-color-light font-weight-bolder custom-text-10 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">
									We’re interested in talking<br>
									about your business.
								</h4>
							</div>
							<div class="col-lg-4 d-flex align-items-center justify-content-start justify-content-lg-end mt-5 mt-lg-0">
								<a herf="#" class="btn btn-outline custom-btn-outline btn-light border-white rounded-0 px-4 py-3 text-color-light text-color-hover-dark bg-color-hover-light custom-text-6 line-height-6 font-weight-semibold custom-btn-with-arrow appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="600">Let’s Talk!</a>
							</div>
						</div>
					</div>
				</section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="mt-0 py-5">
				<div class="container py-5">
					<div class="row justify-content-between">
						<div class="col-sm-12 col-lg-6 col-xl-6">
							<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
								<h4 class="custom-font-primary custom-newsletter-title font-weight-bold mb-4 custom-text-7">Join for Company Updates</h4>
								<div class="alert alert-success d-none" id="newsletterSuccess">
									<strong>Success!</strong> You've been added to our email list.
								</div>
								<div class="alert alert-danger d-none" id="newsletterError"></div>
								<form id="newsletterForm" action="php/newsletter-subscribe.php" method="POST" class="mr-0 mb-3 mb-md-0 opacity-10">
									<div class="input-group custom-newsletter">
										<input class="form-control form-control-sm custom-newsletter-input rounded-0 bg-transparent border-0 pl-0 custom-text-2 text-color-light box-shadow-none" placeholder="Your E-mail Address" name="newsletterEmail" id="newsletterEmail" type="text">
										<span class="input-group-append">
											<button class="btn text-color-light custom-text-4 font-weight-semibold custom-btn-with-arrow custom-btn-with-arrow-light" type="submit">Sign Up</button>
										</span>
									</div>
								</form>
							</div>
						</div>
						<div class="col-sm-12 col-lg-6 col-xl-4 col-info-footer mt-4 mt-sm-5 mt-lg-0">
							<div class="row">
								<div class="col-md-6">
									<span class="d-block text-left text-lg-right text-color-light font-weight-semibold text-5 pb-2 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="100">Los Angeles</span>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="150">123 The Main Street</p>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Los Angeles, CA 1000</p>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="250"><a href="tel:+1234567890" class="text-color-default">(123) 456-7890</a></p>
								</div>
								<div class="col-md-6 mt-3 mt-md-0">
									<span class="d-block text-left text-lg-right text-color-light font-weight-semibold text-5 pb-2 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="100">New York</span>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="150">123 The Main Street</p>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">New York, NY 1000</p>
									<p class="mb-0 text-left text-lg-right text-4 font-weight-medium appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="250"><a href="tel:+1234567890" class="text-color-default">(123) 456-7890</a></p>
								</div>
							</div>
						</div>
					</div>
					<div class="row justify-content-between">
						<div class="col-sm-12 col-lg-7 col-xl-6 d-none d-sm-flex">
							<div class="nav-footer w-100 pt-5 mt-0 mt-lg-4">
								<div class="row justify-content-between">
									<div class="col-auto mr-auto">
										<div class="appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">
											<div class="footer-nav footer-nav-links">
												<nav>
													<ul class="nav" id="footerNav">
														<li>
															<a class="text-color-hover-primary font-weight-semibold custom-text-2 text-capitalize" href="demo-digital-agency-2-our-services.html">Our Services</a>
														</li>
														<li>
															<a class="text-color-hover-primary font-weight-semibold custom-text-2 text-capitalize" href="demo-digital-agency-2-our-work.html">Our Work</a>
														</li>
														<li>
															<a class="text-color-hover-primary font-weight-semibold custom-text-2 text-capitalize" href="demo-digital-agency-2-contact-us.html">Contact Us</a>
														</li>
													</ul>
												</nav>
											</div>			
										</div>							
									</div>
									<div class="col-auto">
										<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
											@include('porto.partials.header-social-icons.header-social-icons-8')
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-12 col-lg-5 col-xl-6">
							<div class="d-flex justify-content-end custom-footer-copywriting pt-5 mt-0 mt-lg-4">
								<p class="mb-0 text-left text-lg-right d-block w-100 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="300">Porto Digital Agency. ©  2021.  All Rights Reserved</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
@endsection
