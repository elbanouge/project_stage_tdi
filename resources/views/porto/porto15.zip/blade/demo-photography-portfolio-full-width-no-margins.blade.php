@extends('porto.app')
@section('header')
<header id="header" class="header-full-width" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 0, 'stickySetTop': '0'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-33')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-175')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main" id="main">
				
				<div class="container-fluid p-0">

					<div id="photographyLightbox" class="mfp-hide">
						<div class="thumb-gallery">
							<div class="owl-carousel owl-theme manual thumb-gallery-detail" id="thumbGalleryDetail">
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/wedding/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/family/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/landscape/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1.jpg" class="img-fluid">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block">
										<img alt="" src="img/demos/photography/gallery/travel/3.jpg" class="img-fluid">
									</span>
								</div>
							</div>
							<div class="owl-carousel owl-theme manual thumb-gallery-thumbs show-thumbs mt" id="thumbGalleryThumbs">
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/wedding/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/family/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/landscape/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/3-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/2-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/lifestyle/1-thumb.jpg">
									</span>
								</div>
								<div>
									<span class="img-thumbnail d-block cur-pointer">
										<img alt="" src="img/demos/photography/gallery/travel/3-thumb.jpg">
									</span>
								</div>
							</div>
						</div>
					</div>
					<ul id="portfolioGrid" class="portfolioGridFullNoMargins p-0" data-grid-sizer=".col-lg-5ths">
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-278')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-279')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-280')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-281')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-282')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-283')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-284')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-285')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-286')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-287')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-288')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-289')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-290')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-291')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-292')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-283')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-282')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-281')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-280')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-279')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-298')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-286')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-285')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-284')
								</a>
							</div>
						</li>
						<li class="col-md-4 col-lg-5ths isotope-item p-0">
							<div class="portfolio-grid-item">
								<a href="#photographyLightbox" class="text-decoration-none popup-with-move-anim">
									@include('porto.partials.thumb-info.thumb-info-289')
								</a>
							</div>
						</li>
					</ul>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="light narrow">
				@include('porto.partials.footer-copyright.footer-copyright-28')
			</footer>
@endsection
