@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink bg-color-tertiary custom-header" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 100, 'stickyHeaderContainerHeight': 83}">
				<div class="header-body border-0 box-shadow-none">
					<div class="header-top header-top-default bg-color-white border-bottom-0">
						<div class="container-fluid px-lg-4">
							<div class="header-row py-2">
								<div class="header-column justify-content-start">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills text-uppercase text-2">
												<li class="nav-item nav-item-anim-icon">
													<a class="px-0" href="mailto:mail@domain.com"><i class="far fa-envelope text-4 top-1 left-0"></i> porto@construction.com</a>
												</li>
												<li class="nav-item nav-item-anim-icon pl-md-4">
													<span class="d-none d-md-block">
														<i class="far fa-clock p-relative top-2 text-4"></i><span> Mon - Sat 9:00am - 6:00pm / Sunday - CLOSED</span>
													</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>

								<div class="header-column justify-content-end">
									<div class="header-row">
										@include('porto.partials.header-social-icons.header-social-icons-5')
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container-fluid bg-secondary px-0">
						<div class="header-row">
							<div class="header-column bg-color-primary flex-grow-0 px-3 px-lg-5">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-14')
								</div>
							</div>
							<div class="header-column justify-content-end justify-content-lg-start px-lg-5">
								<div class="header-row pr-3">
									@include('porto.partials.header-nav.header-nav-68')
									<div class="header-nav-features header-nav-features-light header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">porto.partials
										@include('porto.partials.header-nav-feature.header-nav-feature-3')
									</div>
								</div>
							</div>
						</div>
						<div class="header-row d-none d-lg-inline-flex justify-content-end">
							<div class="order-1 order-lg-2 pr-4 d-none d-xl-block">
								<div>
									<div class="feature-box feature-box-style-2 align-items-center p-relative top-8 px-2">
										<div class="feature-box-icon">
											<i class="fas fa-mobile-alt text-9 p-relative bottom-8 text-color-light"></i>
										</div>
										<div class="feature-box-info pl-0">
											<p class="text-color-light opacity-8 text-uppercase line-height-1 text-2 pb-0 mb-2">CALL US NOW</p>
											<p class="text-uppercase text-color-light font-weight-black letter-spacing-minus-1 line-height-1 text-5 pb-0"><a href="tel:+1234567890" class="text-color-light text-color-hover-primary text-decoration-none">(800) 123 4567</a></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('porto.partials
<div role="main" class="main">
@include('porto.partials.page-header.page-header-115')

				<div class="container container-lg-custom pt-4">
					<div class="row">
						<div class="col">
							<p class="mb-1">FEATURE WORKS</p>
							<h3 class="text-secondary font-weight-bold text-capitalize text-7 mb-3">Our Portfolio</h3>
						</div>
					</div>
					<div class="row row-gutter-sm">
						<div class="col custom-portfolio">
							<ul class="nav nav-pills sort-source custom-nav-filter custom-center-pills my-3" data-sort-id="portfolio" data-option-key="filter" data-plugin-options="{'layoutMode': 'packery', 'filter': '*'}">
								<li class="nav-item active" data-option-value="*"><a class="nav-link active" href="#">VIEW ALL</a></li>
								<li class="nav-item" data-option-value=".pre-construction"><a class="nav-link" href="#">PRE-CONSTRUCTION</a></li>
								<li class="nav-item" data-option-value=".general-construction"><a class="nav-link" href="#">GENERALCONSTRUCTION</a></li>
								<li class="nav-item" data-option-value=".painting"><a class="nav-link" href="#">PAINTING</a></li>
								<li class="nav-item" data-option-value=".plubing"><a class="nav-link" href="#">PLUMBING</a></li>
							</ul>
							<div class="sort-destination-loader sort-destination-loader-showing">
								<div id="loaporto.partials"row row-gutter-sm px-0 image-gallery sort-destination" data-sort-id="portfolio" data-total-pages="3">
									<div class="col-sm-6 isotope-item pre-construction">
										@include('porto.partials.portfolio-item.portfolio-item-41')
									</div>porto.partials
									<div class="col-sm-6 col-lg-3 isotope-item general-construction">
										@include('porto.partials.portfolio-item.portfolio-item-42')
									</div>porto.partials
									<div class="col-sm-6 col-lg-3 isotope-item painting">
										@include('porto.partials.portfolio-item.portfolio-item-43')
									</div>porto.partials
									<div class="col-sm-6 col-lg-3 isotope-item plubing">
										@include('porto.partials.portfolio-item.portfolio-item-44')
									</div>	
								</div>
							</div>
						</div>
					</div>
					<div class="row justify-content-center mb-5">
						<div id="loadMoreBtnWrapper" class="row text-center">
							<div class="col">
								<div id="loadMoreLoader" class="load-more-loader">
									<div class="bounce-loader">
										<div class="bounce1"></div>
										<div class="bounce2"></div>
										<div class="bounce3"></div>
									</div>
								</div>
								<button id="loadMore" class="btn btn-primary btn-outline custom-btn font-weight-extra-bold mt-4 px-5 py-3 border-width-4 appear-animation" data-appear-animation="fadeInUpShorter">LOAD MORE+
								</button>
							</div>
						</div>
					</div>
				</div>

			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-secondary border-top-0 mt-0 custom-footer">
				<div class="container container-lg-custom py-md-4">
					<div class="row justify-content-md-center py-5">
						<div class="col-md-12 col-lg-2 d-flex align-items-center justify-content-center justify-content-lg-start mb-5 mb-lg-0">
							<a href="#"><img src="img/demos/construction-2/logo-1.png" alt="Logo" class="img-fluid logo"></a>
						</div>
						<div class="col-md-3 text-center text-md-left">
							<p class="text-5 text-color-light font-weight-bold mb-3 mt-4 mt-lg-0">Get in Touch</p>
							<p class="text-3 mb-0 font-weight-bold text-color-light opacity-7 text-uppercase">ADDRESS</p>
							<p class="text-3 mb-2 text-color-light">123 Street name, City, USA.</p>
							<p class="text-3 mb-0 font-weight-bold text-color-light opacity-7 text-uppercase">PHONE</p>
							<p class="text-3 mb-2 text-color-light">Toll Free <a href="tel:+1234567890" class="text-color-light">(123) 456-7890</a></p>
							<p class="text-3 mb-0 font-weight-bold text-color-light opacity-7 text-uppercase">EMAIL</p>
							<p class="text-3 mb-2 "><a href="mailto:info@porto.com" class="text-color-light">mail@example.com</a></p>
							<p class="text-3 mb-0 font-weight-bold text-color-light opacity-7 text-uppercase">Working Days/Hours</p>
							<p class="text-3 mb-3 text-color-light">Mon - Sun / 9:00AM - 8:00PM</p>
							<ul class="social-icons social-icons-dark social-icons-clean">
								<li class="social-icons-instagram">
									<a href="http://www.instagram.com/" target="_blank" title="Instagram">
										<i class="fab fa-instagram font-weight-semibold"></i>
									</a>
								</li>
								<li class="social-icons-twitter">
									<a href="http://www.twitter.com/" target="_blank" title="Twitter">
										<i class="fab fa-twitter font-weight-semibold"></i>
									</a>
								</li>
								<li class="social-icons-facebook">
									<a href="http://www.facebook.com/" target="_blank" title="Facebook">
										<i class="fab fa-facebook-f font-weight-semibold"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 text-center text-md-left mt-5 mt-md-0 mb-5 mb-lg-0">
							<p class="text-5 text-color-light font-weight-bold mb-3 mt-4 mt-lg-0">Useful links</p>
							<div class="row opacity-7">
								<div class="col-md-5">
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Contact Us</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Our Services</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Payment Methods</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Services Guide</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">FAQs</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Service Support</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Privacy</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">About Porto</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Our Guarantees</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Terms And Conditions</a></p>
								</div>
								<div class="col-md-5">
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Privacy Policy</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Return Policy</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Intellectual Property</a></p>
									<p class="mb-0"><a href="#" class="text-3 text-color-light link-hover-style-1">Site Map</a></p>
								</div>
							</div>
						</div>
						<div class="col-md-3 text-center text-md-left">
							<p class="text-5 text-color-light font-weight-bold mb-3 mt-4 mt-lg-0">Latest Projects</p>

							<p class="text-3 mb-0 text-color-light opacity-7">Painting, Plumbing</p>
							<p class="text-3 mb-0 font-weight-bold text-color-light">House Renovation - New York / NY</p>
							<p class="text-3 mb-4 font-weight-bold"><a href="#" class="link-hover-style-1 text-primary">VIEW MORE+</a></p>

							<p class="text-3 mb-0 text-color-light opacity-7">Eletrical Maitenance</p>
							<p class="text-3 mb-0 font-weight-bold text-color-light">Building Repair - Detroit / MI</p>
							<p class="text-3 mb-4 font-weight-bold"><a href="#" class="link-hover-style-1 text-primary">VIEW MORE+</a></p>

							<p class="text-3 mb-0 text-color-light opacity-7">Flooring</p>
							<p class="text-3 mb-0 font-weight-bold text-color-light">House Repair - New York / NY</p>
							<p class="text-3 font-weight-bold"><a href="#" class="link-hover-style-1 text-primary">VIEW MORE+</a></p>
						</div>
					</div>
				</div>porto.partials
				<div class="container container-lg-custom">
					@include('porto.partials.footer-copyright.footer-copyright-12')
				</div>
				<div class="container-fluid bg-light">
					<div class="container container-lg-custom py-5">
						<div class="row flex-column flex-md-row align-items-center justify-content-center justify-content-lg-between px-3">
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-1.png" alt="Brand" class="img-fluid">
							</span>
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-2.png" alt="Brand" class="img-fluid">
							</span>
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-3.png" alt="Brand" class="img-fluid">
							</span>
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-4.png" alt="Brand" class="img-fluid">
							</span>
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-5.png" alt="Brand" class="img-fluid">
							</span>
							<span class="p-3">
								<img src="img/demos/construction-2/brands/brand-6.png" alt="Brand" class="img-fluid">
							</span>
						</div>
					</div>
				</div>
			</footer>
@endsection
