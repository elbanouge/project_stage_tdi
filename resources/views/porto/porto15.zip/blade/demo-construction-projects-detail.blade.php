@extends('porto.app')
@section('header')
<header id="header" class="header-narrow header-semi-transparent-light" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 1, 'stickySetTop': '1'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-15')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-74')
									<div class="header-nav-features header-nav-features-no-border d-none d-sm-block order-1 order-lg-2">
										@include('porto.partials.header-social-icons.header-social-icons-6')
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				<section class="section section-tertiary section-no-border pb-3 mt-0">
					<div class="container">
						<div class="row justify-content-end mt-4">
							<div class="col-lg-10 pt-4 mt-4 text-right">
								<h1 class="text-uppercase font-weight-light mt-4 pt-3 text-color-primary">Projects</h1>
							</div>
						</div>
					</div>
				</section>

				<div class="container">

					<div class="row">
						<div class="col">
							<div class="portfolio-title">
								<div class="row">
									<div class="portfolio-nav-all col-lg-1">
										<a href="demo-construction-projects.html" data-tooltip data-original-title="Back to list"><i class="fas fa-th"></i></a>
									</div>
									<div class="col-lg-10 text-center">
										<h2 class="mb-0">Porto Building</h2>
									</div>
									<div class="portfolio-nav col-lg-1">
										<a href="demo-construction-projects-detail.html" class="portfolio-nav-prev" data-tooltip data-original-title="Previous"><i class="fas fa-chevron-left"></i></a>
										<a href="demo-construction-projects-detail.html" class="portfolio-nav-next" data-tooltip data-original-title="Next"><i class="fas fa-chevron-right"></i></a>
									</div>
								</div>
							</div>

							<hr class="solid my-5">
						</div>
					</div>

					<div class="row mb-4">
						<div class="col-lg-4">
							<div class="thumb-gallery">
								<div class="lightbox" data-plugin-options="{'delegate': 'a', 'type': 'image', 'gallery': {'enabled': true}}">
									<div class="owl-carousel owl-theme manual thumb-gallery-detail show-nav-hover" id="thumbGalleryDetail">
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-1.jpg">
												@include('porto.partials.thumb-info.thumb-info-81')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-2.jpg">
												@include('porto.partials.thumb-info.thumb-info-82')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-3.jpg">
												@include('porto.partials.thumb-info.thumb-info-83')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-4.jpg">
												@include('porto.partials.thumb-info.thumb-info-84')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-5.jpg">
												@include('porto.partials.thumb-info.thumb-info-85')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-6.jpg">
												@include('porto.partials.thumb-info.thumb-info-86')
											</a>
										</div>
										<div>
											<a href="img/demos/construction/gallery/construction-gallery-7.jpg">
												@include('porto.partials.thumb-info.thumb-info-87')
											</a>
										</div>
									</div>
								</div>

								<div class="owl-carousel owl-theme manual thumb-gallery-thumbs mt" id="thumbGalleryThumbs">
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-1.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-2.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-3.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-4.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-5.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-6.jpg" class="img-fluid cur-pointer">
									</div>
									<div>
										<img alt="Project Image" src="img/demos/construction/gallery/construction-gallery-7.jpg" class="img-fluid cur-pointer">
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-8">

							<div class="project-detail-construction">

								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempus nibh sed elimttis adipiscing. Fusce in hendrerit purus. Suspendisse potenti. Proin quis eros odio, dapibus dictum mauris. Donec nisi libero, adipiscing id pretium eget, consectetur sit amet leo. Nam at eros quis mi egestas fringilla non nec purus.</p>

								<div class="row">
									<div class="col-lg-5">

										<ul class="list-project-details">
											<li>
												<label>Project Location:</label>
												<p>New York</p>
											</li>
											<li>
												<label>Project Type:</label>
												<p>General Construction</p>
											</li>
											<li>
												<label>Project Cost:</label>
												<p>$100,000</p>
											</li>
											<li>
												<label>Client:</label>
												<p>Okler Themes</p>
											</li>
										</ul>

									</div>
									<div class="col-lg-7">
										<div class="progress-bars progress-bars-project-detail">
											<div class="progress-label">
												<span>General Progress</span>
											</div>
											<div class="progress progress-sm">
												<div class="progress-bar progress-bar-primary" data-appear-progress-animation="81%">
													<span class="progress-bar-tooltip">81%</span>
												</div>
											</div>
											<div class="progress-label">
												<span>Phase 1</span>
											</div>
											<div class="progress progress-sm">
												<div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="300">
													<span class="progress-bar-tooltip">85%</span>
												</div>
											</div>
											<div class="progress-label">
												<span>Phase 2</span>
											</div>
											<div class="progress progress-sm">
												<div class="progress-bar progress-bar-primary" data-appear-progress-animation="75%" data-appear-animation-delay="600">
													<span class="progress-bar-tooltip">75%</span>
												</div>
											</div>
											<div class="progress-label">
												<span>Phase 4</span>
											</div>
											<div class="progress progress-sm">
												<div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="900">
													<span class="progress-bar-tooltip">85%</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>
					</div>

				</div>
			</div>
@endsection

@section('footer')
<footer id="footer">
				<div class="container">
					<div class="row pt-4 pb-5 text-center text-md-left">
						<div class="col-md-3">
							<a href="demo-construction.html">
								<img alt="Porto" class="img-fluid logo" width="110" src="img/demos/construction/logo-construction-small.png">
							</a>
						</div>
						<div class="col-md-4">
							<div class="row">
								<div class="col-lg-6 mb-2">
									<h4>Navigation</h4>
								</div>
							</div>
							<div class="row">
								<div class="col-6 mb-0">
									<ul class="list list-footer-nav">
										<li>
											<a href="demo-construction.html">
												Home
											</a>
										</li>
										<li>
											<a href="demo-construction-company.html">
												Company
											</a>
										</li>
										<li>
											<a href="demo-construction-services.html">
												Services
											</a>
										</li>
									</ul>
								</div>
								<div class="col-6">
									<ul class="list list-footer-nav">
										<li>
											<a href="demo-construction-projects.html">
												Projects
											</a>
										</li>
										<li>
											<a href="demo-construction-blog.html">
												Blog
											</a>
										</li>
										<li>
											<a href="demo-construction-contact.html">
												Contact
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-5">
							<h4>Newsletter</h4>

							<div class="newsletter">

								<div class="alert alert-success d-none" id="newsletterSuccess">
									<strong>Success!</strong> You've been added to our email list.
								</div>

								<div class="alert alert-danger d-none" id="newsletterError"></div>

								<form id="newsletterForm" action="php/newsletter-subscribe.php" method="POST">
									<div class="input-group">
										<input class="form-control form-control-sm" placeholder="Email Address" name="newsletterEmail" id="newsletterEmail" type="text">
										<span class="input-group-append">
											<button class="btn btn-light" type="submit"><i class="icon-paper-plane icons"></i></button>
										</span>
									</div>
								</form>

							</div>

							<p><i class="fas fa-phone"></i> (123) 456-789 <i class="far fa-envelope ml-2"></i> <a href="mailto:mail@example.com">mail@example.com</a></p>

						</div>
					</div>

					@include('porto.partials.footer-copyright.footer-copyright-13')

				</div>
			</footer>
@endsection
