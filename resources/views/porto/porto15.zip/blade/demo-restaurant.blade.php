@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-top-0">
					<div class="header-top border-bottom-0 bg-color-secondary">
						<div class="container">
							<div class="header-row py-2">
								<div class="header-column justify-content-center justify-content-md-start">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<span class="text-light opacity-7 pl-0">The best place to eat in downtown Porto!</span>
												</li>
											</ul>
										</nav>
									</div>
								</div>
								<div class="header-column justify-content-end d-none d-md-flex">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<a href="tel:123-456-7890"><i class="fab fa-whatsapp text-4 text-color-primary" style="top: 0;"></i> 123-456-7890</a>
												</li>
											</ul>
										</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-36')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-188')
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">
				<div class="owl-carousel-wrapper" style="height: 650px;">
					<div class="owl-carousel dots-inside dots-horizontal-center show-dots-hover show-dots-xs show-dots-sm show-dots-md nav-inside nav-inside-plus nav-dark nav-md nav-font-size-md show-nav-hover mb-0" data-plugin-options="{'responsive': {'0': {'items': 1, 'dots': true, 'nav': false}, '479': {'items': 1, 'dots': true}, '768': {'items': 1, 'dots': true}, '979': {'items': 1}, '1199': {'items': 1}}, 'loop': false, 'autoHeight': false, 'margin': 0, 'dots': false, 'dotsVerticalOffset': '-50px', 'nav': true, 'animateIn': 'fadeIn', 'animateOut': 'fadeOut', 'mouseDrag': false, 'touchDrag': false, 'pullDrag': false, 'autoplay': false, 'autoplayTimeout': 7000, 'autoplayHoverPause': true, 'rewind': true}">
										
						<!-- Carousel Slide 1 -->
						<div class="position-relative overflow-hidden" data-dynamic-height="['650px','650px','650px','500px','500px']" style="background-image: url(img/demos/restaurant/slides/slide-restaurant-1.jpg); background-size: cover; background-position: center; background-position: center; height: 650px;">
							<div class="container position-relative z-index-3 h-100">
								<div class="row align-items-center h-100">
									<div class="col-lg-7">
										<div class="d-flex flex-column justify-content-center align-items-start h-100">
											<h2 class="position-relative text-color-light text-6 line-height-5 font-weight-medium alternative-font pr-4 mb-2 appear-animation" data-appear-animation="fadeInDownShorterPlus" data-plugin-options="{'minWindowWidth': 0}">
												WELCOME TO
												<span class="position-absolute left-100pct top-50pct transform3dy-n50">
													<img src="img/slides/slide-title-border.png" class="w-auto appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="250" data-plugin-options="{'minWindowWidth': 0}" alt="">
												</span>
											</h2>
											<h1 class="text-color-light font-weight-extra-bold text-15 line-height-1 mb-2 appear-animation" data-appear-animation="blurIn" data-appear-animation-delay="1000" data-plugin-options="{'minWindowWidth': 0}">THE PORTO</h1>
											<p class="text-4 text-color-light font-weight-light mb-4" data-plugin-animated-letters data-plugin-options="{'startDelay': 2000, 'minWindowWidth': 0}">The best place to eat in downtown Porto!</p>
											<a href="#menu" data-hash data-hash-offset="85" class="btn btn-primary font-weight-bold btn-py-2 btn-px-3 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="2400">Our Menu</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<!-- Carousel Slide 2 -->
						<div class="position-relative overflow-hidden" data-dynamic-height="['650px','650px','650px','500px','500px']" style="background-image: url(img/demos/restaurant/slides/slide-restaurant-2.jpg); background-size: cover; background-position: center; background-position: center; height: 650px;">
							<div class="container position-relative z-index-3 h-100">
								<div class="row align-items-center h-100">
									<div class="col-lg-7">
										<div class="d-flex flex-column justify-content-center align-items-start h-100">
											<h2 class="position-relative text-color-light text-6 line-height-5 font-weight-medium alternative-font pr-4 mb-2 appear-animation" data-appear-animation="fadeInDownShorterPlus" data-plugin-options="{'minWindowWidth': 0}">
												Best ingredients, fresh prepared!
												<span class="position-absolute left-100pct top-50pct transform3dy-n50">
													<img src="img/slides/slide-title-border.png" class="w-auto appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="250" data-plugin-options="{'minWindowWidth': 0}" alt="">
												</span>
											</h2>
											<h1 class="text-color-light font-weight-extra-bold text-15 line-height-1 mb-2 appear-animation" data-appear-animation="blurIn" data-appear-animation-delay="1000" data-plugin-options="{'minWindowWidth': 0}">DELICIOUS!!!</h1>
											<p class="text-4 text-color-light font-weight-light mb-4" data-plugin-animated-letters data-plugin-options="{'startDelay': 2000, 'minWindowWidth': 0}">The best place to eat in downtown Porto!</p>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>

				<section class="pt-5">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 text-center">
								<h2 class="mt-4 mb-2">Enjoy <strong>Your Meal</strong></h2>
								<p class="text-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

								<hr class="custom-divider">
							</div>
						</div>
						<div class="row mt-4">
							<div class="col-md-4 pb-5">

								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="0">
									@include('porto.partials.thumb-info.thumb-info-348')
								</div>

							</div>
							<div class="col-md-4 pb-5">

								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="300">
									@include('porto.partials.thumb-info.thumb-info-349')
								</div>

							</div>
							<div class="col-md-4 pb-5">

								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="600">
									@include('porto.partials.thumb-info.thumb-info-350')
								</div>

							</div>
						</div>
					</div>
				</section>

				<section class="section section-background section-center" style="background-image: url(img/demos/restaurant/parallax-restaurant.jpg); background-position: 50% 100%; min-height: 615px;">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-8">
								<hr class="custom-divider">
								<div class="owl-carousel owl-theme nav-bottom rounded-nav" data-plugin-options="{'items': 1, 'loop': false}">
									<div>
										<div class="col">
											@include('porto.partials.testimonial.testimonial-70')
										</div>
									</div>
									<div>
										<div class="col">
											@include('porto.partials.testimonial.testimonial-71')
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-lg-8">

							</div>
						</div>
					</div>
				</section>
				<section class="pt-3 pb-3">
					<div class="container">
						<div class="row mb-5">
							<div class="col-lg-12 text-center">
								<h4 class="mt-4 mb-2">Our <strong>Gallery</strong></h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

								<hr class="custom-divider">

								<div class="lightbox" data-plugin-options="{'delegate': 'a', 'type': 'image', 'gallery': {'enabled': true}}">
									<div class="masonry-loader masonry-loader-showing">
										<div class="masonry" data-plugin-masonry data-plugin-options="{'itemSelector': '.masonry-item'}">
											<div class="masonry-item">
												@include('porto.partials.thumb-info.thumb-info-351')
											</div>
											<div class="masonry-item w2">
												@include('porto.partials.thumb-info.thumb-info-352')
											</div>
											<div class="masonry-item">
												@include('porto.partials.thumb-info.thumb-info-353')
											</div>
											<div class="masonry-item">
												@include('porto.partials.thumb-info.thumb-info-354')
											</div>
											<div class="masonry-item">
												@include('porto.partials.thumb-info.thumb-info-355')
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<div class="container-fluid">
					<div class="row mt-5">

						<div class="col-lg-6 p-0">
							<section class="section section-quaternary section-no-border h-100 mt-0">
								<div class="row justify-content-end">
									<div class="col-half-section col-half-section-right">
										<div class="text-center">
											<h4 class="mt-3 mb-0 heading-dark">Our <strong>Blog</strong></h4>
											<p class="mb-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

											<hr class="custom-divider m-0">
										</div>
										
										<div class="owl-carousel owl-theme show-nav-title mt-5 mb-0" data-plugin-options="{'items': 1, 'margin': 10, 'loop': true, 'nav': true, 'dots': false, 'autoplay': true, 'autoplayTimeout': 5000}">
											<div>
												@include('porto.partials.thumb-info.thumb-info-356')

												@include('porto.partials.thumb-info.thumb-info-357')
											</div>
											<div>
												@include('porto.partials.thumb-info.thumb-info-358')

												@include('porto.partials.thumb-info.thumb-info-359')
											</div>
											<div>
												@include('porto.partials.thumb-info.thumb-info-360')

												@include('porto.partials.thumb-info.thumb-info-357')
											</div>
										</div>

									</div>
								</div>
							</section>
						</div>

						<div class="col-lg-6 p-0">
							<section class="section section-tertiary section-no-border h-100 mt-0">
								<div class="row">
									<div class="col-half-section">
										<div class="text-center">
											<h4 class="mt-3 mb-0 heading-dark">Our <strong>Team</strong></h4>
											<p class="mb-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

											<hr class="custom-divider m-0">
										</div>

										<div class="owl-carousel owl-theme show-nav-title mt-5 mb-0" data-plugin-options="{'responsive': {'0': {'items': 1}, '479': {'items': 1}, '768': {'items': 2}, '979': {'items': 2}, '1199': {'items': 2}}, 'margin': 10, 'loop': false, 'nav': true, 'dots': false}">
											<div>
												@include('porto.partials.thumb-info.thumb-info-362')
											</div>
											<div>
												@include('porto.partials.thumb-info.thumb-info-363')
											</div>
											<div>
												@include('porto.partials.thumb-info.thumb-info-364')
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>

					</div>
				</div>

				<section id="menu" style="background-image: url(img/demos/restaurant/background-restaurant.png); background-position: 50% 100%; background-repeat: no-repeat;">
					<div class="container">
						<div class="row mt-3">
							<div class="col-lg-12 text-center">
								<h4 class="mt-4 mb-2">Special <strong>Menu</strong></h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>

								<hr class="custom-divider">

								<ul class="special-menu pb-4">
									<li>
										<img src="img/demos/restaurant/products/product-1.jpg" class="img-fluid" alt="">
										<h3>Monday <em>Special</em></h3>
										<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu pulvinar magna.</span></p>
										<strong class="special-menu-price text-color-dark">$29</strong>
									</li>
									<li>
										<img src="img/demos/restaurant/products/product-2.jpg" class="img-fluid" alt="">
										<h3>Tuesday <em>Special</em></h3>
										<p><span>Lorem ipsum dolor sit amet. Donec eu pulvinar magna.</span></p>
										<strong class="special-menu-price text-color-dark">$39</strong>
									</li>
									<li>
										<img src="img/demos/restaurant/products/product-3.jpg" class="img-fluid" alt="">
										<h3>Wednesday <em>Special</em></h3>
										<p><span>Lorem ipsum dolor sit amet.</span></p>
										<strong class="special-menu-price text-color-dark">$24</strong>
									</li>
									<li>
										<img src="img/demos/restaurant/products/product-4.jpg" class="img-fluid" alt="">
										<h3>Thursday <em>Special</em></h3>
										<p><span>Lorem ipsum dolor sit amet magna.</span></p>
										<strong class="special-menu-price text-color-dark">$39</strong>
									</li>
									<li>
										<img src="img/demos/restaurant/products/product-5.jpg" class="img-fluid" alt="">
										<h3>Friday <em>Special</em></h3>
										<p><span>Lorem ipsum dolor sit amet adipiscing elit. Donec eu pulvinar magna.</span></p>
										<strong class="special-menu-price text-color-dark">$59</strong>
									</li>
								</ul>

							</div>
						</div>
						<div class="row mb-0 mt-5">
							<div class="col-lg-12 text-center">
								<a href="demo-restaurant-menu.html" class="btn btn-primary btn-lg mb-5">Full Menu</a>
							</div>
						</div>
					</div>
				</section>
			</div>
@endsection

@section('footer')
<footer id="footer" class="border-top-0 bg-color-secondary mt-0">
				<div class="container">
					<div class="row py-5">
						<div class="col text-center">
							<ul class="footer-social-icons social-icons social-icons-clean social-icons-big social-icons-opacity-light social-icons-icon-light mt-1">
								<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f text-2"></i></a></li>
								<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter text-2"></i></a></li>
								<li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in text-2"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-32')
			</footer>
@endsection
