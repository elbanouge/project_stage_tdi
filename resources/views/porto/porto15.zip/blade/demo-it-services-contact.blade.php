@extends('porto.app')
@section('header')
<header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 90}">
				<div class="header-body border-top-0 box-shadow-none">
					<div class="header-container container container-lg-custom">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									@include('porto.partials.header-logo.header-logo-25')
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									@include('porto.partials.header-nav.header-nav-134')
									<div class="d-none d-sm-inline-flex order-1 order-lg-2 ml-2">
										<ul class="header-extra-info d-flex">
											<li class="d-none d-xl-flex flex-column">
												<span class="d-block font-weight-semibold text-color-dark text-2 line-height-3">SUPPORT</span>
												<a href="tel:+1234567890" class="font-weight-bold text-color-primary text-5">800-123-4567</a>
											</li>
											<li class="d-flex flex-column">
												<span class="d-block font-weight-semibold text-color-dark text-2 line-height-3">SALES</span>
												<a href="tel:+1234567890" class="font-weight-bold text-color-primary text-5">800-123-4567</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
@endsection

@section('main')
<div role="main" class="main">

                @include('porto.partials.page-header.page-header-160')

                <section class="section border-0 py-0 m-0">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-5 px-0">
                                <div class="d-flex flex-column justify-content-center bg-color-dark h-100 p-5">
                                    <div class="row justify-content-center pt-2 mt-5">
                                        <div class="col-md-9">
                                            <div class="feature-box flex-column flex-xl-row align-items-center align-items-xl-start text-center text-xl-left appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="600">
                                                <div class="feature-box-icon bg-color-transparent w-auto h-auto pt-0">
                                                    <img src="img/demos/it-services/icons/building.svg" class="img-fluid" width="95" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-light'}">
                                                </div>
                                                <div class="feature-box-info pl-2 pt-1">
                                                    <h4 class="text-color-light font-weight-bold text-6">Corporate Headquarters</h4>
                                                    <p class="text-color-light opacity-5 font-weight-light custom-text-size-1 pb-2 mb-4">12345 Porto Blvd,<br>Suite 1500<br>Los Angeles, California 9000</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-9 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">
                                            <hr class="bg-color-light opacity-2">
                                        </div>
                                    </div>
                                    <div class="row justify-content-center py-2">
                                        <div class="col-auto text-center mb-4 mb-sm-0 mb-lg-4 mb-xl-0 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="1000">
                                            <span class="d-block font-weight-semibold text-center">SUPPORT</span>
                                            <a href="tel:+1234567890" class="text-color-light font-weight-bold text-6">800-123-4567</a>
                                        </div>
                                        <div class="col-auto text-center ml-xl-5 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="1200">
                                            <span class="d-block font-weight-semibold text-center">SALES</span>
                                            <a href="tel:+1234567890" class="text-color-light font-weight-bold text-6">800-123-4567</a>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center pt-2 pb-3 mb-5">
                                        <div class="col-md-9 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1400">
                                            <hr class="bg-color-light opacity-2">
                                        </div>
                                        <div class="col-md-12 text-center appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1600">
                                            <span class="d-block font-weight-semibold text-center">SEND AN EMAIL</span>
                                            <a href="mailto:mail@domain.com" class="text-color-light font-weight-bold text-decoration-underline text-5">mail@domain.com</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 px-0">
                                
                                <!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
                                <div id="googlemaps" class="google-map h-100 my-0" style="min-height: 500px;"></div>

                            </div>
                        </div>
                    </div>
                </section>

                <section class="section custom-section-full-width bg-color-transparent border-0 mt-1 mb-1" style="background-image: url(img/demos/it-services/backgrounds/dots-background-4.png); background-repeat: no-repeat; background-position: top right;">
                    <div class="container container-lg-custom mt-3">
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="overflow-hidden mb-2">
                                    <span class="d-block font-weight-bold custom-text-color-grey-1 text-center line-height-1 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="300">GET IN TOUCH</span>
                                </div>
                                <div class="overflow-hidden mb-4">
                                    <h2 class="text-color-dark font-weight-bold text-center text-8 line-height-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="500">How Can We Help?</h2>
                                </div>
                                <p class="custom-text-size-1 text-center mb-5 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="700">Contact us to request a quote or to schedule a consultation with our team.</p>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="900">
                                <form class="contact-form" action="php/contact-form.php" method="POST">
                                    <div class="contact-form-success alert alert-success d-none mt-4">
                                        <strong>Success!</strong> Your message has been sent to us.
                                    </div>

                                    <div class="contact-form-error alert alert-danger d-none mt-4">
                                        <strong>Error!</strong> There was an error sending your message.
                                        <span class="mail-error-message text-1 d-block"></span>
                                    </div>
                                    
                                    <div class="form-row row-gutter-sm">
                                        <div class="form-group col-lg-6 mb-4">
                                            <input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control border-0 custom-box-shadow-1 py-3 px-4 h-auto text-3 text-color-dark" name="name" id="name" required placeholder="Your Name">
                                        </div>
                                        <div class="form-group col-lg-6 mb-4">
                                            <input type="text" value="" data-msg-required="Please enter your phone number." maxlength="100" class="form-control border-0 custom-box-shadow-1 py-3 px-4 h-auto text-3 text-color-dark" name="phone" id="phone" required placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <div class="form-row row-gutter-sm">
                                        <div class="form-group col-lg-6 mb-4">
                                            <input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control border-0 custom-box-shadow-1 py-3 px-4 h-auto text-3 text-color-dark" name="email" id="email" required placeholder="Your Name">
                                        </div>
                                        <div class="form-group col-lg-6 mb-4">
                                            <input type="text" value="" data-msg-required="Please enter the subject." maxlength="100" class="form-control border-0 custom-box-shadow-1 py-3 px-4 h-auto text-3 text-color-dark" name="subject" id="subject" required placeholder="Subject">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col mb-4">
                                            <textarea maxlength="5000" data-msg-required="Please enter your message." rows="10" class="form-control border-0 custom-box-shadow-1 py-3 px-4 h-auto text-3 text-color-dark" name="message" id="message" required placeholder="Your Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col mb-0">
                                            <button type="submit" class="btn btn-secondary btn-outline text-color-dark font-weight-semibold border-width-4 custom-link-effect-1 text-1 text-xl-3 d-inline-flex align-items-center px-4 py-3" data-loading-text="Loading...">SUBMIT <i class="custom-arrow-icon ml-5"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>

			</div>
@endsection

@section('footer')
<footer id="footer" class="bg-color-primary border-0 mt-0">
				<div class="container container-lg-custom pt-4 pb-3">
					<div class="row py-5">
						<div class="col-md-4 col-lg-2 mb-4 mb-lg-0">
							<h4 class="ls-0">OUR ADDRESS</h4>
							<ul class="list list-unstyled">
								<li class="mb-1">
									12345  Porto Blvd.
								</li>
								<li class="mb-1">
									Suite 1500
								</li>
								<li>
									Los Angeles, California 90000
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-lg-2 mb-4 mb-lg-0">
							<h4 class="ls-0">OUR CONTACTS</h4>
							<ul class="list-unstyled">
								<li class="pb-1 mb-2">
									<span class="d-block line-height-2">SUPPORT</span>
									<a href="tel:+1234567890" class="text-color-light text-6 text-lg-4 text-xl-6 font-weight-bold">800-123-4567</a>
								</li>
								<li>
									<span class="d-block line-height-2">SALES</span>
									<a href="tel:+1234567890" class="text-color-light text-6 text-lg-4 text-xl-6 font-weight-bold">800-123-4568</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-lg-2 mb-4 mb-lg-0">
							<h4 class="ls-0">USEFUL LINKS</h4>
							<ul class="list-unstyled">
								<li class="mb-1">
									<a href="demo-it-services-services.html">Our Services</a>
								</li>
								<li class="mb-1">
									<a href="#">Payment Methods</a>
								</li>
								<li class="mb-1">
									<a href="#">Services Guide</a>
								</li>
								<li>
									<a href="#">FAQs</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-lg-2 mb-4 mb-md-0">
							<h4 class="ls-0">OUR SERVICES</h4>
							<ul class="list-unstyled">
								<li class="mb-1">
									<a href="demo-it-services-services-detail.html">Cloud Services</a>
								</li>
								<li class="mb-1">
									<a href="demo-it-services-services-detail.html">Tech Support</a>
								</li>
								<li class="mb-1">
									<a href="demo-it-services-services-detail.html">Data Security</a>
								</li>
								<li>
									<a href="demo-it-services-services-detail.html">Software Dev</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-lg-2 mb-4 mb-md-0">
							<h4 class="ls-0">ABOUT</h4>
							<ul class="list-unstyled">
								<li class="mb-1">
									<a href="demo-it-services-about-us.html">About Us</a>
								</li>
								<li>
									<a href="demo-it-services-contact.html">Send a Message</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-lg-2">
							<h4 class="ls-0">SOCIAL MEDIA</h4>
							<ul class="social-icons social-icons-clean custom-social-icons-icon-light">
								<li>
									<a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
								</li>
								<li>
									<a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				@include('porto.partials.footer-copyright.footer-copyright-21')
			</footer>
@endsection
